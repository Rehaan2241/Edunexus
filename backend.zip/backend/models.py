from sqlalchemy import Column, Integer, String, Boolean, Date, DateTime, Text, Numeric, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database import Base


class User(Base):
    __tablename__ = "users"
    id            = Column(Integer, primary_key=True, index=True)
    email         = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role          = Column(String, nullable=False)   # hod / advisor / mentor / student
    first_login   = Column(Boolean, default=False)
    created_at    = Column(DateTime(timezone=True), server_default=func.now())


class Mentor(Base):
    __tablename__ = "mentors"
    id         = Column(Integer, primary_key=True)
    user_id    = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"))
    name       = Column(String, nullable=False)
    department = Column(String, default="CSE")

    mentees       = relationship("Student",      back_populates="mentor_rel")
    announcements = relationship("Announcement", back_populates="mentor_rel")
    chat_messages = relationship("ChatMessage",  back_populates="mentor_rel")


class Advisor(Base):
    __tablename__ = "advisors"
    id      = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"))
    name    = Column(String, nullable=False)
    year    = Column(Integer, nullable=False)
    section = Column(String(1), nullable=False)

    students = relationship("Student", back_populates="advisor_rel")


class Student(Base):
    __tablename__ = "students"
    id         = Column(Integer, primary_key=True)
    user_id    = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"))
    name       = Column(String, default="Pending")
    roll_no    = Column(String, unique=True, nullable=True)
    year       = Column(Integer)
    section    = Column(String(1))
    phone      = Column(String)
    cgpa       = Column(Numeric(4, 2), default=0.0)
    dob        = Column(Date)
    mentor_id  = Column(Integer, ForeignKey("mentors.id",  ondelete="SET NULL"), nullable=True)
    advisor_id = Column(Integer, ForeignKey("advisors.id", ondelete="SET NULL"), nullable=True)
    backlogs   = Column(Integer, default=0)

    mentor_rel        = relationship("Mentor",       back_populates="mentees")
    advisor_rel       = relationship("Advisor",      back_populates="students")
    attendance_records = relationship("Attendance",  back_populates="student")
    certificates      = relationship("Certificate",  back_populates="student")
    leave_requests    = relationship("LeaveRequest", back_populates="student")
    achievements      = relationship("Achievement",  back_populates="student")


class Attendance(Base):
    __tablename__ = "attendance"
    id         = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("students.id", ondelete="CASCADE"))
    date       = Column(Date, nullable=False)
    status     = Column(String, default="present")
    marked_by  = Column(Integer, ForeignKey("users.id"))

    student = relationship("Student", back_populates="attendance_records")


class Certificate(Base):
    __tablename__ = "certificates"
    id          = Column(Integer, primary_key=True)
    student_id  = Column(Integer, ForeignKey("students.id", ondelete="CASCADE"))
    title       = Column(String, nullable=False)
    type        = Column(String)
    issuer      = Column(String)
    issue_date  = Column(Date)
    file_path   = Column(String)
    uploaded_at = Column(DateTime(timezone=True), server_default=func.now())

    student = relationship("Student", back_populates="certificates")


class Announcement(Base):
    __tablename__ = "announcements"
    id         = Column(Integer, primary_key=True)
    mentor_id  = Column(Integer, ForeignKey("mentors.id", ondelete="CASCADE"))
    title      = Column(String, nullable=False)
    body       = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    mentor_rel = relationship("Mentor", back_populates="announcements")


class LeaveRequest(Base):
    __tablename__ = "leave_requests"
    id          = Column(Integer, primary_key=True)
    student_id  = Column(Integer, ForeignKey("students.id", ondelete="CASCADE"))
    type        = Column(String)
    from_date   = Column(Date, nullable=False)
    to_date     = Column(Date, nullable=False)
    reason      = Column(Text)
    status      = Column(String, default="pending")
    reviewed_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    reviewed_at = Column(DateTime(timezone=True), nullable=True)

    student = relationship("Student", back_populates="leave_requests")


class ChatMessage(Base):
    __tablename__ = "chat_messages"
    id             = Column(Integer, primary_key=True)
    mentor_id      = Column(Integer, ForeignKey("mentors.id", ondelete="CASCADE"))
    sender_user_id = Column(Integer, ForeignKey("users.id"))
    sender_name    = Column(String)
    message        = Column(Text, nullable=False)
    sent_at        = Column(DateTime(timezone=True), server_default=func.now())

    mentor_rel = relationship("Mentor", back_populates="chat_messages")


class Achievement(Base):
    __tablename__ = "achievements"
    id         = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("students.id", ondelete="CASCADE"))
    title      = Column(String, nullable=False)

    student = relationship("Student", back_populates="achievements")


class Examination(Base):
    __tablename__ = "examinations"
    id           = Column(Integer, primary_key=True)
    advisor_id   = Column(Integer, ForeignKey("advisors.id", ondelete="CASCADE"))
    name         = Column(String, nullable=False)
    conducted_on = Column(Date, nullable=False)
    created_at   = Column(DateTime(timezone=True), server_default=func.now())

    subjects = relationship("ExamSubject", back_populates="exam", cascade="all, delete")
    advisor  = relationship("Advisor")


class ExamSubject(Base):
    __tablename__ = "exam_subjects"
    id             = Column(Integer, primary_key=True)
    examination_id = Column(Integer, ForeignKey("examinations.id", ondelete="CASCADE"))
    name           = Column(String, nullable=False)

    exam  = relationship("Examination", back_populates="subjects")
    marks = relationship("ExamMark", back_populates="subject", cascade="all, delete")


class ExamMark(Base):
    __tablename__ = "exam_marks"
    id             = Column(Integer, primary_key=True)
    examination_id = Column(Integer, ForeignKey("examinations.id", ondelete="CASCADE"))
    subject_id     = Column(Integer, ForeignKey("exam_subjects.id", ondelete="CASCADE"))
    student_id     = Column(Integer, ForeignKey("students.id",      ondelete="CASCADE"))
    subject_mark   = Column(Numeric(6,2), default=0)
    max_mark       = Column(Numeric(6,2), default=100)
    activity_mark  = Column(Numeric(6,2), default=0)
    grade          = Column(String(5))
    pass_fail      = Column(String(4), default="Pass")

    subject = relationship("ExamSubject", back_populates="marks")
    student = relationship("Student")

class Staff(Base):
    __tablename__ = "staff"
    id         = Column(Integer, primary_key=True)
    user_id    = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=True)
    name       = Column(String, nullable=False)
    short_name = Column(String(10))
    department = Column(String, default="CSE")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    subjects   = relationship("Subject", back_populates="staff_rel")


class Subject(Base):
    __tablename__ = "subjects"
    id             = Column(Integer, primary_key=True)
    name           = Column(String, nullable=False)
    code           = Column(String(20))
    year           = Column(Integer, nullable=False)
    staff_id       = Column(Integer, ForeignKey("staff.id", ondelete="SET NULL"), nullable=True)
    hours_per_week = Column(Integer, default=5)
    is_lab         = Column(Boolean, default=False)
    staff_rel      = relationship("Staff", back_populates="subjects")
    timetable_entries = relationship("Timetable", back_populates="subject_rel")


class Timetable(Base):
    __tablename__ = "timetable"
    id         = Column(Integer, primary_key=True)
    year       = Column(Integer, nullable=False)
    section    = Column(String(1), nullable=False)
    day        = Column(String(10), nullable=False)
    slot_index = Column(Integer, nullable=False)
    subject_id = Column(Integer, ForeignKey("subjects.id", ondelete="SET NULL"), nullable=True)
    staff_id   = Column(Integer, ForeignKey("staff.id",    ondelete="SET NULL"), nullable=True)
    subject_rel = relationship("Subject", back_populates="timetable_entries")
    staff_rel   = relationship("Staff")


class AttendanceLock(Base):
    __tablename__ = "attendance_locks"
    id         = Column(Integer, primary_key=True)
    lock_date  = Column(Date, nullable=False, unique=True)
    locked_by  = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    locked_at  = Column(DateTime(timezone=True), server_default=func.now())


class PeriodAttendance(Base):
    __tablename__ = "period_attendance"
    id         = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("students.id", ondelete="CASCADE"))
    subject_id = Column(Integer, ForeignKey("subjects.id", ondelete="CASCADE"))
    staff_id   = Column(Integer, ForeignKey("staff.id",    ondelete="SET NULL"), nullable=True)
    date       = Column(Date, nullable=False)
    slot_index = Column(Integer, nullable=False)
    status     = Column(String, default="present")
    marked_by  = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    marked_at  = Column(DateTime(timezone=True), server_default=func.now())
