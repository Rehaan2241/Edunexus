-- =====================================================
-- MentorConnect — Complete Seed Data (OLD STRUCTURE)
-- Roles: hod | mentor | advisor | student
-- Password for ALL users: password
-- 135 students across Year 2,3,4 (3 sections each)
-- All assigned to mentors and advisors
-- 30 days of attendance included
-- =====================================================

-- HOD
INSERT INTO users (email, password_hash, role) VALUES ('hod@college.edu', 'password', 'hod');

-- MENTORS
INSERT INTO users (email, password_hash, role) VALUES
('rajesh.kumar@college.edu',   'password', 'mentor'),
('priya.sharma@college.edu',   'password', 'mentor'),
('anand.krishnan@college.edu', 'password', 'mentor');

INSERT INTO mentors (user_id, name, department)
SELECT id, 'Dr. Rajesh Kumar',     'CSE' FROM users WHERE email='rajesh.kumar@college.edu';
INSERT INTO mentors (user_id, name, department)
SELECT id, 'Dr. Priya Sharma',     'CSE' FROM users WHERE email='priya.sharma@college.edu';
INSERT INTO mentors (user_id, name, department)
SELECT id, 'Prof. Anand Krishnan', 'CSE' FROM users WHERE email='anand.krishnan@college.edu';

-- CLASS ADVISORS
INSERT INTO users (email, password_hash, role) VALUES
('kavitha.rajan@college.edu',  'password', 'advisor'),
('suresh.babu@college.edu',    'password', 'advisor'),
('deepa.nair@college.edu',     'password', 'advisor'),
('mohan.raj@college.edu',      'password', 'advisor'),
('sangeetha.devi@college.edu', 'password', 'advisor'),
('karthik.selvan@college.edu', 'password', 'advisor'),
('lakshmi.prabha@college.edu', 'password', 'advisor'),
('vijay.anand@college.edu',    'password', 'advisor'),
('meena.kumari@college.edu',   'password', 'advisor');

INSERT INTO advisors (user_id, name, year, section) SELECT id, 'Mrs. Kavitha Rajan',  2,'A' FROM users WHERE email='kavitha.rajan@college.edu';
INSERT INTO advisors (user_id, name, year, section) SELECT id, 'Mr. Suresh Babu',     2,'B' FROM users WHERE email='suresh.babu@college.edu';
INSERT INTO advisors (user_id, name, year, section) SELECT id, 'Mrs. Deepa Nair',     2,'C' FROM users WHERE email='deepa.nair@college.edu';
INSERT INTO advisors (user_id, name, year, section) SELECT id, 'Dr. Mohan Raj',       3,'A' FROM users WHERE email='mohan.raj@college.edu';
INSERT INTO advisors (user_id, name, year, section) SELECT id, 'Mrs. Sangeetha Devi', 3,'B' FROM users WHERE email='sangeetha.devi@college.edu';
INSERT INTO advisors (user_id, name, year, section) SELECT id, 'Mr. Karthik Selvan',  3,'C' FROM users WHERE email='karthik.selvan@college.edu';
INSERT INTO advisors (user_id, name, year, section) SELECT id, 'Dr. Lakshmi Prabha',  4,'A' FROM users WHERE email='lakshmi.prabha@college.edu';
INSERT INTO advisors (user_id, name, year, section) SELECT id, 'Mr. Vijay Anand',     4,'B' FROM users WHERE email='vijay.anand@college.edu';
INSERT INTO advisors (user_id, name, year, section) SELECT id, 'Mrs. Meena Kumari',   4,'C' FROM users WHERE email='meena.kumari@college.edu';

-- EXTRA TEACHING STAFF (for timetable)
INSERT INTO users (email, password_hash, role) VALUES
('senthil.kumar@college.edu', 'password', 'mentor'),
('divya.priya@college.edu',   'password', 'mentor'),
('prakash.raj@college.edu',   'password', 'mentor'),
('rekha.devi@college.edu',    'password', 'mentor'),
('arun.selvan@college.edu',   'password', 'mentor'),
('nirmala.raj@college.edu',   'password', 'mentor'),
('venkat.raman@college.edu',  'password', 'mentor'),
('geetha.nair@college.edu',   'password', 'mentor'),
('ravi.shankar@college.edu',  'password', 'mentor'),
('sudha.menon@college.edu',   'password', 'mentor');

-- STAFF TABLE
INSERT INTO staff (user_id, name, short_name, department) SELECT u.id,'Dr. Rajesh Kumar','RK','CSE' FROM mentors m JOIN users u ON u.id=m.user_id WHERE m.name='Dr. Rajesh Kumar';
INSERT INTO staff (user_id, name, short_name, department) SELECT u.id,'Dr. Priya Sharma','PS','CSE' FROM mentors m JOIN users u ON u.id=m.user_id WHERE m.name='Dr. Priya Sharma';
INSERT INTO staff (user_id, name, short_name, department) SELECT u.id,'Prof. Anand Krishnan','AK','CSE' FROM mentors m JOIN users u ON u.id=m.user_id WHERE m.name='Prof. Anand Krishnan';
INSERT INTO staff (user_id, name, short_name, department) SELECT u.id,a.name,'KR','CSE' FROM advisors a JOIN users u ON u.id=a.user_id WHERE a.name='Mrs. Kavitha Rajan';
INSERT INTO staff (user_id, name, short_name, department) SELECT u.id,a.name,'SB','CSE' FROM advisors a JOIN users u ON u.id=a.user_id WHERE a.name='Mr. Suresh Babu';
INSERT INTO staff (user_id, name, short_name, department) SELECT u.id,a.name,'DN','CSE' FROM advisors a JOIN users u ON u.id=a.user_id WHERE a.name='Mrs. Deepa Nair';
INSERT INTO staff (user_id, name, short_name, department) SELECT u.id,a.name,'MR','CSE' FROM advisors a JOIN users u ON u.id=a.user_id WHERE a.name='Dr. Mohan Raj';
INSERT INTO staff (user_id, name, short_name, department) SELECT u.id,a.name,'SD','CSE' FROM advisors a JOIN users u ON u.id=a.user_id WHERE a.name='Mrs. Sangeetha Devi';
INSERT INTO staff (user_id, name, short_name, department) SELECT u.id,a.name,'KS','CSE' FROM advisors a JOIN users u ON u.id=a.user_id WHERE a.name='Mr. Karthik Selvan';
INSERT INTO staff (user_id, name, short_name, department) SELECT u.id,a.name,'LP','CSE' FROM advisors a JOIN users u ON u.id=a.user_id WHERE a.name='Dr. Lakshmi Prabha';
INSERT INTO staff (user_id, name, short_name, department) SELECT u.id,a.name,'VA','CSE' FROM advisors a JOIN users u ON u.id=a.user_id WHERE a.name='Mr. Vijay Anand';
INSERT INTO staff (user_id, name, short_name, department) SELECT u.id,a.name,'MK','CSE' FROM advisors a JOIN users u ON u.id=a.user_id WHERE a.name='Mrs. Meena Kumari';
INSERT INTO staff (user_id, name, short_name, department) SELECT id,'Mr. Senthil Kumar','SK','CSE' FROM users WHERE email='senthil.kumar@college.edu';
INSERT INTO staff (user_id, name, short_name, department) SELECT id,'Mrs. Divya Priya','DP','CSE' FROM users WHERE email='divya.priya@college.edu';
INSERT INTO staff (user_id, name, short_name, department) SELECT id,'Mr. Prakash Raj','PR','CSE' FROM users WHERE email='prakash.raj@college.edu';
INSERT INTO staff (user_id, name, short_name, department) SELECT id,'Mrs. Rekha Devi','RD','CSE' FROM users WHERE email='rekha.devi@college.edu';
INSERT INTO staff (user_id, name, short_name, department) SELECT id,'Mr. Arun Selvan','AS','CSE' FROM users WHERE email='arun.selvan@college.edu';
INSERT INTO staff (user_id, name, short_name, department) SELECT id,'Mrs. Nirmala Raj','NR','CSE' FROM users WHERE email='nirmala.raj@college.edu';
INSERT INTO staff (user_id, name, short_name, department) SELECT id,'Mr. Venkat Raman','VR','CSE' FROM users WHERE email='venkat.raman@college.edu';
INSERT INTO staff (user_id, name, short_name, department) SELECT id,'Mrs. Geetha Nair','GN','CSE' FROM users WHERE email='geetha.nair@college.edu';
INSERT INTO staff (user_id, name, short_name, department) SELECT id,'Mr. Ravi Shankar','RS','CSE' FROM users WHERE email='ravi.shankar@college.edu';
INSERT INTO staff (user_id, name, short_name, department) SELECT id,'Mrs. Sudha Menon','SM','CSE' FROM users WHERE email='sudha.menon@college.edu';

-- SUBJECTS
DO $$
DECLARE
  s_rajesh INT; s_priya INT; s_anand INT; s_kavitha INT; s_mohan INT;
  s_senthil INT; s_divya INT; s_prakash INT; s_rekha INT; s_arun INT;
  s_nirmala INT; s_venkat INT; s_geetha INT;
BEGIN
  SELECT id INTO s_rajesh  FROM staff WHERE short_name='RK';
  SELECT id INTO s_priya   FROM staff WHERE short_name='PS';
  SELECT id INTO s_anand   FROM staff WHERE short_name='AK';
  SELECT id INTO s_kavitha FROM staff WHERE short_name='KR';
  SELECT id INTO s_mohan   FROM staff WHERE short_name='MR';
  SELECT id INTO s_senthil FROM staff WHERE short_name='SK';
  SELECT id INTO s_divya   FROM staff WHERE short_name='DP';
  SELECT id INTO s_prakash FROM staff WHERE short_name='PR';
  SELECT id INTO s_rekha   FROM staff WHERE short_name='RD';
  SELECT id INTO s_arun    FROM staff WHERE short_name='AS';
  SELECT id INTO s_nirmala FROM staff WHERE short_name='NR';
  SELECT id INTO s_venkat  FROM staff WHERE short_name='VR';
  SELECT id INTO s_geetha  FROM staff WHERE short_name='GN';
  INSERT INTO subjects (name,code,year,staff_id,hours_per_week,is_lab) VALUES
    ('Data Structures','CS201',2,s_rajesh,5,FALSE),
    ('Digital Electronics','CS202',2,s_senthil,5,FALSE),
    ('Object Oriented Programming','CS203',2,s_kavitha,5,FALSE),
    ('Discrete Mathematics','CS204',2,s_divya,5,FALSE),
    ('Computer Organization','CS205',2,s_prakash,5,FALSE),
    ('Communication Skills','CS206',2,s_rekha,3,FALSE),
    ('DS & OOP Lab','CS207',2,s_kavitha,1,TRUE),
    ('Operating Systems','CS301',3,s_priya,5,FALSE),
    ('Database Management Systems','CS302',3,s_mohan,5,FALSE),
    ('Computer Networks','CS303',3,s_arun,5,FALSE),
    ('Software Engineering','CS304',3,s_nirmala,5,FALSE),
    ('Theory of Computation','CS305',3,s_venkat,5,FALSE),
    ('Web Technologies','CS306',3,s_senthil,3,FALSE),
    ('DBMS & Networks Lab','CS307',3,s_mohan,1,TRUE),
    ('Machine Learning','CS401',4,s_anand,5,FALSE),
    ('Cloud Computing','CS402',4,s_geetha,5,FALSE),
    ('ML & Cloud Lab','CS403',4,s_anand,1,TRUE);
END $$;

-- STUDENTS (135 total — 15 per section, 3 sections per year, 3 years)
DO $$
DECLARE
  m1 INT; m2 INT; m3 INT;
  adv2a INT; adv2b INT; adv2c INT;
  adv3a INT; adv3b INT; adv3c INT;
  adv4a INT; adv4b INT; adv4c INT;
  uid INT;
BEGIN
  SELECT id INTO m1 FROM mentors WHERE name='Dr. Rajesh Kumar';
  SELECT id INTO m2 FROM mentors WHERE name='Dr. Priya Sharma';
  SELECT id INTO m3 FROM mentors WHERE name='Prof. Anand Krishnan';
  SELECT id INTO adv2a FROM advisors WHERE year=2 AND section='A';
  SELECT id INTO adv2b FROM advisors WHERE year=2 AND section='B';
  SELECT id INTO adv2c FROM advisors WHERE year=2 AND section='C';
  SELECT id INTO adv3a FROM advisors WHERE year=3 AND section='A';
  SELECT id INTO adv3b FROM advisors WHERE year=3 AND section='B';
  SELECT id INTO adv3c FROM advisors WHERE year=3 AND section='C';
  SELECT id INTO adv4a FROM advisors WHERE year=4 AND section='A';
  SELECT id INTO adv4b FROM advisors WHERE year=4 AND section='B';
  SELECT id INTO adv4c FROM advisors WHERE year=4 AND section='C';

  -- YEAR 2A
  INSERT INTO users(email,password_hash,role) VALUES('arun.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Arun Kumar','21CS001',2,'A','9876543201',8.5,'2003-04-12',m1,adv2a,0);
  INSERT INTO users(email,password_hash,role) VALUES('bhavya.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Bhavya Sri','21CS002',2,'A','9876543202',7.8,'2003-06-22',m1,adv2a,0);
  INSERT INTO users(email,password_hash,role) VALUES('chandru.m@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Chandru Mohan','21CS003',2,'A','9876543203',6.9,'2003-02-15',m1,adv2a,1);
  INSERT INTO users(email,password_hash,role) VALUES('divya.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Divya Raj','21CS004',2,'A','9876543204',9.1,'2003-08-30',m1,adv2a,0);
  INSERT INTO users(email,password_hash,role) VALUES('eswaran.p@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Eswaran Pillai','21CS005',2,'A','9876543205',7.2,'2003-11-05',m1,adv2a,0);
  INSERT INTO users(email,password_hash,role) VALUES('fathima.z@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Fathima Zara','21CS006',2,'A','9876543206',8.3,'2003-03-18',m2,adv2a,0);
  INSERT INTO users(email,password_hash,role) VALUES('ganesh.v@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Ganesh Venkat','21CS007',2,'A','9876543207',6.5,'2003-07-25',m2,adv2a,2);
  INSERT INTO users(email,password_hash,role) VALUES('haritha.d@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Haritha Devi','21CS008',2,'A','9876543208',8.8,'2003-01-10',m2,adv2a,0);
  INSERT INTO users(email,password_hash,role) VALUES('ishaan.v@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Ishaan Verma','21CS009',2,'A','9876543209',7.5,'2003-09-14',m2,adv2a,0);
  INSERT INTO users(email,password_hash,role) VALUES('jasmine.f@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Jasmine Fathima','21CS010',2,'A','9876543210',9.3,'2003-05-20',m2,adv2a,0);
  INSERT INTO users(email,password_hash,role) VALUES('kiran.b@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Kiran Babu','21CS011',2,'A','9876543211',7.0,'2003-12-03',m3,adv2a,1);
  INSERT INTO users(email,password_hash,role) VALUES('logesh.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Logesh Raj','21CS012',2,'A','9876543212',8.1,'2003-10-17',m3,adv2a,0);
  INSERT INTO users(email,password_hash,role) VALUES('malathi.p@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Malathi Priya','21CS013',2,'A','9876543213',6.7,'2003-04-28',m3,adv2a,0);
  INSERT INTO users(email,password_hash,role) VALUES('naveen.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Naveen Raj','21CS014',2,'A','9876543214',8.6,'2003-06-08',m3,adv2a,0);
  INSERT INTO users(email,password_hash,role) VALUES('oviya.n@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Oviya Nair','21CS015',2,'A','9876543215',7.9,'2003-02-22',m3,adv2a,0);

  -- YEAR 2B
  INSERT INTO users(email,password_hash,role) VALUES('pravin.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Pravin Kumar','21CS016',2,'B','9876543216',8.2,'2003-03-11',m1,adv2b,0);
  INSERT INTO users(email,password_hash,role) VALUES('queenie.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Queenie Rose','21CS017',2,'B','9876543217',7.6,'2003-07-19',m1,adv2b,0);
  INSERT INTO users(email,password_hash,role) VALUES('rahman.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Rahman Sha','21CS018',2,'B','9876543218',6.8,'2003-11-24',m1,adv2b,1);
  INSERT INTO users(email,password_hash,role) VALUES('sathya.m@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Sathya Moorthy','21CS019',2,'B','9876543219',9.0,'2003-01-30',m2,adv2b,0);
  INSERT INTO users(email,password_hash,role) VALUES('thendral.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Thendral Kumari','21CS020',2,'B','9876543220',7.3,'2003-05-16',m2,adv2b,0);
  INSERT INTO users(email,password_hash,role) VALUES('udhay.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Udhay Shankar','21CS021',2,'B','9876543221',8.4,'2003-08-07',m2,adv2b,0);
  INSERT INTO users(email,password_hash,role) VALUES('vaishnavi.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Vaishnavi Raj','21CS022',2,'B','9876543222',9.2,'2003-04-01',m2,adv2b,0);
  INSERT INTO users(email,password_hash,role) VALUES('waqar.h@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Waqar Hussain','21CS023',2,'B','9876543223',6.4,'2003-09-23',m2,adv2b,2);
  INSERT INTO users(email,password_hash,role) VALUES('xavier.j@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Xavier Joseph','21CS024',2,'B','9876543224',7.7,'2003-12-14',m3,adv2b,0);
  INSERT INTO users(email,password_hash,role) VALUES('yamini.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Yamini Selvi','21CS025',2,'B','9876543225',8.9,'2003-02-06',m3,adv2b,0);
  INSERT INTO users(email,password_hash,role) VALUES('zubair.m@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Zubair Mohammed','21CS026',2,'B','9876543226',7.1,'2003-06-29',m3,adv2b,0);
  INSERT INTO users(email,password_hash,role) VALUES('abinaya.v@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Abinaya Velu','21CS027',2,'B','9876543227',8.0,'2003-10-11',m3,adv2b,0);
  INSERT INTO users(email,password_hash,role) VALUES('balamurali.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Balamurali Krishnan','21CS028',2,'B','9876543228',6.6,'2003-03-26',m1,adv2b,1);
  INSERT INTO users(email,password_hash,role) VALUES('charulatha.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Charulatha Srinivas','21CS029',2,'B','9876543229',8.7,'2003-07-04',m1,adv2b,0);
  INSERT INTO users(email,password_hash,role) VALUES('dinesh.p@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Dinesh Prabhu','21CS030',2,'B','9876543230',7.4,'2003-11-18',m2,adv2b,0);

  -- YEAR 2C
  INSERT INTO users(email,password_hash,role) VALUES('elango.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Elango Raja','21CS031',2,'C','9876543231',8.3,'2003-04-09',m1,adv2c,0);
  INSERT INTO users(email,password_hash,role) VALUES('femitha.a@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Femitha Ameen','21CS032',2,'C','9876543232',9.0,'2003-08-21',m1,adv2c,0);
  INSERT INTO users(email,password_hash,role) VALUES('gowtham.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Gowtham Suresh','21CS033',2,'C','9876543233',6.8,'2003-01-16',m2,adv2c,1);
  INSERT INTO users(email,password_hash,role) VALUES('hema.v@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Hema Valli','21CS034',2,'C','9876543234',8.6,'2003-05-03',m2,adv2c,0);
  INSERT INTO users(email,password_hash,role) VALUES('ilavarasan.m@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Ilavarasan Muthu','21CS035',2,'C','9876543235',7.6,'2003-09-27',m2,adv2c,0);
  INSERT INTO users(email,password_hash,role) VALUES('janani.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Janani Rajan','21CS036',2,'C','9876543236',8.9,'2003-12-12',m2,adv2c,0);
  INSERT INTO users(email,password_hash,role) VALUES('kalaivanan.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Kalaivanan Selvam','21CS037',2,'C','9876543237',7.2,'2003-03-07',m3,adv2c,0);
  INSERT INTO users(email,password_hash,role) VALUES('lavanya.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Lavanya Kumar','21CS038',2,'C','9876543238',9.4,'2003-07-31',m3,adv2c,0);
  INSERT INTO users(email,password_hash,role) VALUES('mani.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Mani Selvan','21CS039',2,'C','9876543239',6.5,'2003-11-20',m3,adv2c,2);
  INSERT INTO users(email,password_hash,role) VALUES('nithya.p@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Nithya Priya','21CS040',2,'C','9876543240',8.1,'2003-02-14',m3,adv2c,0);
  INSERT INTO users(email,password_hash,role) VALUES('omkumar.v@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Om Kumar Vijay','21CS041',2,'C','9876543241',7.7,'2003-06-26',m1,adv2c,0);
  INSERT INTO users(email,password_hash,role) VALUES('pavithra.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Pavithra Selvi','21CS042',2,'C','9876543242',8.4,'2003-10-09',m1,adv2c,0);
  INSERT INTO users(email,password_hash,role) VALUES('rajkumar.a@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Rajkumar Anand','21CS043',2,'C','9876543243',7.0,'2003-04-23',m2,adv2c,1);
  INSERT INTO users(email,password_hash,role) VALUES('saranya.m@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Saranya Mani','21CS044',2,'C','9876543244',8.8,'2003-08-15',m2,adv2c,0);
  INSERT INTO users(email,password_hash,role) VALUES('tamil.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Tamil Selvan','21CS045',2,'C','9876543245',7.3,'2003-12-29',m3,adv2c,0);

  -- YEAR 3A
  INSERT INTO users(email,password_hash,role) VALUES('aakash.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Aakash Raj','20CS001',3,'A','9876543301',8.7,'2002-03-15',m1,adv3a,0);
  INSERT INTO users(email,password_hash,role) VALUES('bharathi.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Bharathi Kumari','20CS002',3,'A','9876543302',7.4,'2002-07-22',m1,adv3a,0);
  INSERT INTO users(email,password_hash,role) VALUES('chitra.v@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Chitra Velu','20CS003',3,'A','9876543303',6.6,'2002-11-08',m2,adv3a,1);
  INSERT INTO users(email,password_hash,role) VALUES('deepak.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Deepak Sharma','20CS004',3,'A','9876543304',9.2,'2002-01-25',m2,adv3a,0);
  INSERT INTO users(email,password_hash,role) VALUES('ezhilan.p@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Ezhilan Pari','20CS005',3,'A','9876543305',7.8,'2002-05-19',m2,adv3a,0);
  INSERT INTO users(email,password_hash,role) VALUES('fiona.j@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Fiona James','20CS006',3,'A','9876543306',8.5,'2002-09-02',m3,adv3a,0);
  INSERT INTO users(email,password_hash,role) VALUES('ganesh.k2@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Ganesh Kumar','20CS007',3,'A','9876543307',6.3,'2002-12-16',m3,adv3a,2);
  INSERT INTO users(email,password_hash,role) VALUES('harini.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Harini Selvi','20CS008',3,'A','9876543308',9.0,'2002-04-30',m3,adv3a,0);
  INSERT INTO users(email,password_hash,role) VALUES('ibrahim.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Ibrahim Khan','20CS009',3,'A','9876543309',7.6,'2002-08-13',m1,adv3a,0);
  INSERT INTO users(email,password_hash,role) VALUES('jayanthi.m@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Jayanthi Mani','20CS010',3,'A','9876543310',8.2,'2002-02-27',m1,adv3a,0);
  INSERT INTO users(email,password_hash,role) VALUES('kannan.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Kannan Raj','20CS011',3,'A','9876543311',7.0,'2002-06-10',m2,adv3a,1);
  INSERT INTO users(email,password_hash,role) VALUES('lekha.v@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Lekha Vani','20CS012',3,'A','9876543312',8.8,'2002-10-24',m2,adv3a,0);
  INSERT INTO users(email,password_hash,role) VALUES('murugan.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Murugan Selvan','20CS013',3,'A','9876543313',6.7,'2002-03-08',m3,adv3a,0);
  INSERT INTO users(email,password_hash,role) VALUES('nandhini.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Nandhini Kumar','20CS014',3,'A','9876543314',9.1,'2002-07-21',m3,adv3a,0);
  INSERT INTO users(email,password_hash,role) VALUES('obuli.m@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Obuli Murugan','20CS015',3,'A','9876543315',7.5,'2002-11-04',m3,adv3a,0);

  -- YEAR 3B
  INSERT INTO users(email,password_hash,role) VALUES('parveen.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Parveen Sultana','20CS016',3,'B','9876543316',8.4,'2002-04-17',m1,adv3b,0);
  INSERT INTO users(email,password_hash,role) VALUES('rajini.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Rajini Kumar','20CS017',3,'B','9876543317',7.2,'2002-08-30',m1,adv3b,0);
  INSERT INTO users(email,password_hash,role) VALUES('sakthi.v@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Sakthi Vel','20CS018',3,'B','9876543318',6.4,'2002-12-13',m2,adv3b,2);
  INSERT INTO users(email,password_hash,role) VALUES('tamilarasi.m@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Tamilarasi Mani','20CS019',3,'B','9876543319',9.3,'2002-02-01',m2,adv3b,0);
  INSERT INTO users(email,password_hash,role) VALUES('umesh.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Umesh Raj','20CS020',3,'B','9876543320',7.9,'2002-06-24',m2,adv3b,0);
  INSERT INTO users(email,password_hash,role) VALUES('vanitha.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Vanitha Selvi','20CS021',3,'B','9876543321',8.6,'2002-10-07',m3,adv3b,0);
  INSERT INTO users(email,password_hash,role) VALUES('wesly.j@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Wesly Joseph','20CS022',3,'B','9876543322',7.1,'2002-03-20',m3,adv3b,1);
  INSERT INTO users(email,password_hash,role) VALUES('xena.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Xena Kumar','20CS023',3,'B','9876543323',8.9,'2002-07-03',m3,adv3b,0);
  INSERT INTO users(email,password_hash,role) VALUES('yuvan.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Yuvan Shankar','20CS024',3,'B','9876543324',6.9,'2002-11-16',m1,adv3b,0);
  INSERT INTO users(email,password_hash,role) VALUES('zara.b@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Zara Begum','20CS025',3,'B','9876543325',9.1,'2002-04-29',m1,adv3b,0);
  INSERT INTO users(email,password_hash,role) VALUES('akilan.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Akilan Raja','20CS026',3,'B','9876543326',7.5,'2002-08-12',m2,adv3b,0);
  INSERT INTO users(email,password_hash,role) VALUES('bavya.m@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Bavya Mani','20CS027',3,'B','9876543327',8.2,'2002-12-26',m2,adv3b,0);
  INSERT INTO users(email,password_hash,role) VALUES('chelvan.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Chelvan Siva','20CS028',3,'B','9876543328',6.6,'2002-05-09',m3,adv3b,1);
  INSERT INTO users(email,password_hash,role) VALUES('dhivya.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Dhivya Raj','20CS029',3,'B','9876543329',8.7,'2002-09-22',m3,adv3b,0);
  INSERT INTO users(email,password_hash,role) VALUES('ethiraj.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Ethiraj Kumar','20CS030',3,'B','9876543330',7.3,'2002-01-15',m3,adv3b,0);

  -- YEAR 3C
  INSERT INTO users(email,password_hash,role) VALUES('faizal.m@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Faizal Malik','20CS031',3,'C','9876543331',8.0,'2002-05-28',m1,adv3c,0);
  INSERT INTO users(email,password_hash,role) VALUES('geetha.v@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Geetha Valli','20CS032',3,'C','9876543332',9.0,'2002-09-11',m1,adv3c,0);
  INSERT INTO users(email,password_hash,role) VALUES('hari.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Hari Selvan','20CS033',3,'C','9876543333',6.5,'2002-01-24',m2,adv3c,2);
  INSERT INTO users(email,password_hash,role) VALUES('inba.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Inba Raj','20CS034',3,'C','9876543334',8.4,'2002-06-07',m2,adv3c,0);
  INSERT INTO users(email,password_hash,role) VALUES('jeeva.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Jeeva Kumar','20CS035',3,'C','9876543335',7.6,'2002-10-20',m2,adv3c,0);
  INSERT INTO users(email,password_hash,role) VALUES('kaveri.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Kaveri Selvi','20CS036',3,'C','9876543336',9.2,'2002-02-13',m3,adv3c,0);
  INSERT INTO users(email,password_hash,role) VALUES('lingam.v@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Lingam Vel','20CS037',3,'C','9876543337',7.0,'2002-07-27',m3,adv3c,1);
  INSERT INTO users(email,password_hash,role) VALUES('meena.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Meena Raj','20CS038',3,'C','9876543338',8.6,'2002-11-10',m3,adv3c,0);
  INSERT INTO users(email,password_hash,role) VALUES('naveenkumar.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Naveen Kumar S','20CS039',3,'C','9876543339',7.3,'2002-03-23',m1,adv3c,0);
  INSERT INTO users(email,password_hash,role) VALUES('padma.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Padma Kumar','20CS040',3,'C','9876543340',8.1,'2002-08-06',m1,adv3c,0);
  INSERT INTO users(email,password_hash,role) VALUES('raghu.m@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Raghu Mani','20CS041',3,'C','9876543341',6.8,'2002-12-19',m2,adv3c,1);
  INSERT INTO users(email,password_hash,role) VALUES('selvi.p@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Selvi Priya','20CS042',3,'C','9876543342',8.9,'2002-04-02',m2,adv3c,0);
  INSERT INTO users(email,password_hash,role) VALUES('thiru.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Thiru Selvan','20CS043',3,'C','9876543343',7.7,'2002-08-16',m3,adv3c,0);
  INSERT INTO users(email,password_hash,role) VALUES('umarani.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Umarani Kumar','20CS044',3,'C','9876543344',9.3,'2002-05-31',m3,adv3c,0);
  INSERT INTO users(email,password_hash,role) VALUES('vijay.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Vijay Raja','20CS045',3,'C','9876543345',7.4,'2002-09-14',m3,adv3c,0);

  -- YEAR 4A
  INSERT INTO users(email,password_hash,role) VALUES('ajith.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Ajith Kumar','19CS001',4,'A','9876543401',8.8,'2001-02-18',m1,adv4a,0);
  INSERT INTO users(email,password_hash,role) VALUES('benita.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Benita Selvi','19CS002',4,'A','9876543402',7.5,'2001-06-01',m1,adv4a,0);
  INSERT INTO users(email,password_hash,role) VALUES('chellapandi.m@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Chellapandi Murugan','19CS003',4,'A','9876543403',6.7,'2001-10-14',m2,adv4a,1);
  INSERT INTO users(email,password_hash,role) VALUES('devi.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Devi Raj','19CS004',4,'A','9876543404',9.4,'2001-03-27',m2,adv4a,0);
  INSERT INTO users(email,password_hash,role) VALUES('elan.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Elan Selvan','19CS005',4,'A','9876543405',8.0,'2001-07-10',m2,adv4a,0);
  INSERT INTO users(email,password_hash,role) VALUES('farhan.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Farhan Khan','19CS006',4,'A','9876543406',7.3,'2001-11-23',m3,adv4a,0);
  INSERT INTO users(email,password_hash,role) VALUES('gomathi.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Gomathi Selvi','19CS007',4,'A','9876543407',8.5,'2001-04-06',m3,adv4a,0);
  INSERT INTO users(email,password_hash,role) VALUES('harikumar.v@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Hari Kumar Vel','19CS008',4,'A','9876543408',6.2,'2001-08-19',m3,adv4a,2);
  INSERT INTO users(email,password_hash,role) VALUES('indira.p@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Indira Priya','19CS009',4,'A','9876543409',9.0,'2001-01-02',m1,adv4a,0);
  INSERT INTO users(email,password_hash,role) VALUES('jagan.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Jagan Raj','19CS010',4,'A','9876543410',7.8,'2001-05-15',m1,adv4a,0);
  INSERT INTO users(email,password_hash,role) VALUES('kamala.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Kamala Selvi','19CS011',4,'A','9876543411',8.3,'2001-09-28',m2,adv4a,0);
  INSERT INTO users(email,password_hash,role) VALUES('logapriya.m@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Logapriya Mani','19CS012',4,'A','9876543412',7.1,'2001-02-11',m2,adv4a,1);
  INSERT INTO users(email,password_hash,role) VALUES('muthu.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Muthu Raja','19CS013',4,'A','9876543413',8.9,'2001-06-24',m3,adv4a,0);
  INSERT INTO users(email,password_hash,role) VALUES('nirmal.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Nirmal Selvan','19CS014',4,'A','9876543414',7.6,'2001-10-07',m3,adv4a,0);
  INSERT INTO users(email,password_hash,role) VALUES('oviya.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Oviya Kumar','19CS015',4,'A','9876543415',9.2,'2001-03-20',m3,adv4a,0);

  -- YEAR 4B
  INSERT INTO users(email,password_hash,role) VALUES('palani.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Palani Selvam','19CS016',4,'B','9876543416',8.1,'2001-07-03',m1,adv4b,0);
  INSERT INTO users(email,password_hash,role) VALUES('queen.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Queen Raj','19CS017',4,'B','9876543417',7.4,'2001-11-16',m1,adv4b,0);
  INSERT INTO users(email,password_hash,role) VALUES('rajan.m@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Rajan Murugan','19CS018',4,'B','9876543418',6.5,'2001-04-29',m2,adv4b,2);
  INSERT INTO users(email,password_hash,role) VALUES('savitha.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Savitha Kumar','19CS019',4,'B','9876543419',9.3,'2001-08-12',m2,adv4b,0);
  INSERT INTO users(email,password_hash,role) VALUES('tharun.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Tharun Selvan','19CS020',4,'B','9876543420',7.9,'2001-12-25',m2,adv4b,0);
  INSERT INTO users(email,password_hash,role) VALUES('usha.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Usha Rani','19CS021',4,'B','9876543421',8.6,'2001-05-08',m3,adv4b,0);
  INSERT INTO users(email,password_hash,role) VALUES('vikram.p@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Vikram Pandi','19CS022',4,'B','9876543422',7.2,'2001-09-21',m3,adv4b,1);
  INSERT INTO users(email,password_hash,role) VALUES('weslin.j@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Weslin James','19CS023',4,'B','9876543423',8.4,'2001-01-04',m3,adv4b,0);
  INSERT INTO users(email,password_hash,role) VALUES('xavier.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Xavier Sam','19CS024',4,'B','9876543424',9.0,'2001-06-17',m1,adv4b,0);
  INSERT INTO users(email,password_hash,role) VALUES('yamuna.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Yamuna Raja','19CS025',4,'B','9876543425',7.0,'2001-10-30',m1,adv4b,0);
  INSERT INTO users(email,password_hash,role) VALUES('zainab.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Zainab Khan','19CS026',4,'B','9876543426',8.7,'2001-03-13',m2,adv4b,0);
  INSERT INTO users(email,password_hash,role) VALUES('anbu.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Anbu Selvan','19CS027',4,'B','9876543427',6.8,'2001-07-26',m2,adv4b,1);
  INSERT INTO users(email,password_hash,role) VALUES('brinda.m@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Brinda Mani','19CS028',4,'B','9876543428',8.2,'2001-11-09',m3,adv4b,0);
  INSERT INTO users(email,password_hash,role) VALUES('chetan.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Chetan Raj','19CS029',4,'B','9876543429',7.6,'2001-04-22',m3,adv4b,0);
  INSERT INTO users(email,password_hash,role) VALUES('dhanam.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Dhanam Selvi','19CS030',4,'B','9876543430',9.1,'2001-08-05',m3,adv4b,0);

  -- YEAR 4C
  INSERT INTO users(email,password_hash,role) VALUES('elil.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Elil Raja','19CS031',4,'C','9876543431',8.3,'2001-01-18',m1,adv4c,0);
  INSERT INTO users(email,password_hash,role) VALUES('florance.j@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Florance Joseph','19CS032',4,'C','9876543432',7.7,'2001-05-31',m1,adv4c,0);
  INSERT INTO users(email,password_hash,role) VALUES('guhan.m@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Guhan Murugan','19CS033',4,'C','9876543433',6.4,'2001-10-13',m2,adv4c,2);
  INSERT INTO users(email,password_hash,role) VALUES('haripriya.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Haripriya Selvi','19CS034',4,'C','9876543434',9.2,'2001-02-26',m2,adv4c,0);
  INSERT INTO users(email,password_hash,role) VALUES('ilayaraja.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Ilayaraja Kumar','19CS035',4,'C','9876543435',8.0,'2001-07-09',m2,adv4c,0);
  INSERT INTO users(email,password_hash,role) VALUES('jothika.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Jothika Raj','19CS036',4,'C','9876543436',7.5,'2001-11-22',m3,adv4c,0);
  INSERT INTO users(email,password_hash,role) VALUES('karthi.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Karthik Selvan','19CS037',4,'C','9876543437',8.7,'2001-04-05',m3,adv4c,0);
  INSERT INTO users(email,password_hash,role) VALUES('lalitha.m@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Lalitha Mani','19CS038',4,'C','9876543438',6.9,'2001-08-18',m3,adv4c,1);
  INSERT INTO users(email,password_hash,role) VALUES('madhan.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Madhan Raj','19CS039',4,'C','9876543439',9.0,'2001-12-01',m1,adv4c,0);
  INSERT INTO users(email,password_hash,role) VALUES('nithish.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Nithish Selvan','19CS040',4,'C','9876543440',7.8,'2001-05-14',m1,adv4c,0);
  INSERT INTO users(email,password_hash,role) VALUES('prabha.k@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Prabha Kumar','19CS041',4,'C','9876543441',8.4,'2001-09-27',m2,adv4c,0);
  INSERT INTO users(email,password_hash,role) VALUES('ramya.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Ramya Selvi','19CS042',4,'C','9876543442',7.2,'2001-02-10',m2,adv4c,0);
  INSERT INTO users(email,password_hash,role) VALUES('sudhan.m@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Sudhan Mani','19CS043',4,'C','9876543443',8.8,'2001-06-23',m3,adv4c,0);
  INSERT INTO users(email,password_hash,role) VALUES('thilagam.r@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Thilagam Raja','19CS044',4,'C','9876543444',7.0,'2001-10-06',m3,adv4c,1);
  INSERT INTO users(email,password_hash,role) VALUES('vasanth.s@student.edu','password','student') RETURNING id INTO uid; INSERT INTO students(user_id,name,roll_no,year,section,phone,cgpa,dob,mentor_id,advisor_id,backlogs) VALUES(uid,'Vasanth Selvan','19CS045',4,'C','9876543445',9.4,'2001-03-19',m3,adv4c,0);

END $$;

-- ATTENDANCE: last 30 working days (~85% present)
DO $$
DECLARE
  s RECORD;
  d DATE;
BEGIN
  FOR s IN SELECT id FROM students LOOP
    FOR d IN SELECT generate_series(CURRENT_DATE-29, CURRENT_DATE-1, '1 day'::interval)::date LOOP
      IF EXTRACT(DOW FROM d) NOT IN (0,6) THEN
        INSERT INTO attendance(student_id,date,status)
        VALUES(s.id, d, CASE WHEN random()<0.85 THEN 'present' ELSE 'absent' END)
        ON CONFLICT DO NOTHING;
      END IF;
    END LOOP;
  END LOOP;
END $$;
