-- =====================================================
-- MentorConnect — Database Schema
-- Run: psql -U postgres -d mentorconnect -f schema.sql
-- =====================================================

CREATE TABLE IF NOT EXISTS users (
    id            SERIAL PRIMARY KEY,
    email         VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role          VARCHAR(20) NOT NULL CHECK (role IN ('hod','advisor','mentor','student')),
    first_login   BOOLEAN DEFAULT FALSE,
    created_at    TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS mentors (
    id         SERIAL PRIMARY KEY,
    user_id    INT REFERENCES users(id) ON DELETE CASCADE,
    name       VARCHAR(255) NOT NULL,
    department VARCHAR(100) DEFAULT 'CSE'
);

CREATE TABLE IF NOT EXISTS advisors (
    id      SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id) ON DELETE CASCADE,
    name    VARCHAR(255) NOT NULL,
    year    INT NOT NULL,
    section CHAR(1) NOT NULL
);

CREATE TABLE IF NOT EXISTS students (
    id         SERIAL PRIMARY KEY,
    user_id    INT REFERENCES users(id) ON DELETE CASCADE,
    name       VARCHAR(255) DEFAULT 'Pending',
    roll_no    VARCHAR(50) UNIQUE,
    year       INT,
    section    CHAR(1),
    phone      VARCHAR(20),
    cgpa       DECIMAL(4,2) DEFAULT 0.0,
    dob        DATE,
    mentor_id  INT REFERENCES mentors(id)  ON DELETE SET NULL,
    advisor_id INT REFERENCES advisors(id) ON DELETE SET NULL,
    backlogs   INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS attendance (
    id         SERIAL PRIMARY KEY,
    student_id INT REFERENCES students(id) ON DELETE CASCADE,
    date       DATE NOT NULL,
    status     VARCHAR(10) DEFAULT 'present',
    marked_by  INT REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE(student_id, date)
);

CREATE TABLE IF NOT EXISTS certificates (
    id          SERIAL PRIMARY KEY,
    student_id  INT REFERENCES students(id) ON DELETE CASCADE,
    title       VARCHAR(255) NOT NULL,
    type        VARCHAR(50),
    issuer      VARCHAR(255),
    issue_date  DATE,
    file_path   VARCHAR(500),
    uploaded_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS announcements (
    id         SERIAL PRIMARY KEY,
    mentor_id  INT REFERENCES mentors(id) ON DELETE CASCADE,
    title      VARCHAR(255) NOT NULL,
    body       TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS leave_requests (
    id          SERIAL PRIMARY KEY,
    student_id  INT REFERENCES students(id) ON DELETE CASCADE,
    type        VARCHAR(20) CHECK (type IN ('Leave','On-Duty')),
    from_date   DATE NOT NULL,
    to_date     DATE NOT NULL,
    reason      TEXT,
    status      VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending','accepted','declined')),
    reviewed_by INT REFERENCES users(id),
    reviewed_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS chat_messages (
    id             SERIAL PRIMARY KEY,
    mentor_id      INT REFERENCES mentors(id) ON DELETE CASCADE,
    sender_user_id INT REFERENCES users(id),
    sender_name    VARCHAR(255),
    message        TEXT NOT NULL,
    sent_at        TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS achievements (
    id         SERIAL PRIMARY KEY,
    student_id INT REFERENCES students(id) ON DELETE CASCADE,
    title      VARCHAR(255) NOT NULL
);


CREATE TABLE IF NOT EXISTS examinations (
    id           SERIAL PRIMARY KEY,
    advisor_id   INT REFERENCES advisors(id) ON DELETE CASCADE,
    name         VARCHAR(255) NOT NULL,
    conducted_on DATE NOT NULL,
    created_at   TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS exam_subjects (
    id             SERIAL PRIMARY KEY,
    examination_id INT REFERENCES examinations(id) ON DELETE CASCADE,
    name           VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS exam_marks (
    id             SERIAL PRIMARY KEY,
    examination_id INT REFERENCES examinations(id) ON DELETE CASCADE,
    subject_id     INT REFERENCES exam_subjects(id) ON DELETE CASCADE,
    student_id     INT REFERENCES students(id) ON DELETE CASCADE,
    subject_mark   DECIMAL(6,2) DEFAULT 0,
    max_mark       DECIMAL(6,2) DEFAULT 100,
    activity_mark  DECIMAL(6,2) DEFAULT 0,
    grade          VARCHAR(5),
    pass_fail      VARCHAR(4) DEFAULT 'Pass',
    UNIQUE(subject_id, student_id)
);

CREATE TABLE IF NOT EXISTS staff (
    id         SERIAL PRIMARY KEY,
    user_id    INT REFERENCES users(id) ON DELETE CASCADE,
    name       VARCHAR(255) NOT NULL,
    short_name VARCHAR(10),
    department VARCHAR(100) DEFAULT 'CSE',
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS subjects (
    id         SERIAL PRIMARY KEY,
    name       VARCHAR(255) NOT NULL,
    code       VARCHAR(20),
    year       INT NOT NULL,
    staff_id   INT REFERENCES staff(id) ON DELETE SET NULL,
    hours_per_week INT DEFAULT 5,
    is_lab     BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS timetable (
    id         SERIAL PRIMARY KEY,
    year       INT NOT NULL,
    section    CHAR(1) NOT NULL,
    day        VARCHAR(10) NOT NULL,
    slot_index INT NOT NULL,
    subject_id INT REFERENCES subjects(id) ON DELETE SET NULL,
    staff_id   INT REFERENCES staff(id) ON DELETE SET NULL,
    UNIQUE(year, section, day, slot_index)
);

CREATE TABLE IF NOT EXISTS attendance_locks (
    id         SERIAL PRIMARY KEY,
    lock_date  DATE NOT NULL UNIQUE,
    locked_by  INT REFERENCES users(id) ON DELETE SET NULL,
    locked_at  TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS period_attendance (
    id         SERIAL PRIMARY KEY,
    student_id INT REFERENCES students(id) ON DELETE CASCADE,
    subject_id INT REFERENCES subjects(id) ON DELETE CASCADE,
    staff_id   INT REFERENCES staff(id) ON DELETE SET NULL,
    date       DATE NOT NULL,
    slot_index INT NOT NULL,
    status     VARCHAR(10) DEFAULT 'present',
    marked_by  INT REFERENCES users(id) ON DELETE SET NULL,
    marked_at  TIMESTAMP DEFAULT NOW(),
    UNIQUE(student_id, subject_id, date, slot_index)
);
