from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os

from database import Base, engine
from routers import auth, hod, advisor, mentor, student, chat ,exam , timetable

# Create all tables
Base.metadata.create_all(bind=engine)

# Ensure uploads folder exists
os.makedirs("uploads", exist_ok=True)

app = FastAPI(title="MentorConnect API", version="2.0.0")

# CORS — allow frontend to call the API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # In production: specify your frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve uploaded certificate files
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

# Register all routers
app.include_router(auth.router,    prefix="/api/auth",    tags=["Auth"])
app.include_router(hod.router,     prefix="/api/hod",     tags=["HOD"])
app.include_router(advisor.router, prefix="/api/advisor", tags=["Advisor"])
app.include_router(mentor.router,  prefix="/api/mentor",  tags=["Mentor"])
app.include_router(student.router, prefix="/api/student", tags=["Student"])
app.include_router(chat.router,    prefix="/api/chat",    tags=["Chat"])
app.include_router(exam.router,      prefix="/api/exam",      tags=["Exam"])
app.include_router(timetable.router, prefix="/api/timetable", tags=["Timetable"])


@app.get("/")
def root():
    return {"message": "MentorConnect API is running. Visit /docs for API documentation."}
