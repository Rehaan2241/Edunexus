// =====================================================
// MentorConnect — API Helper
// All backend calls go through here
// =====================================================

const BASE_URL = 'http://localhost:9000/api';

const API = {
  // ── INTERNAL FETCH HELPER ──────────────────────────
  async _fetch(method, path, body = null, isForm = false) {
    const token = localStorage.getItem('token');
    const headers = {};
    if (token) headers['Authorization'] = 'Bearer ' + token;
    if (!isForm && body) headers['Content-Type'] = 'application/json';

    const opts = { method, headers };
    if (body) opts.body = isForm ? body : JSON.stringify(body);

    const res = await fetch(BASE_URL + path, opts);
    if (res.status === 401) { localStorage.clear(); window.location.href = 'index.html'; return; }
    const json = await res.json();
    if (!res.ok) throw json;
    return json;
  },

  get:    (path)        => API._fetch('GET',    path),
  post:   (path, body)  => API._fetch('POST',   path, body),
  put:    (path, body)  => API._fetch('PUT',    path, body),
  del:    (path)        => API._fetch('DELETE', path),
  upload: (path, form)  => API._fetch('POST',   path, form, true),

  // ── AUTH ───────────────────────────────────────────
  login: (email, password) => API.post('/auth/login', { email, password }),
  changePassword: (data) => API.post('/auth/change-password', data),
  // ── HOD ───────────────────────────────────────────
  // Mentors
  getHodMentors:   ()           => API.get('/hod/mentors'),
  addMentor:       (data)       => API.post('/hod/mentors', data),
  deleteMentor:    (id)         => API.del('/hod/mentors/' + id),
  getAssignable:   (mentorId)   => API.get('/hod/mentors/' + mentorId + '/assignable-students'),
  assignStudents:  (mId, ids)   => API.put('/hod/mentors/' + mId + '/assign', { student_ids: ids }),
  // Students
  getHodStudents:  (p = {})     => API.get('/hod/students?' + new URLSearchParams(p)),
  getStudentFull:  (id)         => API.get('/hod/students/' + id + '/profile'),
  // Advisors
  getHodAdvisors:  ()           => API.get('/hod/advisors'),
  addAdvisor:      (data)       => API.post('/hod/advisors', data),
  changeAdvisor:   (id, data)   => API.put('/hod/advisors/' + id, data),
  deleteAdvisor:   (id)         => API.del('/hod/advisors/' + id),
  // Attendance
  getYearWise: (p = {}) => API.get('/hod/attendance/year-wise?' + 
    new URLSearchParams(Object.fromEntries(Object.entries(p).filter(([,v]) => v !== '' && v != null)))),
  getAbsences:     (p = {})     => API.get('/hod/attendance/absences?' + new URLSearchParams(p)),
  // Certificates
  getHodCerts:     ()           => API.get('/hod/certificates'),
  getPromotionPreview: ()  => API.get('/hod/promotion/preview'),

  // ── ADVISOR ───────────────────────────────────────
  getMyClass:             (advId)          => API.get('/advisor/my-class/' + advId),
  uploadAttendance:       (data)           => API.post('/advisor/attendance', data),
  getAttendanceByDate:    (advId, date)    => API.get(`/advisor/attendance/by-date/${advId}?date=${date}`),
  getLeaveReqs:    (advId)      => API.get('/advisor/leave-requests/' + advId),
  reviewLeave:     (id, data)   => API.put('/advisor/leave-requests/' + id, data),
  addStudent:      (data)       => API.post('/advisor/add-student', data),

  // ── MENTOR ────────────────────────────────────────
  getMentees:      (mId)        => API.get('/mentor/mentees/' + mId),
  getMentorCerts:  (mId)        => API.get('/mentor/certificates/' + mId),
  postAnnounce:    (mId, data)  => API.post('/mentor/announcements/' + mId, data),
  getAnnouncements:(mId)        => API.get('/mentor/announcements/' + mId),
  getMentorAlerts: (mId)        => API.get('/mentor/alerts/' + mId),

  // ── STUDENT ───────────────────────────────────────
  getMyProfile:    (sId)        => API.get('/student/profile/' + sId),
  updateProfile:   (sId, data)  => API.put('/student/profile/' + sId, data),
  uploadCert:      (sId, form)  => API.upload('/student/certificates/' + sId, form),
  submitLeave:     (sId, data)  => API.post('/student/leave-request/' + sId, data),
  getMyLeaves:     (sId)        => API.get('/student/leave-requests/' + sId),
  getMyAnnounce:   (sId)        => API.get('/student/announcements/' + sId),
  getMyAttendance: (sId)        => API.get('/student/attendance/' + sId),

  // ── CHAT ──────────────────────────────────────────
  getChatHistory:  (mId)        => API.get('/chat/history/' + mId),

  // ── EXAM ──────────────────────────────────────────
  getExams:       (advId)              => API.get('/exam/advisor/' + advId),
  createExam:     (data)               => API.post('/exam/create', data),
  deleteExam:     (id)                 => API.del('/exam/' + id),
  getExamMarks:   (examId, subjectId)  => API.get(`/exam/${examId}/subject/${subjectId}/marks`),
  saveExamMarks:    (examId, subjectId, data) => API.post(`/exam/${examId}/subject/${subjectId}/marks`, data),
  addExamSubject:   (examId, data)            => API.post('/exam/' + examId + '/add-subject', data),
  getStudentMarks:  (studentId)               => API.get('/exam/student/' + studentId + '/marks'),
  getAllExamMarks:   (advisorId)               => API.get('/exam/advisor/' + advisorId + '/all-marks'),
  getHodExamMarks:  ()                        => API.get('/exam/hod/all-marks'),

  // ── TIMETABLE ─────────────────────────────────────
  getStaff:           ()                => API.get('/timetable/staff'),
  addStaff:           (data)            => API.post('/timetable/staff', data),
  deleteStaff:        (id)              => API.del('/timetable/staff/' + id),
  getSubjects:        ()                => API.get('/timetable/subjects'),
  addSubject:         (data)            => API.post('/timetable/subjects', data),
  updateSubject:      (id, data)        => API.put('/timetable/subjects/' + id, data),
  deleteSubject:      (id)              => API.del('/timetable/subjects/' + id),
  getTimetable:       (year, section)   => API.get(`/timetable/view/${year}/${section}`),
  getStaffTimetable:  (staffId)         => API.get('/timetable/staff-view/' + staffId),
  generateTimetable:  (year, section)   => API.post(`/timetable/generate/${year}/${section}`, {}),

  // ── PERIOD ATTENDANCE ────────────────────────────
  getStaffSubjects:      (staffId)                          => API.get('/advisor/period-attendance/my-subjects/' + staffId),
  getStudentsForPeriod:  (year, section)                    => API.get('/advisor/period-attendance/students/' + year + '/' + section),
  getExistingPeriod:     (staffId, subjectId, date, slot)   => API.get('/advisor/period-attendance/existing/' + staffId + '/' + subjectId + '/' + date + '/' + slot),
  markPeriodAttendance:  (data)                             => API.post('/advisor/period-attendance/mark', data),
  getClassPeriodReport:  (advId, date)                      => API.get('/advisor/period-attendance/class-report/' + advId + (date ? '?date=' + date : '')),
  getMentorPeriodReport: (mentorId)                         => API.get('/advisor/period-attendance/mentor-report/' + mentorId),
  getStudentPeriodReport:(studentId)                        => API.get('/advisor/period-attendance/student-report/' + studentId),
  getHodPeriodReport:    (p = {})                           => API.get('/advisor/period-attendance/hod-report?' + new URLSearchParams(Object.fromEntries(Object.entries(p).filter(([,v]) => v !== '' && v != null)))),

  // ── ATTENDANCE LOCKS (HOD) ────────────────────────
  getLocks:     ()     => API.get('/hod/attendance/locks'),
  lockDate:     (data) => API.post('/hod/attendance/lock', data),
  unlockDate:   (date) => API.del('/hod/attendance/lock/' + date),
  isDateLocked: (date) => API.get('/hod/attendance/is-locked/' + date),

};

// ── WEBSOCKET CHAT ──────────────────────────────────
function openChatWS(mentorId, userId, onMessage, onOpen) {
  const wsUrl = `ws://localhost:9000/api/chat/ws/${mentorId}/${userId}`;
  const ws = new WebSocket(wsUrl);
  ws.onopen    = () => { if (onOpen) onOpen(); };
  ws.onmessage = e  => onMessage(JSON.parse(e.data));
  ws.onerror   = e  => console.error('WS error', e);
  ws.onclose   = () => console.log('WS closed');
  return ws;
}

// ── UTILITY HELPERS ─────────────────────────────────
function ini(name) {
  return (name || 'U').split(' ').map(w => w[0]).join('').substring(0, 2).toUpperCase();
}
function pill(text, cls) {
  return `<span class="pill p-${cls}">${text}</span>`;
}
function attnPill(pct) {
  const c = pct >= 75 ? 'green' : pct >= 60 ? 'amber' : 'red';
  return pill(pct + '%', c);
}
function attnBar(pct) {
  const col = pct >= 75 ? '#1D9E75' : pct >= 60 ? '#EF9F27' : '#E24B4A';
  return `<div class="attn-wrap"><div class="attn-bar" style="width:${pct}%;background:${col}"></div></div>`;
}
function avatarEl(name, bg, color, size = 32) {
  return `<div class="avatar" style="width:${size}px;height:${size}px;background:${bg};color:${color};font-size:${Math.floor(size * 0.35)}px">${ini(name)}</div>`;
}
function emptyState(icon, msg) {
  return `<div class="empty-state"><div class="empty-icon">${icon}</div>${msg}</div>`;
}
function fakeDownload(filename) {
  const url = `http://localhost:9000${filename}`;
  window.open(url, "_blank");
}
function formatDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}
function om(id) { document.getElementById(id).classList.add('open'); }
function cm(id) { document.getElementById(id).classList.remove('open'); }
function showToast(msg, type = 'success') {
  let t = document.getElementById('toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'toast';
    t.style.cssText = 'position:fixed;bottom:24px;right:24px;padding:12px 18px;border-radius:8px;font-size:13px;font-weight:600;z-index:9999;box-shadow:0 4px 12px rgba(0,0,0,.2);transition:opacity .3s';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.style.background = type === 'success' ? '#1D9E75' : type === 'error' ? '#E24B4A' : '#EF9F27';
  t.style.color = '#fff';
  t.style.opacity = '1';
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.style.opacity = '0', 3000);
}
