// =====================================================
// MentorConnect — Dashboard Logic (dashboard.js)
// Handles all 4 roles: HOD, Advisor, Mentor, Student
// =====================================================

// ── STATE ─────────────────────────────────────────────
let ROLE = '', USER_ID = null, ENTITY_ID = null;
let assigningMentorId = null, currentPage = '';
const chartRefs = {};
let chatWS = null;

// ── ROLE NAV CONFIG ────────────────────────────────────
const NAV = {
  hod: [
    { id: 'hod_overview',    icon: '📊', label: 'Overview' },
    { id: 'hod_students',    icon: '🎓', label: 'Students' },
    { id: 'hod_mentors',     icon: '👨🏫', label: 'Mentors' },
    { id: 'hod_advisors',    icon: '📋', label: 'Advisors' },
    { id: 'hod_attendance',  icon: '📅', label: 'Attendance' },
    { id: 'hod_certs',       icon: '🏅', label: 'Certificates' },
    { id: 'hod_exam_results', icon: '📊', label: 'Exam Results' },
    { id: 'hod_calendar',     icon: '🗒', label: 'Academic Calendar' },
    { id: 'hod_timetable',   icon: '📅', label: 'Timetable' },
  ],
  advisor: [
    { id: 'adv_class',       icon: '📋', label: 'My Class' },
    { id: 'adv_attend',      icon: '📅', label: 'Attendance' },
    { id: 'adv_period_attend', icon: '🕐', label: 'Period Attendance' },
    { id: 'adv_period_report',  icon: '📊', label: 'Period Report' },
    { id: 'adv_leave',       icon: '📝', label: 'Permissions' },
    { id: 'adv_students',    icon: '🎓', label: 'Student Profiles' },
    { id: 'adv_exam',        icon: '📝', label: 'Examination' },
    { id: 'adv_alerts',      icon: '🔔', label: 'Alerts' },
    { id: 'adv_calendar',    icon: '🗒', label: 'Academic Calendar' },
    { id: 'adv_timetable',   icon: '📅', label: 'Timetable' },
  ],
  mentor: [
    { id: 'ment_mentees',    icon: '👥', label: 'My Mentees' },
    { id: 'ment_certs',      icon: '🏅', label: 'Certificates' },
    { id: 'ment_announce',   icon: '📢', label: 'Announcements' },
    { id: 'ment_timeline',   icon: '📈', label: 'Student Timeline' },
    { id: 'ment_chat',       icon: '💬', label: 'Group Chat' },
    { id: 'ment_alerts',     icon: '🔔', label: 'Alerts' },
    { id: 'ment_calendar',   icon: '🗒', label: 'Academic Calendar' },
    { id: 'ment_timetable',  icon: '📅', label: 'Timetable' },
  ],
  student: [
    { id: 'stu_profile',     icon: '👤', label: 'My Profile' },
    { id: 'stu_attend',      icon: '📅', label: 'My Attendance' },
    { id: 'stu_certs',       icon: '🏅', label: 'My Certificates' },
    { id: 'stu_announce',    icon: '📢', label: 'Announcements' },
    { id: 'stu_chat',        icon: '💬', label: 'Group Chat' },
    { id: 'stu_leave',       icon: '📝', label: 'Leave / OD' },
    { id: 'stu_calendar',    icon: '🗒', label: 'Academic Calendar' },
    { id: 'stu_timetable',   icon: '📅', label: 'Timetable' },
  ],
};

// ── BOOT ──────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  const token = localStorage.getItem('token');
  if (!token) { window.location.href = 'index.html'; return; }

  ROLE = localStorage.getItem('role');
  if (!ROLE) { window.location.href = 'index.html'; return; }

  // Decode JWT to get user_id
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    USER_ID = parseInt(payload.sub);
  } catch (e) { window.location.href = 'index.html'; return; }

  // Set topbar
  const roleLabels = { hod: 'HOD', advisor: 'Class Advisor', mentor: 'Mentor', student: 'Student' };
  const roleColors = { hod: ['#E6F1FB','#0C447C'], advisor: ['#E1F5EE','#085041'], mentor: ['#EEEDFE','#534AB7'], student: ['#FAEEDA','#633806'] };
  const [bg, fg] = roleColors[ROLE] || ['#f0f0f0','#333'];
  document.getElementById('roleBadge').textContent = roleLabels[ROLE];
  document.getElementById('roleBadge').className = `role-badge rb-${ROLE}`;
  document.getElementById('tbAvatar').style.background = bg;
  document.getElementById('tbAvatar').style.color = fg;

  // Build sidebar
  buildSidebar();

  // Resolve entity ID from user
  await resolveEntityId();

  // Set user name
  document.getElementById('tbName').textContent = localStorage.getItem('userName') || '';
  document.getElementById('tbAvatar').textContent = ini(localStorage.getItem('userName') || 'U');

  // Check first login for students
  if (ROLE === 'student' && localStorage.getItem('first_login') === 'true') {
    setTimeout(() => om('mFirstLogin'), 500);
  }

  // Navigate to first page
  navigateTo(NAV[ROLE][0].id);
});

async function resolveEntityId() {
  try {
    if (ROLE === 'hod') {
      ENTITY_ID = USER_ID;
      localStorage.setItem('userName', 'HOD Admin');
    } else if (ROLE === 'mentor') {
      const data = await API.get('/auth/me');
      ENTITY_ID = data.entity_id;
      localStorage.setItem('userName', data.name);
      if (data.staff_id) localStorage.setItem('staff_id', data.staff_id);
    } else if (ROLE === 'advisor') {
      const data = await API.get('/auth/me');
      ENTITY_ID = data.entity_id;
      localStorage.setItem('userName', data.name);
      if (data.staff_id) localStorage.setItem('staff_id', data.staff_id);
      if (data.year)     localStorage.setItem('my_year', data.year);
      if (data.section)  localStorage.setItem('my_section', data.section);
    } else if (ROLE === 'student') {
      const data = await API.get('/auth/me');
      ENTITY_ID = data.entity_id;
      localStorage.setItem('userName', data.name);
    }
    document.getElementById('tbName').textContent = localStorage.getItem('userName') || '';
    document.getElementById('tbAvatar').textContent = ini(localStorage.getItem('userName') || 'U');
  } catch (e) {
    console.error('resolveEntityId failed', e);
    // fallback: navigate anyway
  }
}

function buildSidebar() {
  const items = NAV[ROLE] || [];
  document.getElementById('sidebar').innerHTML =
    items.map(n => `<div class="nav-item" id="nav-${n.id}" onclick="navigateTo('${n.id}')"><span class="nav-icon">${n.icon}</span><span>${n.label}</span></div>`).join('');
}

function navigateTo(page) {
  currentPage = page;
  document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
  const navEl = document.getElementById('nav-' + page);
  if (navEl) navEl.classList.add('active');
  destroyAllCharts();
  if (chatWS) { chatWS.close(); chatWS = null; }
  renderPage(page);
}

function destroyAllCharts() {
  Object.keys(chartRefs).forEach(k => { if (chartRefs[k]) { chartRefs[k].destroy(); delete chartRefs[k]; } });
}

async function renderPage(page) {
  const el = document.getElementById('content');
  el.innerHTML = `<div style="display:flex;align-items:center;justify-content:center;height:60vh"><div class="spinner"></div></div>`;
  try {
    const html = await PAGE_RENDERERS[page]();
    el.innerHTML = html;
    if (POST_RENDER[page]) await POST_RENDER[page]();
  } catch (e) {
    el.innerHTML = `<div class="card"><div style="color:var(--red);font-size:13px">⚠ Error loading page: ${e?.detail || e?.message || JSON.stringify(e)}</div></div>`;
    console.error(e);
  }
}

function doLogout() {
  localStorage.clear();
  window.location.href = 'index.html';
}

// ══════════════════════════════════════════════════════
// PAGE RENDERERS
// ══════════════════════════════════════════════════════
const PAGE_RENDERERS = {
  
  // ── HOD: OVERVIEW ─────────────────────────────────
  async hod_overview() {
  const [students, mentors, advisors, absences, certs] = await Promise.all([
    API.getHodStudents().catch(() => []),
    API.getHodMentors().catch(() => []),
    API.getHodAdvisors().catch(() => []),
    API.getAbsences().catch(() => []),
    API.getHodCerts().catch(() => []),
  ]);
  const leaveReqs = [];

  const today = new Date().toISOString().split('T')[0];
  const abToday = absences.filter(a => a.date === today);
  const low = students.filter(s => s.attendance_pct < 75);
  const critical = students.filter(s => s.attendance_pct < 60);
  const atRisk = students.filter(s => s.attendance_pct >= 60 && s.attendance_pct < 75);
  const regular = students.filter(s => s.attendance_pct >= 75);
  const avgCgpa = students.length
    ? (students.reduce((a, s) => a + (s.cgpa || 0), 0) / students.length).toFixed(2)
    : '—';
  const pendingLeaves = Array.isArray(leaveReqs) ? leaveReqs.filter(r => r.status === 'pending').length : 0;

  // Group students by year
  const yr2 = students.filter(s => s.year == 2);
  const yr3 = students.filter(s => s.year == 3);
  const yr4 = students.filter(s => s.year == 4);

  // Section counts for stacked bar
  const yrSecCount = (yr, sec) => students.filter(s => s.year == yr && s.section === sec).length;

  // CGPA buckets
  const cgpaBuckets = [0, 0, 0, 0]; // 6-7, 7-8, 8-9, 9-10
  students.forEach(s => {
    const c = parseFloat(s.cgpa || 0);
    if (c >= 9) cgpaBuckets[3]++;
    else if (c >= 8) cgpaBuckets[2]++;
    else if (c >= 7) cgpaBuckets[1]++;
    else cgpaBuckets[0]++;
  });

  // Certificate types
  const certTypes = {};
  certs.forEach(c => { certTypes[c.type] = (certTypes[c.type] || 0) + 1; });
  const certLabels = Object.keys(certTypes);
  const certData   = Object.values(certTypes);
  const certColors = ['#185FA5','#1D9E75','#EF9F27','#534AB7','#E24B4A','#1D9E75'];

  // Section attendance averages
  const secAvg = (yr, sec) => {
    const grp = students.filter(s => s.year == yr && s.section === sec);
    if (!grp.length) return null;
    return Math.round(grp.reduce((a, s) => a + (s.attendance_pct || 0), 0) / grp.length);
  };
  const secRows = [
    { label: 'Yr2 Sec A', pct: secAvg(2,'A') },
    { label: 'Yr2 Sec B', pct: secAvg(2,'B') },
    { label: 'Yr2 Sec C', pct: secAvg(2,'C') },
    { label: 'Yr3 Sec A', pct: secAvg(3,'A') },
    { label: 'Yr3 Sec B', pct: secAvg(3,'B') },
    { label: 'Yr3 Sec C', pct: secAvg(3,'C') },
    { label: 'Yr4 Sec A', pct: secAvg(4,'A') },
    { label: 'Yr4 Sec B', pct: secAvg(4,'B') },
    { label: 'Yr4 Sec C', pct: secAvg(4,'C') },
  ].filter(r => r.pct !== null);

  const barColor = p => p >= 75 ? '#1D9E75' : p >= 60 ? '#EF9F27' : '#E24B4A';

  return `
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.25rem">
      <div class="page-title" style="margin-bottom:0">Dashboard Overview</div>
      <div style="display:flex;align-items:center;gap:10px">
        <span style="font-size:12px;color:var(--gray-500)">Academic Year 2025–26</span>
        <button class="btn btn-s btn-sm" onclick="exportHodPDF()">📄 Export PDF</button>
        <button class="btn btn-danger btn-sm" onclick="openPromotion()">🎓 Year Promotion / Passout</button>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:14px">
      <div class="stat-card"><div class="stat-label">Total Students</div><div class="stat-val">${students.length}</div><div class="stat-sub">Yr 2, 3, 4</div></div>
      <div class="stat-card"><div class="stat-label">Mentors</div><div class="stat-val">${mentors.length}</div></div>
      <div class="stat-card"><div class="stat-label">Low Attendance</div><div class="stat-val" style="color:#E24B4A">${low.length}</div><div class="stat-sub">Below 75%</div></div>
      <div class="stat-card"><div class="stat-label">Absent Today</div><div class="stat-val" style="color:#EF9F27">${abToday.length}</div></div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:1.25rem">
      <div class="stat-card"><div class="stat-label">Certificates</div><div class="stat-val">${certs.length}</div></div>
      <div class="stat-card"><div class="stat-label">Avg CGPA</div><div class="stat-val">${avgCgpa}</div></div>
      <div class="stat-card"><div class="stat-label">Leave Requests</div><div class="stat-val" style="color:#EF9F27">${pendingLeaves}</div><div class="stat-sub">Pending</div></div>
      <div class="stat-card"><div class="stat-label">Class Advisors</div><div class="stat-val">${advisors.length}</div></div>
    </div>

    <div class="two-col" style="margin-bottom:14px">
      <div class="card">
        <div style="font-size:12px;font-weight:600;color:var(--gray-500);text-transform:uppercase;letter-spacing:.05em;margin-bottom:10px">Attendance distribution</div>
        <div style="display:flex;flex-wrap:wrap;gap:12px;margin-bottom:10px;font-size:12px;color:var(--gray-500)">
          <span style="display:flex;align-items:center;gap:4px"><span style="width:10px;height:10px;border-radius:2px;background:#1D9E75;display:inline-block"></span>Regular (≥75%): ${regular.length}</span>
          <span style="display:flex;align-items:center;gap:4px"><span style="width:10px;height:10px;border-radius:2px;background:#EF9F27;display:inline-block"></span>At risk (60–74%): ${atRisk.length}</span>
          <span style="display:flex;align-items:center;gap:4px"><span style="width:10px;height:10px;border-radius:2px;background:#E24B4A;display:inline-block"></span>Critical (<60%): ${critical.length}</span>
        </div>
        <div style="position:relative;height:180px"><canvas id="ovAttnChart"></canvas></div>
      </div>

      <div class="card">
        <div style="font-size:12px;font-weight:600;color:var(--gray-500);text-transform:uppercase;letter-spacing:.05em;margin-bottom:10px">Students by year</div>
        <div style="display:flex;flex-wrap:wrap;gap:10px;margin-bottom:10px;font-size:12px;color:var(--gray-500)">
          <span style="display:flex;align-items:center;gap:4px"><span style="width:10px;height:10px;border-radius:2px;background:#185FA5;display:inline-block"></span>Section A</span>
          <span style="display:flex;align-items:center;gap:4px"><span style="width:10px;height:10px;border-radius:2px;background:#85B7EB;display:inline-block"></span>Section B</span>
          <span style="display:flex;align-items:center;gap:4px"><span style="width:10px;height:10px;border-radius:2px;background:#B5D4F4;display:inline-block"></span>Section C</span>
        </div>
        <div style="position:relative;height:180px"><canvas id="ovYearChart"></canvas></div>
      </div>
    </div>

    <div class="two-col" style="margin-bottom:14px">
      <div class="card">
        <div style="font-size:12px;font-weight:600;color:var(--gray-500);text-transform:uppercase;letter-spacing:.05em;margin-bottom:10px">CGPA distribution</div>
        <div style="position:relative;height:180px"><canvas id="ovCgpaChart"></canvas></div>
      </div>

      <div class="card">
        <div style="font-size:12px;font-weight:600;color:var(--gray-500);text-transform:uppercase;letter-spacing:.05em;margin-bottom:12px">Avg attendance by section</div>
        ${secRows.map(r => `
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
            <div style="font-size:12px;width:76px;flex-shrink:0;color:var(--gray-500)">${r.label}</div>
            <div style="flex:1;background:var(--gray-100);border-radius:20px;height:7px;overflow:hidden">
              <div style="height:100%;border-radius:20px;width:${r.pct}%;background:${barColor(r.pct)}"></div>
            </div>
            <div style="font-size:12px;width:36px;text-align:right;font-weight:600;color:${barColor(r.pct)}">${r.pct}%</div>
          </div>`).join('')}
      </div>
    </div>

    <div class="two-col">
      <div class="card">
        <div style="font-size:12px;font-weight:600;color:var(--gray-500);text-transform:uppercase;letter-spacing:.05em;margin-bottom:12px">Low attendance alerts</div>
        ${low.slice(0, 8).map(s => `
          <div style="display:flex;align-items:flex-start;gap:8px;padding:6px 0;border-bottom:0.5px solid var(--gray-100)">
            <div style="width:7px;height:7px;border-radius:50%;margin-top:4px;flex-shrink:0;background:${s.attendance_pct < 60 ? '#E24B4A' : '#EF9F27'}"></div>
            <div style="font-size:12px;color:var(--gray-500)">
              <strong style="color:var(--gray-900)">${s.name}</strong> — ${s.roll_no || '—'} — Yr${s.year}${s.section} —
              <span style="font-weight:600;color:${s.attendance_pct < 60 ? '#E24B4A' : '#EF9F27'}">${s.attendance_pct}%</span>
            </div>
          </div>`).join('') || '<div style="font-size:13px;color:var(--gray-500);padding:1rem 0;text-align:center">No low attendance alerts</div>'}
      </div>

      <div class="card">
        <div style="font-size:12px;font-weight:600;color:var(--gray-500);text-transform:uppercase;letter-spacing:.05em;margin-bottom:10px">Certificate uploads by type</div>
        ${certLabels.length ? `
          <div style="display:flex;flex-wrap:wrap;gap:10px;margin-bottom:10px;font-size:12px;color:var(--gray-500)">
            ${certLabels.map((l, i) => `<span style="display:flex;align-items:center;gap:4px"><span style="width:10px;height:10px;border-radius:2px;background:${certColors[i]||'#888'};display:inline-block"></span>${l}: ${certData[i]}</span>`).join('')}
          </div>
          <div style="position:relative;height:180px"><canvas id="ovCertChart"></canvas></div>` :
          `<div style="font-size:13px;color:var(--gray-500);padding:2rem 0;text-align:center">No certificates uploaded yet</div>`}
      </div>
    </div>`;
},

  // ── HOD: STUDENTS ─────────────────────────────────
  async hod_students() {
    const students = await API.getHodStudents();
    return `
      <div class="page-header"><div class="page-title">All Students</div></div>
      <div class="frow">
        <select id="fYear" onchange="filterStudents()"><option value="">All Years</option><option value="2">Year 2</option><option value="3">Year 3</option><option value="4">Year 4</option></select>
        <select id="fSec" onchange="filterStudents()"><option value="">All Sections</option><option>A</option><option>B</option><option>C</option></select>
        <select id="fAttn" onchange="filterStudents()"><option value="">All Attendance</option><option value="low">Below 75%</option><option value="vlow">Below 60%</option></select>
        <input type="text" id="fSearch" placeholder="Search name or roll no…" oninput="filterStudents()" style="min-width:180px">
      </div>
      <div class="card" style="padding:0">
        <div class="table-wrap">
          <table>
            <thead><tr><th>Name</th><th>Roll No</th><th>Yr/Sec</th><th>CGPA</th><th>Attendance</th><th>Mentor</th><th></th></tr></thead>
            <tbody id="stuTbody">${renderStuRows(students)}</tbody>
          </table>
        </div>
      </div>`;
  },

  // ── HOD: MENTORS ──────────────────────────────────
  async hod_mentors() {
    const mentors = await API.getHodMentors();
    return `
      <div class="page-header">
        <div class="page-title">Mentors</div>
        <button class="btn btn-p" onclick="om('mAddMentor')">+ Add Mentor</button>
      </div>
      <div class="card" style="padding:0">
        <div class="table-wrap">
          <table>
            <thead><tr><th>Mentor</th><th>Email</th><th>Dept</th><th>Mentees</th><th>Low Attn</th><th>Actions</th></tr></thead>
            <tbody>
            ${mentors.map(m => `
              <tr>
                <td><div class="flex-center">${avatarEl(m.name,'#EEEDFE','#534AB7',28)} ${m.name}</div></td>
                <td class="text-muted text-sm">${m.email}</td>
                <td>${m.department}</td>
                <td>${m.mentee_count}</td>
                <td>${m.low_attendance > 0 ? `<span style="color:var(--red);font-weight:700">${m.low_attendance}</span>` : '<span style="color:var(--green)">0</span>'}</td>
                <td>
                  <div class="flex-center">
                    <button class="btn btn-s btn-xs" onclick="showMentorProfile(${m.id})">View</button>
                    <button class="btn btn-p btn-xs" onclick="openAssign(${m.id},'${m.name}')">Assign</button>
                    <button class="btn btn-danger btn-xs" onclick="deleteMentor(${m.id},'${m.name}')">Remove</button>
                  </div>
                </td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>`;
  },

  // ── HOD: ADVISORS ─────────────────────────────────
  async hod_advisors() {
    const advisors = await API.getHodAdvisors();
    // Check for idle students (advisor_id = null) via the students endpoint
    const allStudents = await API.getHodStudents();
    const idleStudents = allStudents.filter(s => s.advisor_id === null || s.advisor_id === undefined);
    // Group idle by year-section for display
    const idleMap = {};
    idleStudents.forEach(s => {
      const k = `Yr${s.year} Sec ${s.section}`;
      if (!idleMap[k]) idleMap[k] = 0;
      idleMap[k]++;
    });
    const idleKeys = Object.keys(idleMap);
    return `
      <div class="page-header">
        <div class="page-title">Class Advisors</div>
        <button class="btn btn-p" onclick="openAdvisorModal()">+ Add Advisor</button>
      </div>
      ${idleKeys.length > 0 ? `
        <div style="background:#FAEEDA;border:1px solid #FAC775;border-radius:8px;padding:10px 14px;margin-bottom:1rem;font-size:13px;color:#633806">
          <strong>⚠ ${idleStudents.length} student(s) have no class advisor:</strong>
          ${idleKeys.map(k => `<span style="margin-left:8px">${k}: ${idleMap[k]} student(s)</span>`).join(' |')}
          <span style="margin-left:8px">— Add an advisor for their class to auto-assign them.</span>
        </div>` : ''}
      <div class="card" style="padding:0">
        <div class="table-wrap">
          <table>
            <thead><tr><th>Advisor</th><th>Email</th><th>Year</th><th>Section</th><th>Students</th><th>Actions</th></tr></thead>
            <tbody>
            ${advisors.map(a => `
              <tr>
                <td><div class="flex-center">${avatarEl(a.name,'#E1F5EE','#085041',28)} ${a.name}</div></td>
                <td class="text-muted text-sm">${a.email}</td>
                <td>Year ${a.year}</td>
                <td>Section ${a.section}</td>
                <td>${a.student_count}</td>
                <td>
                  <div class="flex-center">
                    <button class="btn btn-s btn-xs" onclick="openAdvisorModal(${a.id},'${a.name}','${a.email}',${a.year},'${a.section}')">Change Role</button>
                    <button class="btn btn-danger btn-xs" onclick="deleteAdvisor(${a.id},'${a.name}')">Remove</button>
                  </div>
                </td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>`;
  },

  // ── HOD: ATTENDANCE ───────────────────────────────
  async hod_attendance() {
    return `
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;flex-wrap:wrap;gap:8px">
        <div class="page-title" style="margin-bottom:0">Attendance</div>
        <button class="btn btn-p" onclick="openLockManager()" style="font-size:13px;padding:8px 16px">🔒 Lock Manager</button>
      </div>
      <div class="tab-bar">
        <div class="tab active" onclick="switchTab('yearwise',this)">Year-wise / Class-wise</div>
        <div class="tab" onclick="switchTab('absences',this)">Recent Absences</div>
      </div>
      <div id="tab-yearwise" class="tab-panel active">
        <div class="frow">
          <select id="aYear" onchange="loadYearWise()"><option value="">All Years</option><option value="2">Year 2</option><option value="3">Year 3</option><option value="4">Year 4</option></select>
          <select id="aSec" onchange="loadYearWise()"><option value="">All Sections</option><option>A</option><option>B</option><option>C</option></select>
        </div>
        <div id="yearwiseContent"><div class="spinner"></div></div>
      </div>
      <div id="tab-absences" class="tab-panel">
        <div class="frow">
          <select id="abYear"><option value="">All Years</option><option value="2">Year 2</option><option value="3">Year 3</option><option value="4">Year 4</option></select>
          <select id="abSec"><option value="">All Sections</option><option>A</option><option>B</option><option>C</option></select>
          <input type="text" id="abSearch" placeholder="Search…" style="min-width:140px">
          <button class="btn btn-s btn-sm" onclick="loadAbsences()">Filter</button>
        </div>
        <div id="absencesContent"><div class="spinner"></div></div>
      </div>`;
  },

  // ── HOD: CERTIFICATES ─────────────────────────────
  async hod_certs() {
    const certs = await API.getHodCerts();
    return `
      <div class="page-title">Certificates</div>
      <div class="card" style="padding:0">
        <div class="table-wrap">
          <table>
            <thead><tr><th>Student</th><th>Certificate</th><th>Type</th><th>Issuer</th><th>Date</th><th>Action</th></tr></thead>
            <tbody>
            ${certs.length ? certs.map(c => `
              <tr>
                <td class="fw-600">${c.student}</td>
                <td>${c.title}</td>
                <td>${pill(c.type, 'purple')}</td>
                <td class="text-muted text-sm">${c.issuer || '—'}</td>
                <td class="text-sm">${formatDate(c.date)}</td>
                <td><button class="btn btn-s btn-xs" onclick="fakeDownload('${c.file_path || c.title}')">⬇ Download</button></td>
              </tr>`).join('') : `<tr><td colspan="6">${emptyState('🏅', 'No certificates uploaded yet')}</td></tr>`}
            </tbody>
          </table>
        </div>
      </div>`;
  },
  async hod_promotion() {
    return `
      <div class="page-title">Year Promotion &amp; Passout</div>
      <div class="card">
        <div class="card-title">Academic Year Rollover</div>
        <p style="font-size:13px;color:var(--gray-700);margin-bottom:1rem;line-height:1.8">
          Use this at the <strong>end of every academic year</strong> to roll over all students.<br>
          <br>
          • All <strong>4th year students</strong> are marked as passed out — an Excel report is auto-downloaded<br>
          • <strong>3rd year → 4th year</strong> and <strong>2nd year → 3rd year</strong> automatically<br>
          • Promoted students are detached from their current class advisors<br>
          &nbsp;&nbsp;(Go to Advisors page after promotion to reassign)<br>
          • <strong>Mentor assignments are kept unchanged</strong><br>
          • 2nd year becomes empty — Class Advisors can add new incoming students
        </p>
        <div style="background:#FCEBEB;border:1px solid #F7C1C1;border-radius:8px;padding:10px 14px;margin-bottom:1rem;font-size:13px;color:#791F1F">
          ⚠ This action is permanent. Always take a database backup before proceeding.
        </div>
        <button
          class="btn btn-danger"
          style="font-size:14px;padding:10px 22px"
          onclick="openPromotion()">
          🎓 Start Year Promotion
        </button>
      </div>`;
  },
  // ── ADVISOR: MY CLASS ─────────────────────────────
  async adv_class() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';
    const students = await API.getMyClass(ENTITY_ID);
    const avg = students.length ? Math.round(students.reduce((s, x) => s + (x.attendance_pct || 0), 0) / students.length) : 0;
    const low = students.filter(s => s.attendance_pct < 75).length;
    return `
      <div class="page-header">
        <div class="page-title">My Class</div>
        <div class="flex-center">
          <button class="btn btn-s btn-sm" onclick="om('mAddStudent')">+ Add Student</button>
          <button class="btn btn-p btn-sm" onclick="openAttendanceModal()">📋 Mark Attendance</button>
        </div>
      </div>
      <div class="stat-grid">
        <div class="stat-card"><div class="stat-label">Total Students</div><div class="stat-val">${students.length}</div></div>
        <div class="stat-card"><div class="stat-label">Avg Attendance</div><div class="stat-val">${avg}%</div></div>
        <div class="stat-card"><div class="stat-label">Low Attendance</div><div class="stat-val" style="color:var(--red)">${low}</div></div>
      </div>
      <div class="card" style="padding:0">
        <div class="table-wrap">
          <table>
            <thead><tr><th>Name</th><th>Roll No</th><th>CGPA</th><th>Attendance</th><th></th></tr></thead>
            <tbody>
            ${students.map(s => `
              <tr>
                <td><div class="flex-center">${avatarEl(s.name,'#FAEEDA','#633806',26)} ${s.name}</div></td>
                <td class="text-muted">${s.roll_no || '—'}</td>
                <td>${s.cgpa || '—'}</td>
                <td>${attnPill(s.attendance_pct)}${attnBar(s.attendance_pct)}</td>
                <td><button class="btn btn-s btn-xs" onclick="showStudentProfileModal(${s.id})">Profile</button></td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>`;
  },

  // ── ADVISOR: ATTENDANCE ───────────────────────────
  async adv_attend() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';
    const students = await API.getMyClass(ENTITY_ID);
    const recentAbs = students.filter(s => s.attendance_pct < 100);
    return `
      <div class="page-title">Attendance Management</div>
      <div class="card">
        <div class="card-title">Mark Daily Attendance</div>
        <button class="btn btn-p" onclick="openAttendanceModal()">📋 Mark / Upload Attendance</button>
        <p class="text-sm text-muted" style="margin-top:8px">Absences are instantly visible to mentors and HOD.</p>
      </div>
      <div class="card">
        <div class="card-title">Students with Absences</div>
        ${recentAbs.length ? `
          <div class="table-wrap"><table>
            <thead><tr><th>Name</th><th>Roll No</th><th>Attendance %</th></tr></thead>
            <tbody>${recentAbs.map(s => `
              <tr>
                <td>${s.name}</td><td class="text-muted">${s.roll_no}</td>
                <td>${attnPill(s.attendance_pct)}${attnBar(s.attendance_pct)}</td>
              </tr>`).join('')}
            </tbody>
          </table></div>` : emptyState('✅', 'All students have full attendance')}
      </div>`;
  },

  // ── ADVISOR: PERIOD ATTENDANCE (STAFF MARKS) ─────
  async adv_period_attend() {
    const staffId = localStorage.getItem('staff_id');
    if (!staffId) return '<div class="card"><p style="color:var(--red);font-size:13px">⚠ No staff record linked to your account. Ask HOD to add you as staff in Timetable settings.</p></div>';

    const dates = [];
    for (let i = 0; i <= 3; i++) {
      const d = new Date(); d.setDate(d.getDate() - i);
      dates.push(d.toISOString().split('T')[0]);
    }
    const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    const dateOptions = dates.map((d, i) => {
      const dayName = days[new Date(d + 'T00:00:00').getDay()];
      return '<option value="' + d + '">' + (i === 0 ? 'Today' : dayName) + ' — ' + formatDate(d) + '</option>';
    }).join('');

    return '<div class="page-title">Period Attendance</div>' +
      '<div class="card" style="margin-bottom:14px;background:#E6F1FB;border-color:#185FA5">' +
        '<p style="font-size:13px;color:#0C447C;margin:0">📋 Select a date — your scheduled periods for that day will load automatically.</p>' +
      '</div>' +
      '<div class="card" style="margin-bottom:14px">' +
        '<div class="card-title">Select Date</div>' +
        '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">' +
          '<select id="paDate" onchange="paLoadDaySlots()" style="min-width:220px;padding:8px 10px;border-radius:6px;border:1px solid var(--gray-200);font-size:13px">' +
            dateOptions +
          '</select>' +
          '<span style="font-size:12px;color:var(--gray-400)">Your periods for that day load automatically</span>' +
        '</div>' +
      '</div>' +
      '<div id="paStudentList"><div class="card" style="text-align:center;padding:2rem;color:var(--gray-400)">👆 Select a date above to see your scheduled periods</div></div>';
  },

  async adv_period_report() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';

    // Build last 7 weekdays as options
    const dayNames = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    const dates = [];
    for (let i = 0; i <= 14 && dates.length < 7; i++) {
      const d = new Date(); d.setDate(d.getDate() - i);
      const dn = dayNames[d.getDay()];
      if (dn !== 'Saturday' && dn !== 'Sunday') {
        dates.push({
          val: d.toISOString().split('T')[0],
          label: (i === 0 ? 'Today' : dn) + ' — ' + formatDate(d.toISOString().split('T')[0])
        });
      }
    }
    const dateOptions = dates.map((d, i) =>
      '<option value="' + d.val + '"' + (i === 0 ? ' selected' : '') + '>' + d.label + '</option>'
    ).join('');

    return '<div class="page-title">Period Report</div>' +
      '<div class="card" style="margin-bottom:14px">' +
        '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">' +
          '<label style="font-size:13px;font-weight:600;color:var(--gray-700)">📅 Select Day:</label>' +
          '<select id="prDatePicker" onchange="prLoadReport()" style="min-width:220px;padding:8px 10px;border-radius:6px;border:1px solid var(--gray-200);font-size:13px">' +
            dateOptions +
          '</select>' +
        '</div>' +
      '</div>' +
      '<div id="prTableArea"><div class="card" style="text-align:center;padding:2rem"><div class="spinner"></div></div></div>';
  },

  // ── ADVISOR: PERIOD PERMISSIONS ──────────────────────────
  async adv_leave() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';
    const reqs = await API.getLeaveReqs(ENTITY_ID);
    const pending = reqs.filter(r => r.status === 'pending');
    const resolved = reqs.filter(r => r.status !== 'pending');
    return `
      <div class="page-title">Student Permission Requests</div>
      <div class="card">
        <div class="card-title">⏳ Pending Requests (${pending.length})</div>
        ${pending.length ? pending.map(r => `
          <div class="leave-item">
            <div class="leave-hdr">
              <div class="leave-name">${r.student} ${pill(r.type, r.type === 'Leave' ? 'amber' : 'blue')}</div>
              <div class="leave-dates">${formatDate(r.from)} → ${formatDate(r.to)}</div>
            </div>
            <div class="leave-reason">${r.reason}</div>
            <div class="leave-actions">
              <button class="btn btn-green btn-sm" onclick="resolveLeave(${r.id},'accepted')">✓ Accept (auto-marks present)</button>
              <button class="btn btn-danger btn-sm" onclick="resolveLeave(${r.id},'declined')">✕ Decline</button>
            </div>
          </div>`).join('') : emptyState('📝', 'No pending requests')}
      </div>
      ${resolved.length ? `
        <div class="card">
          <div class="card-title">Resolved Requests</div>
          <div class="table-wrap"><table>
            <thead><tr><th>Student</th><th>Type</th><th>Dates</th><th>Status</th></tr></thead>
            <tbody>${resolved.map(r => `
              <tr>
                <td>${r.student}</td>
                <td>${pill(r.type, 'blue')}</td>
                <td class="text-sm">${formatDate(r.from)} → ${formatDate(r.to)}</td>
                <td>${pill(r.status, r.status === 'accepted' ? 'green' : 'red')}</td>
              </tr>`).join('')}
            </tbody>
          </table></div>
        </div>` : ''}`;
  },

  // ── ADVISOR: STUDENT PROFILES ─────────────────────
  async adv_students() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';
    const students = await API.getMyClass(ENTITY_ID);
    return `
      <div class="page-title">Student Profiles</div>
      <div class="student-card-grid">
        ${students.map(s => `
          <div class="student-card" onclick="showStudentProfileModal(${s.id})">
            <div class="flex-center" style="margin-bottom:10px">
              ${avatarEl(s.name,'#FAEEDA','#633806',38)}
              <div><div class="fw-600">${s.name}</div><div class="text-xs text-muted">${s.roll_no || '—'}</div></div>
            </div>
            <div class="flex-center" style="justify-content:space-between">
              <span class="text-sm">CGPA: <strong>${s.cgpa || '—'}</strong></span>
              ${attnPill(s.attendance_pct)}
            </div>
          </div>`).join('')}
      </div>`;
  },

  // ── ADVISOR: ALERTS ───────────────────────────────
  async adv_alerts() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';
    const students = await API.getMyClass(ENTITY_ID);
    const low = students.filter(s => s.attendance_pct < 75);
    return `
      <div class="page-title">Alerts</div>
      <div class="card">
        <div class="card-title">⚠ Low Attendance</div>
        ${low.map(s => `<div class="alert-item"><div class="alert-dot"></div><div class="alert-text"><strong>${s.name}</strong> — ${s.roll_no} — ${s.attendance_pct}% attendance</div></div>`).join('') || emptyState('✅', 'No low attendance alerts')}
      </div>`;
  },

  // ── MENTOR: MENTEES ───────────────────────────────
  async ment_mentees() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';
    const mentees = await API.getMentees(ENTITY_ID);
    const absentToday = mentees.filter(m => m.absent_today);
    const low = mentees.filter(m => m.attendance_pct < 75);
    const avg = mentees.length ? Math.round(mentees.reduce((s, m) => s + (m.attendance_pct || 0), 0) / mentees.length) : 0;
    return `
      <div class="page-title">My Mentees</div>
      <div class="stat-grid">
        <div class="stat-card"><div class="stat-label">Total Mentees</div><div class="stat-val">${mentees.length}</div></div>
        <div class="stat-card"><div class="stat-label">Avg Attendance</div><div class="stat-val">${avg}%</div></div>
        <div class="stat-card"><div class="stat-label">Absent Today</div><div class="stat-val" style="color:var(--amber)">${absentToday.length}</div></div>
        <div class="stat-card"><div class="stat-label">Low Attendance</div><div class="stat-val" style="color:var(--red)">${low.length}</div></div>
      </div>
      <div class="card" style="padding:0">
        <div class="table-wrap">
          <table>
            <thead><tr><th>Name</th><th>Roll No</th><th>Yr/Sec</th><th>CGPA</th><th>Attendance</th><th></th></tr></thead>
            <tbody>
            ${mentees.map(s => `
              <tr>
                <td>
                  <div class="flex-center">
                    ${avatarEl(s.name,'#FAEEDA','#633806',26)} ${s.name}
                    ${s.absent_today ? ' ' + pill('Absent Today','amber') : ''}
                  </div>
                </td>
                <td class="text-muted">${s.roll_no || '—'}</td>
                <td>${pill('Yr' + s.year + ' ' + s.section, 'gray')}</td>
                <td>${s.cgpa}</td>
                <td>${attnPill(s.attendance_pct)}${attnBar(s.attendance_pct)}</td>
                <td><button class="btn btn-s btn-xs" onclick="showStudentProfileModal(${s.id})">Profile</button></td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>`;
  },

  // ── MENTOR: CERTIFICATES ──────────────────────────
  async ment_certs() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';
    const certs = await API.getMentorCerts(ENTITY_ID);
    return `
      <div class="page-title">Mentee Certificates</div>
      <div class="card">
        ${certs.length ? certs.map(c => `
          <div class="cert-item">
            <div class="cert-icon">🏅</div>
            <div style="flex:1">
              <div class="cert-name">${c.title}</div>
              <div class="cert-meta">${c.student} · ${c.type} · ${c.issuer || ''} · ${formatDate(c.date)}</div>
            </div>
            ${pill(c.type, 'purple')}
            <button class="btn btn-s btn-xs" style="margin-left:8px" onclick="fakeDownload('${c.file_path || c.title}')">⬇</button>
          </div>`).join('') : emptyState('🏅', 'No certificates uploaded by mentees yet')}
      </div>`;
  },

  // ── MENTOR: ANNOUNCEMENTS ─────────────────────────
  async ment_announce() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';
    const anns = await API.getAnnouncements(ENTITY_ID);
    return `
      <div class="page-header">
        <div class="page-title">Announcements</div>
        <button class="btn btn-p" onclick="om('mAnnounce')">+ New Announcement</button>
      </div>
      <div class="card">
        <div class="card-title">Sent Announcements</div>
        ${anns.length ? anns.map(a => `
          <div class="ann-item">
            <div class="ann-title">${a.title}</div>
            <div class="ann-meta">📅 ${formatDate(a.date)} · Sent to all mentees</div>
            <div class="ann-body">${a.body}</div>
          </div>`).join('') : emptyState('📢', 'No announcements sent yet')}
      </div>`;
  },
  // ── MENTOR: STUDENT TIMELINE ──────────────────────
  async ment_timeline() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';
    const mentees = await API.getMentees(ENTITY_ID).catch(() => []);
    const certs   = await API.getMentorCerts(ENTITY_ID).catch(() => []);

    if (!mentees.length) return `
      <div class="page-title">Student Progress Timeline</div>
      ${emptyState('👥', 'No mentees assigned yet')}`;

    // Default selected = first mentee
    const firstId = mentees[0].id;

    const menteeOptions = mentees.map(m =>
      `<option value="${m.id}">${m.name} — ${m.roll_no || '—'}</option>`
    ).join('');

    return `
      <div class="page-header">
        <div class="page-title">Student Progress Timeline</div>
      </div>

      <div class="card" style="margin-bottom:14px">
        <div style="display:flex;align-items:center;gap:12px">
          <label style="font-size:13px;font-weight:600;color:var(--gray-600);white-space:nowrap">Select Student:</label>
          <select id="timelineSelect" class="w-full"
            style="padding:8px 12px;border:1px solid var(--gray-200);border-radius:8px;font-size:13px;max-width:340px"
            onchange="renderTimelineById()">
            ${menteeOptions}
          </select>
        </div>
      </div>

      <div id="timelineContent"></div>
    `;
  },
  // ── MENTOR: CHAT ──────────────────────────────────
  async ment_chat() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';
    return renderChatPage();
  },

  // ── MENTOR: ALERTS ────────────────────────────────
  async ment_alerts() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';
    const mentees = await API.getMentees(ENTITY_ID);
    const absentToday = mentees.filter(m => m.absent_today);
    const low = mentees.filter(m => m.attendance_pct < 75);
    return `
      <div class="page-title">Alerts</div>
      <div class="card">
        <div class="card-title">📅 Absent Today</div>
        ${absentToday.map(s => `<div class="alert-item"><div class="alert-dot"></div><div class="alert-text"><strong>${s.name}</strong> — ${s.roll_no} marked absent by class advisor</div></div>`).join('') || emptyState('✅', 'No absences today')}
      </div>
      <div class="card">
        <div class="card-title">⚠ Low Attendance (Below 75%)</div>
        ${low.map(s => `<div class="alert-item"><div class="alert-dot"></div><div class="alert-text"><strong>${s.name}</strong> — ${s.attendance_pct}% — requires intervention</div></div>`).join('') || emptyState('✅', 'No low attendance alerts')}
      </div>`;
  },

  // ── STUDENT: PROFILE ──────────────────────────────
  async stu_profile() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';
    const s = await API.getMyProfile(ENTITY_ID);
    const monthly   = (s.monthly_attendance && Object.keys(s.monthly_attendance).length) ? s.monthly_attendance : { Mar: { pct: s.attendance_pct, present: 0, total: 0 } };
    const months   = Object.keys(monthly);
    const vals     = months.map(m => typeof monthly[m] === 'object' ? monthly[m].pct : monthly[m]);
    const presents = months.map(m => typeof monthly[m] === 'object' ? monthly[m].present : 0);
    const totals   = months.map(m => typeof monthly[m] === 'object' ? monthly[m].total : 0);
    return `
      <div class="page-title">My Profile</div>
      <div class="two-col">
        <div>
          <div class="card">
            <div class="profile-hdr">
              <div class="profile-av" style="background:#FAEEDA;color:#633806">${ini(s.name)}</div>
              <div>
                <div class="profile-name">${s.name}</div>
                <div class="profile-meta">${s.roll_no || '—'} · Year ${s.year} · Section ${s.section}</div>
              </div>
            </div>
            <div class="info-grid">
              <div class="info-row"><div class="info-lbl">Email</div><div class="info-val text-sm">${s.email}</div></div>
              <div class="info-row"><div class="info-lbl">Phone</div><div class="info-val">${s.phone || '—'}</div></div>
              <div class="info-row"><div class="info-lbl">Date of Birth</div><div class="info-val">${formatDate(s.dob)}</div></div>
              <div class="info-row"><div class="info-lbl">CGPA</div><div class="info-val">${s.cgpa}</div></div>
              <div class="info-row"><div class="info-lbl">Backlogs</div><div class="info-val" style="color:${s.backlogs > 0 ? 'var(--red)' : 'var(--green)'}">${s.backlogs} ${s.backlogs > 0 ? '⚠' : ''}</div></div>
              <div class="info-row"><div class="info-lbl">Attendance</div><div class="info-val">${attnPill(s.attendance_pct)}</div></div>
              <div class="info-row"><div class="info-lbl">Mentor</div><div class="info-val text-sm">${s.mentor ? s.mentor.name : '—'}</div></div>
              <div class="info-row"><div class="info-lbl">Advisor</div><div class="info-val text-sm">${s.advisor ? s.advisor.name : '—'}</div></div>
            </div>
          </div>
          <div class="card">
            <div class="card-title">🏆 Achievements</div>
            ${s.achievements && s.achievements.length ? s.achievements.map(a => `<div style="padding:4px 0;font-size:13px">🏆 ${a}</div>`).join('') : emptyState('🏆', 'No achievements added')}
          </div>
          <div class="card">
            <div class="card-title">📄 Certificates</div>
            ${s.certificates && s.certificates.length ? s.certificates.map(c => `
              <div class="cert-item">
                <div class="cert-icon">🏅</div>
                <div><div class="cert-name">${c.title}</div><div class="cert-meta">${c.type}</div></div>
                ${pill(c.type, 'purple')}
              </div>`).join('') : emptyState('🏅', 'No certificates uploaded')}
          </div>
          </div>
          <div class="card">
            <div class="card-title">📊 Exam Marks</div>
            <div id="stuExamMarks"></div>
          </div>
        </div>
        </div>
        <div>
          <div class="card">
            <div class="card-title">Attendance Overview</div>
            <div class="pie-row" style="margin-bottom:16px">
              <div style="position:relative;width:110px;height:110px;flex-shrink:0">
                <canvas id="pieCv" width="110" height="110"></canvas>
              </div>
              <div class="pie-legend">
                <div class="legend-item"><div class="legend-dot" style="background:#1D9E75"></div>Present: ${s.attendance_pct}%</div>
                <div class="legend-item"><div class="legend-dot" style="background:#F09595"></div>Absent: ${100 - s.attendance_pct}%</div>
                <div style="margin-top:8px;font-size:12px;color:var(--gray-500)">Overall: ${s.attendance_pct >= 75 ? pill('Regular','green') : pill('Low Attendance','red')}</div>
              </div>
            </div>
            <div class="card-title" style="font-size:13px;margin-bottom:8px">Monthly Trend</div>
            <canvas id="lineCv" height="80"></canvas>
          </div>
          <div class="card">
            <div class="card-title">Month-wise Bar Chart</div>
            <canvas id="barCv" height="90"></canvas>
          </div>
        </div>
      </div>`;
  },

  // ── STUDENT: ATTENDANCE ───────────────────────────
  async stu_attend() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';
    const s = await API.getMyProfile(ENTITY_ID);
    const records = s.attendance_records || [];
    const absences = records.filter(r => r.status === 'absent');
    return `
      <div class="page-title">My Attendance</div>
      ${s.attendance_pct < 75 ? `<div class="card" style="background:var(--red-light);border-color:#f7c1c1;margin-bottom:1rem"><p style="color:#791F1F;font-size:13px;font-weight:600">⚠ Your attendance is below 75%. Please meet your mentor and class advisor immediately to discuss this.</p></div>` : ''}
      <div class="stat-grid">
        <div class="stat-card"><div class="stat-label">Overall Attendance</div><div class="stat-val" style="color:${s.attendance_pct >= 75 ? 'var(--green)' : 'var(--red)'}">${s.attendance_pct}%</div></div>
        <div class="stat-card"><div class="stat-label">Status</div><div class="stat-val">${s.attendance_pct >= 75 ? pill('Regular','green') : pill('Low','red')}</div></div>
        <div class="stat-card"><div class="stat-label">Total Absences</div><div class="stat-val">${absences.length}</div></div>
      </div>
      <div class="card">
        <div class="card-title">Absence Records</div>
        ${absences.length ? `
          <div class="table-wrap"><table>
            <thead><tr><th>Date</th><th>Status</th></tr></thead>
            <tbody>${absences.map(r => `<tr><td>${formatDate(r.date)}</td><td>${pill('Absent','red')}</td></tr>`).join('')}</tbody>
          </table></div>` : emptyState('📅', 'No absences on record')}
      </div>`;
  },

  // ── STUDENT: CERTIFICATES ─────────────────────────
  async stu_certs() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';
    const s = await API.getMyProfile(ENTITY_ID);
    const certs = s.certificates || [];
    return `
      <div class="page-header">
        <div class="page-title">My Certificates</div>
        <button class="btn btn-p" onclick="om('mUploadCert')">+ Upload Certificate</button>
      </div>
      <div class="card" style="background:var(--blue-light);border-color:var(--blue-mid);margin-bottom:1rem">
        <p class="text-sm" style="color:var(--blue-dark)">🔒 Certificates are visible only to you, your mentor, and the HOD.</p>
      </div>
      <div class="card">
        ${certs.length ? certs.map(c => `
          <div class="cert-item">
            <div class="cert-icon">🏅</div>
            <div style="flex:1">
              <div class="cert-name">${c.title}</div>
              <div class="cert-meta">${c.type} · ${c.issuer || ''} · ${formatDate(c.issue_date)}</div>
            </div>
            ${pill(c.type, 'purple')}
            ${c.file_path ? `<button class="btn btn-s btn-xs" onclick="fakeDownload('${c.file_path}')">⬇</button>` : ''}
          </div>`).join('') : emptyState('🏅', 'No certificates uploaded yet. Click "+ Upload Certificate" to add one.')}
      </div>`;
  },

  // ── STUDENT: ANNOUNCEMENTS ────────────────────────
  async stu_announce() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';
    const anns = await API.getMyAnnounce(ENTITY_ID);
    return `
      <div class="page-title">Announcements from Mentor</div>
      <div class="card">
        ${anns.length ? anns.map(a => `
          <div class="ann-item">
            <div class="ann-title">${a.title}</div>
            <div class="ann-meta">📅 ${formatDate(a.date)}</div>
            <div class="ann-body">${a.body}</div>
          </div>`).join('') : emptyState('📢', 'No announcements from your mentor yet')}
      </div>`;
  },

  // ── STUDENT: CHAT ─────────────────────────────────
  async stu_chat() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';
    return renderChatPage();
  },

  // ── STUDENT: LEAVE ────────────────────────────────
  async stu_leave() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';
    const reqs = await API.getMyLeaves(ENTITY_ID);
    return `
      <div class="page-header">
        <div class="page-title">Leave / On-Duty Requests</div>
        <button class="btn btn-p" onclick="om('mLeave')">+ New Request</button>
      </div>
      <div class="card">
        <div class="card-title">My Requests</div>
        ${reqs.length ? reqs.map(r => `
          <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--gray-100)">
            <div>
              <div class="fw-600">${r.type} — ${formatDate(r.from)} → ${formatDate(r.to)}</div>
              <div class="text-sm text-muted">${r.reason}</div>
            </div>
            ${pill(r.status, r.status === 'pending' ? 'amber' : r.status === 'accepted' ? 'green' : 'red')}
          </div>`).join('') : emptyState('📝', 'No leave or on-duty requests submitted yet')}
      </div>`;
  },
  // ── CALENDAR: HOD (add + view) ────────────────────
  async hod_calendar() {
    return calendarPageHTML(true);
  },

  // ── CALENDAR: ADVISOR (view only) ─────────────────
  async adv_calendar() {
    return calendarPageHTML(false);
  },

  // ── CALENDAR: MENTOR (view only) ──────────────────
  async ment_calendar() {
    return calendarPageHTML(false);
  },
  
  // ── CALENDAR: STUDENT (view only) ─────────────────
  async stu_calendar() {
    return calendarPageHTML(false);
  },
  
  // ── ADVISOR: EXAMINATION ──────────────────────────
  async adv_exam() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';
    const exams = await API.getExams(ENTITY_ID).catch(() => []);
    return `
      <div class="page-header">
        <div class="page-title">Examination</div>
        <button class="btn btn-p" onclick="openAddExamForm()">+ Add Examination</button>
      </div>

      <div id="addExamForm" style="display:none">
        <div class="card" style="margin-bottom:14px;border:2px solid #185FA5">
          <div style="font-size:13px;font-weight:700;color:#185FA5;margin-bottom:14px">New Examination</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
            <div>
              <label style="font-size:12px;font-weight:600;color:var(--gray-600);display:block;margin-bottom:4px">Examination Name *</label>
              <input id="examName" type="text" class="w-full" placeholder="e.g. Mid Semester Exam"
                style="padding:8px 10px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px;width:100%">
            </div>
            <div>
              <label style="font-size:12px;font-weight:600;color:var(--gray-600);display:block;margin-bottom:4px">Date Conducted *</label>
              <input id="examDate" type="date" class="w-full"
                style="padding:8px 10px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px;width:100%">
            </div>
          </div>
          <div style="margin-bottom:12px">
            <label style="font-size:12px;font-weight:600;color:var(--gray-600);display:block;margin-bottom:6px">Subjects *</label>
            <div id="subjectInputs">
              <div class="subject-input-row" style="display:flex;gap:8px;margin-bottom:6px">
                <input type="text" class="subj-name w-full" placeholder="Subject name e.g. Mathematics"
                  style="padding:8px 10px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px;flex:1">
                <button onclick="removeSubjectRow(this)" style="background:none;border:1px solid #E24B4A;color:#E24B4A;border-radius:6px;padding:4px 10px;cursor:pointer;font-size:13px">X</button>
              </div>
            </div>
            <button onclick="addSubjectRow()"
              style="background:none;border:1px dashed var(--gray-300);border-radius:6px;padding:6px 14px;cursor:pointer;font-size:12px;color:var(--gray-500);margin-top:4px">
              + Add Subject
            </button>
          </div>
          <div style="display:flex;gap:8px">
            <button class="btn btn-p" onclick="submitCreateExam()">Create Examination</button>
            <button class="btn btn-s" onclick="closeAddExamForm()">Cancel</button>
          </div>
        </div>
      </div>

      <div id="examList">
        ${exams.length ? exams.map(ex => `
          <div class="card" style="margin-bottom:12px">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;flex-wrap:wrap;gap:8px">
              <div>
                <div style="font-size:15px;font-weight:700;color:var(--gray-900)">${ex.name}</div>
                <div style="font-size:12px;color:var(--gray-500);margin-top:2px">
                  Conducted: ${formatDate(ex.conducted_on)} &nbsp;|&nbsp; ${ex.subjects.length} subject(s)
                </div>
              </div>
              <div style="display:flex;flex-direction:column;gap:6px;align-items:flex-end">
                <button class="btn btn-s btn-xs" onclick="openEditExam(${ex.id},'${ex.name}')">Edit</button>
                <button class="btn btn-danger btn-xs" onclick="deleteExamConfirm(${ex.id},'${ex.name}')">Delete</button>
              </div>
            </div>
            <div style="display:flex;flex-wrap:wrap;gap:8px">
              ${ex.subjects.map(sub => `
                <button onclick="openSubjectMarks(${ex.id},'${ex.name}',${sub.id},'${sub.name}')"
                  style="padding:8px 16px;background:#E6F1FB;color:#185FA5;border:none;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer"
                  onmouseover="this.style.background='#185FA5';this.style.color='#fff'"
                  onmouseout="this.style.background='#E6F1FB';this.style.color='#185FA5'">
                  ${sub.name}
                </button>`).join('')}
            </div>
          </div>`).join('')
        : '<div class=\"empty-state\"><div class=\"empty-icon\">📝</div>No examinations added yet. Click &quot;+ Add Examination&quot; to create one.</div>'}
      </div>

      <div id="marksPanel" style="display:none">
        <div class="card" style="border:2px solid #185FA5">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:8px">
            <div>
              <div id="marksPanelTitle" style="font-size:15px;font-weight:700;color:#185FA5"></div>
              <div id="marksPanelSub" style="font-size:12px;color:var(--gray-500);margin-top:2px"></div>
            </div>
            <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
              <button class="btn btn-s btn-xs" onclick="downloadMarksTemplate()">Download CSV Template</button>
              <input type="file" id="marksCsvInput" accept=".csv" style="font-size:11px;max-width:160px">
              <button class="btn btn-s btn-xs" onclick="applyMarksCsv()">Apply CSV</button>
              <button class="btn btn-s" onclick="closeMarksPanel()">Close</button>
            </div>
          </div>
          <div id="marksCsvFeedback" style="display:none;font-size:12px;padding:6px 10px;border-radius:6px;margin-bottom:10px"></div>
          <div id="marksTableWrap" style="overflow-x:auto">
            <div class="spinner" style="margin:1rem auto;display:block"></div>
          </div>
          <div style="display:flex;justify-content:flex-end;margin-top:14px">
            <button class="btn btn-p" onclick="saveMarks()">Save Marks</button>
          </div>
        </div>
      </div>`;
  },

  // ── HOD: TIMETABLE ────────────────────────────────
  async hod_timetable() {
    const [staff, subjects] = await Promise.all([
      API.getStaff().catch(() => []),
      API.getSubjects().catch(() => [])
    ]);
    return ttHodPageHTML(staff, subjects);
  },

  // ── ADVISOR: TIMETABLE ────────────────────────────
  async adv_timetable() {
    if (!ENTITY_ID) return '<div class="card">Loading...</div>';
    const advisor = await API.get('/auth/me').catch(() => null);
    return ttViewPageHTML('advisor');
  },

  // ── MENTOR: TIMETABLE ─────────────────────────────
  async ment_timetable() {
    return ttViewPageHTML('mentor');
  },

  async ment_period_attend() {
    const staffId = localStorage.getItem('staff_id');
    if (!staffId) return '<div class="card"><p style="color:var(--red);font-size:13px">⚠ No staff record linked to your account. Ask HOD to add you as staff in Timetable settings.</p></div>';

    const dates = [];
    for (let i = 0; i <= 3; i++) {
      const d = new Date(); d.setDate(d.getDate() - i);
      dates.push(d.toISOString().split('T')[0]);
    }
    const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    const dateOptions = dates.map((d, i) => {
      const dayName = days[new Date(d + 'T00:00:00').getDay()];
      return '<option value="' + d + '">' + (i === 0 ? 'Today' : dayName) + ' — ' + formatDate(d) + '</option>';
    }).join('');

    return '<div class="page-title">Period Attendance</div>' +
      '<div class="card" style="margin-bottom:14px;background:#E6F1FB;border-color:#185FA5">' +
        '<p style="font-size:13px;color:#0C447C;margin:0">📋 Select a date — your scheduled periods for that day will load automatically.</p>' +
      '</div>' +
      '<div class="card" style="margin-bottom:14px">' +
        '<div class="card-title">Select Date</div>' +
        '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">' +
          '<select id="paDate" onchange="paLoadDaySlots()" style="min-width:220px;padding:8px 10px;border-radius:6px;border:1px solid var(--gray-200);font-size:13px">' +
            dateOptions +
          '</select>' +
          '<span style="font-size:12px;color:var(--gray-400)">Your periods for that day load automatically</span>' +
        '</div>' +
      '</div>' +
      '<div id="paStudentList"><div class="card" style="text-align:center;padding:2rem;color:var(--gray-400)">👆 Select a date above to see your scheduled periods</div></div>';
  },

  // ── STUDENT: TIMETABLE ────────────────────────────
  async stu_timetable() {
    return ttViewPageHTML('student');
  },
};

// ══════════════════════════════════════════════════════
// POST-RENDER HOOKS (for charts, tabs, etc.)
// ══════════════════════════════════════════════════════
const POST_RENDER = {
  hod_overview: async () => {
    const students = await API.getHodStudents().catch(() => []);
    const certs    = await API.getHodCerts().catch(() => []);

    const regular  = students.filter(s => s.attendance_pct >= 75).length;
    const atRisk   = students.filter(s => s.attendance_pct >= 60 && s.attendance_pct < 75).length;
    const critical = students.filter(s => s.attendance_pct < 60).length;

    const cgpaBuckets = [0, 0, 0, 0];
    students.forEach(s => {
      const c = parseFloat(s.cgpa || 0);
      if (c >= 9) cgpaBuckets[3]++;
      else if (c >= 8) cgpaBuckets[2]++;
      else if (c >= 7) cgpaBuckets[1]++;
      else cgpaBuckets[0]++;
    });

    const yrSecCount = (yr, sec) => students.filter(s => s.year == yr && s.section === sec).length;

    const certTypes = {};
    certs.forEach(c => { certTypes[c.type] = (certTypes[c.type] || 0) + 1; });
    const certColors = ['#185FA5', '#1D9E75', '#EF9F27', '#534AB7', '#E24B4A'];

    setTimeout(() => {
      const el1 = document.getElementById('ovAttnChart');
      if (el1) chartRefs.ovAttn = new Chart(el1, {
        type: 'doughnut',
        data: { labels: ['Regular', 'At Risk', 'Critical'], datasets: [{ data: [regular, atRisk, critical], backgroundColor: ['#1D9E75', '#EF9F27', '#E24B4A'], borderWidth: 0, hoverOffset: 4 }] },
        options: { responsive: true, maintainAspectRatio: false, cutout: '65%', plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => ` ${ctx.label}: ${ctx.raw} students` } } } }
      });

      const el2 = document.getElementById('ovYearChart');
      if (el2) chartRefs.ovYear = new Chart(el2, {
        type: 'bar',
        data: { labels: ['Year 2', 'Year 3', 'Year 4'], datasets: [
          { label: 'Sec A', data: [yrSecCount(2,'A'), yrSecCount(3,'A'), yrSecCount(4,'A')], backgroundColor: '#185FA5', borderRadius: 4, borderWidth: 0 },
          { label: 'Sec B', data: [yrSecCount(2,'B'), yrSecCount(3,'B'), yrSecCount(4,'B')], backgroundColor: '#85B7EB', borderRadius: 4, borderWidth: 0 },
          { label: 'Sec C', data: [yrSecCount(2,'C'), yrSecCount(3,'C'), yrSecCount(4,'C')], backgroundColor: '#B5D4F4', borderRadius: 4, borderWidth: 0 }
        ]},
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { mode: 'index' } }, scales: { x: { stacked: true, grid: { display: false }, ticks: { color: '#868E96' } }, y: { stacked: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { color: '#868E96', stepSize: 2 }, beginAtZero: true } } }
      });

      const el3 = document.getElementById('ovCgpaChart');
      if (el3) chartRefs.ovCgpa = new Chart(el3, {
        type: 'bar',
        data: { labels: ['6.0–6.9', '7.0–7.9', '8.0–8.9', '9.0–9.9'], datasets: [{ label: 'Students', data: cgpaBuckets, backgroundColor: ['#F09595', '#EF9F27', '#1D9E75', '#185FA5'], borderRadius: 5, borderWidth: 0 }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => ` ${ctx.raw} students` } } }, scales: { x: { grid: { display: false }, ticks: { color: '#868E96' } }, y: { grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { color: '#868E96', stepSize: 1 }, beginAtZero: true } } }
      });

      const el4 = document.getElementById('ovCertChart');
      if (el4 && Object.keys(certTypes).length) chartRefs.ovCert = new Chart(el4, {
        type: 'doughnut',
        data: { labels: Object.keys(certTypes), datasets: [{ data: Object.values(certTypes), backgroundColor: certColors, borderWidth: 0, hoverOffset: 4 }] },
        options: { responsive: true, maintainAspectRatio: false, cutout: '60%', plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => ` ${ctx.label}: ${ctx.raw}` } } } }
      });
    }, 150);
  },
  hod_attendance: async () => {
    await loadYearWise();
  },
  stu_profile: async () => {
    if (!ENTITY_ID) return;
    const s = await API.getMyProfile(ENTITY_ID);
    const monthly   = (s.monthly_attendance && Object.keys(s.monthly_attendance).length) ? s.monthly_attendance : { Mar: { pct: s.attendance_pct, present: 0, total: 0 } };
    const months   = Object.keys(monthly);
    const vals     = months.map(m => typeof monthly[m] === 'object' ? monthly[m].pct : monthly[m]);
    const presents = months.map(m => typeof monthly[m] === 'object' ? monthly[m].present : 0);
    const totals   = months.map(m => typeof monthly[m] === 'object' ? monthly[m].total : 0);
    setTimeout(() => {
      const pEl = document.getElementById('pieCv');
      const lEl = document.getElementById('lineCv');
      const bEl = document.getElementById('barCv');
      if (pEl) chartRefs.pie = new Chart(pEl, { type: 'doughnut', data: { labels: ['Present','Absent'], datasets: [{ data: [s.attendance_pct, 100-s.attendance_pct], backgroundColor: ['#1D9E75','#F09595'], borderWidth: 0 }] }, options: { cutout: '65%', plugins: { legend: { display: false } }, responsive: false } });
      if (lEl) chartRefs.line = new Chart(lEl, { type: 'line', data: { labels: months, datasets: [{ data: vals, borderColor: '#185FA5', backgroundColor: 'rgba(24,95,165,.1)', borderWidth: 2, pointRadius: 4, fill: true, tension: 0.4 }] }, options: { plugins: { legend: { display: false }, tooltip: { callbacks: { label: function(ctx) { var i = ctx.dataIndex; return ' ' + presents[i] + '/' + totals[i] + ' days present (' + vals[i] + '%)'; } } } }, scales: { y: { min: 0, max: 100, ticks: { font: { size: 10 } } }, x: { ticks: { font: { size: 10 } } } }, responsive: true } });
      if (bEl) chartRefs.bar = new Chart(bEl, { type: 'bar', data: { labels: months, datasets: [{ data: vals, backgroundColor: vals.map(v => v >= 75 ? '#1D9E75' : v >= 60 ? '#EF9F27' : '#E24B4A'), borderRadius: 5, borderWidth: 0 }] }, options: { plugins: { legend: { display: false }, tooltip: { callbacks: { label: function(ctx) { var i = ctx.dataIndex; return ' ' + presents[i] + '/' + totals[i] + ' days present (' + vals[i] + '%)'; } } } }, scales: { y: { min: 0, max: 100, ticks: { font: { size: 10 } } }, x: { ticks: { font: { size: 10 } } } }, responsive: true } });
    }, 100);
    loadStudentExamMarks(ENTITY_ID, 'stuExamMarks');
  },
  ment_chat:       () => initChat(),
  stu_chat:        () => initChat(),
  hod_timetable:   async () => { await ttLoadView(2, 'A'); },
  adv_timetable:   async () => { await ttLoadAdvisorView(); },
  ment_timetable:  async () => { await ttLoadMentorView(); },
  stu_timetable:   async () => { await ttLoadStudentView(); },

};

// ══════════════════════════════════════════════════════
// HELPER RENDER FUNCTIONS
// ══════════════════════════════════════════════════════
function renderStuRows(students) {
  if (!students.length) return `<tr><td colspan="7">${emptyState('🎓', 'No students found')}</td></tr>`;
  return students.map(s => `
    <tr>
      <td><div class="flex-center">${avatarEl(s.name,'#FAEEDA','#633806',26)} ${s.name}</div></td>
      <td class="text-muted">${s.roll_no || '—'}</td>
      <td>${pill('Yr'+s.year+' '+s.section,'gray')}</td>
      <td>${s.cgpa}</td>
      <td>${attnPill(s.attendance_pct)}${attnBar(s.attendance_pct)}</td>
      <td class="text-muted text-sm">${s.mentor_name || pill('Unassigned','amber')}</td>
      <td><button class="btn btn-s btn-xs" onclick="showStudentProfileModal(${s.id})">Profile</button></td>
    </tr>`).join('');
}

function filterStudents() {
  const year = document.getElementById('fYear')?.value;
  const sec  = document.getElementById('fSec')?.value;
  const attn = document.getElementById('fAttn')?.value;
  const q    = document.getElementById('fSearch')?.value?.toLowerCase();
  API.getHodStudents({ year, section: sec }).then(data => {
    let f = data;
    if (attn === 'low')  f = f.filter(s => s.attendance_pct < 75);
    if (attn === 'vlow') f = f.filter(s => s.attendance_pct < 60);
    if (q) f = f.filter(s => (s.name||'').toLowerCase().includes(q) || (s.roll_no||'').toLowerCase().includes(q));
    const el = document.getElementById('stuTbody');
    if (el) el.innerHTML = renderStuRows(f);
  });
}

async function loadYearWise() {
  const el = document.getElementById('yearwiseContent');
  if (!el) return;
  const year = document.getElementById('aYear')?.value;
  const sec  = document.getElementById('aSec')?.value;
  el.innerHTML = '<div class="spinner"></div>';
  try {
    const data = await API.getYearWise({ year, section: sec });
    // Group by year+section
    const groups = {};
    data.forEach(s => {
      const key = `Yr${s.year} — Section ${s.section}`;
      if (!groups[key]) groups[key] = [];
      groups[key].push(s);
    });
    el.innerHTML = Object.entries(groups).map(([grp, students]) => {
      const avg = Math.round(students.reduce((a, s) => a + s.attendance_pct, 0) / students.length);
      return `
        <div class="card">
          <div class="card-hdr">
            <div class="card-title">${grp}</div>
            <span>Avg: ${attnPill(avg)}</span>
          </div>
          <div class="table-wrap"><table>
            <thead><tr><th>Name</th><th>Roll No</th><th>Attendance</th></tr></thead>
            <tbody>${students.map(s => `
              <tr><td>${s.name}</td><td class="text-muted">${s.roll_no}</td><td>${attnPill(s.attendance_pct)}${attnBar(s.attendance_pct)}</td></tr>`).join('')}
            </tbody>
          </table></div>
        </div>`;
    }).join('') || emptyState('📅', 'No data found for this filter');
  } catch (e) { el.innerHTML = '<div class="card">Error loading data</div>'; }
}

async function loadAbsences() {
  const el = document.getElementById('absencesContent');
  if (!el) return;
  const year = document.getElementById('abYear')?.value;
  const sec  = document.getElementById('abSec')?.value;
  const q    = document.getElementById('abSearch')?.value;
  el.innerHTML = '<div class="spinner"></div>';
  try {
    const data = await API.getAbsences({ year, section: sec, q });
    el.innerHTML = `
      <div class="card" style="padding:0">
        <div class="table-wrap"><table>
          <thead><tr><th>Date</th><th>Student</th><th>Roll No</th><th>Yr/Sec</th><th>Mentor</th></tr></thead>
          <tbody>${data.length ? data.map(r => `
            <tr>
              <td>${formatDate(r.date)}</td>
              <td>${r.student}</td>
              <td class="text-muted">${r.roll_no}</td>
              <td>${pill('Yr'+r.year+r.section,'gray')}</td>
              <td class="text-muted text-sm">${r.mentor}</td>
            </tr>`).join('') : `<tr><td colspan="5">${emptyState('✅','No absences found')}</td></tr>`}
          </tbody>
        </table></div>
      </div>`;
  } catch (e) { el.innerHTML = '<div class="card">Error loading absences</div>'; }
}

function switchTab(tabId, el) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('tab-' + tabId).classList.add('active');
  if (tabId === 'yearwise') loadYearWise();
  if (tabId === 'absences') loadAbsences();
}

// ══════════════════════════════════════════════════════
// CHAT
// ══════════════════════════════════════════════════════
function renderChatPage() {
  const mentorId = ROLE === 'mentor' ? ENTITY_ID : null; // will be set by initChat
  return `
    <div class="page-title">Group Chat</div>
    <div class="card" style="padding:12px">
      <div style="font-size:12px;color:var(--gray-500);margin-bottom:8px">Real-time group chat — Mentor + all mentees</div>
      <div class="chat-wrap">
        <div class="chat-msgs" id="chatMsgs"><div style="text-align:center;padding:1rem;color:var(--gray-500);font-size:12px">Loading messages...</div></div>
        <div class="chat-input-row">
          <input type="text" id="chatInput" placeholder="Type a message and press Enter…" onkeydown="if(event.key==='Enter')sendChatMsg()">
          <button class="btn btn-p" onclick="sendChatMsg()">Send</button>
        </div>
      </div>
    </div>`;
}

async function initChat() {
  // Resolve mentor_id for this chat group
  let mentorId = ENTITY_ID;
  if (ROLE === 'student') {
    try {
      const profile = await API.getMyProfile(ENTITY_ID);
      mentorId = profile.mentor?.id;
    } catch (e) { console.error(e); }
  }
  if (!mentorId) return;

  // Load history
  try {
    const history = await API.getChatHistory(mentorId);
    renderChatMessages(history, mentorId);
  } catch (e) { console.error('chat history failed', e); }

  // Open WS
  if (chatWS) { chatWS.close(); chatWS = null; }
  chatWS = openChatWS(mentorId, USER_ID, (msg) => {
    appendChatMessage(msg);
  });
  localStorage.setItem('chatMentorId', mentorId);
}

function renderChatMessages(messages, mentorId) {
  const box = document.getElementById('chatMsgs');
  if (!box) return;
  box.innerHTML = messages.map(m => buildChatBubble(m)).join('');
  box.scrollTop = box.scrollHeight;
}

function appendChatMessage(msg) {
  const box = document.getElementById('chatMsgs');
  if (!box) return;
  box.insertAdjacentHTML('beforeend', buildChatBubble(msg));
  box.scrollTop = box.scrollHeight;
}

function buildChatBubble(m) {
  const mine = m.sender_id === USER_ID;
  const time = m.time ? new Date(m.time).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '';
  return `
    <div class="chat-msg ${mine ? 'mine' : 'theirs'}">
      ${mine ? `<div class="chat-mine-name">You</div>` : `<div class="chat-sender">${m.sender_name}</div>`}
      <div class="chat-bubble">${m.message}</div>
      <div class="chat-time">${time}</div>
    </div>`;
}

function sendChatMsg() {
  const inp = document.getElementById('chatInput');
  if (!inp) return;
  const text = inp.value.trim();
  if (!text) return;
  if (!chatWS || chatWS.readyState !== WebSocket.OPEN) {
    showToast('Chat not connected. Please refresh.', 'error'); return;
  }
  const name = localStorage.getItem('userName') || 'User';
  chatWS.send(JSON.stringify({ message: text, sender_name: name }));
  inp.value = '';
}

// ══════════════════════════════════════════════════════
// MODALS — STUDENT PROFILE
// ══════════════════════════════════════════════════════
async function showStudentProfileModal(studentId) {
  document.getElementById('mProfileTitle').textContent = 'Student Profile';
  document.getElementById('mProfileBody').innerHTML = `<div style="text-align:center;padding:2rem"><div class="spinner"></div></div>`;
  om('mProfile');
  try {
    const s = await API.getStudentFull(studentId);
    const monthly   = (s.monthly_attendance && Object.keys(s.monthly_attendance).length) ? s.monthly_attendance : { Mar: { pct: s.attendance_pct, present: 0, total: 0 } };
    const months   = Object.keys(monthly);
    const vals     = months.map(m => typeof monthly[m] === 'object' ? monthly[m].pct : monthly[m]);
    const presents = months.map(m => typeof monthly[m] === 'object' ? monthly[m].present : 0);
    const totals   = months.map(m => typeof monthly[m] === 'object' ? monthly[m].total : 0);
    document.getElementById('mProfileBody').innerHTML = `
      <div class="profile-hdr">
        <div class="profile-av" style="background:#FAEEDA;color:#633806;width:52px;height:52px;font-size:18px">${ini(s.name)}</div>
        <div>
          <div class="profile-name">${s.name}</div>
          <div class="profile-meta">${s.roll_no || '—'} · Year ${s.year} · Section ${s.section} · ${s.email}</div>
        </div>
      </div>
      <div class="info-grid" style="margin-bottom:14px">
        <div class="info-row"><div class="info-lbl">CGPA</div><div class="info-val">${s.cgpa}</div></div>
        <div class="info-row"><div class="info-lbl">Attendance</div><div class="info-val">${attnPill(s.attendance_pct)}</div></div>
        <div class="info-row"><div class="info-lbl">Backlogs</div><div class="info-val" style="color:${s.backlogs > 0 ? 'var(--red)' : 'var(--green)'}">${s.backlogs}</div></div>
        <div class="info-row"><div class="info-lbl">Phone</div><div class="info-val">${s.phone || '—'}</div></div>
        <div class="info-row"><div class="info-lbl">DOB</div><div class="info-val">${formatDate(s.dob)}</div></div>
        <div class="info-row"><div class="info-lbl">Mentor</div><div class="info-val text-sm">${s.mentor ? s.mentor.name : '—'}</div></div>
        <div class="info-row"><div class="info-lbl">Advisor</div><div class="info-val text-sm">${s.advisor ? s.advisor.name : '—'}</div></div>
      </div>
      ${s.achievements && s.achievements.length ? `<div style="margin-bottom:10px">${s.achievements.map(a => `<span class="pill p-teal" style="margin:2px">🏆 ${a}</span>`).join('')}</div>` : ''}
      ${s.certificates && s.certificates.length ? `<div style="margin-bottom:12px"><div class="text-xs text-muted fw-600" style="margin-bottom:4px">CERTIFICATES</div>${s.certificates.map(c => `<span class="pill p-purple" style="margin:2px">${c.title}</span>`).join('')}</div>` : ''}
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
        <div>
          <div class="text-xs fw-600 text-muted" style="margin-bottom:6px">ATTENDANCE SPLIT</div>
          <div style="display:flex;align-items:center;gap:10px">
            <canvas id="mpie" width="80" height="80" style="flex-shrink:0"></canvas>
            <div style="font-size:11px"><div style="color:#1D9E75">● Present ${s.attendance_pct}%</div><div style="color:#E24B4A">● Absent ${100-s.attendance_pct}%</div></div>
          </div>
        </div>
        <div>
          <div class="text-xs fw-600 text-muted" style="margin-bottom:6px">MONTHLY TREND</div>
          <canvas id="mline" height="80"></canvas>
        </div>
      </div>
      <div>
        <div class="text-xs fw-600 text-muted" style="margin-bottom:6px">MONTH-WISE BAR</div>
        <canvas id="mbar" height="70"></canvas>
      </div>
      <div style="margin-top:14px">
        <div class="text-xs fw-600 text-muted" style="margin-bottom:8px">EXAM MARKS</div>
        <div id="stuModalExamMarks"></div>
      </div>`;
    // Draw charts
    setTimeout(() => {
      const pEl = document.getElementById('mpie');
      const lEl = document.getElementById('mline');
      const bEl = document.getElementById('mbar');
      if (pEl) new Chart(pEl, { type: 'doughnut', data: { labels: ['Present','Absent'], datasets: [{ data: [s.attendance_pct, 100-s.attendance_pct], backgroundColor: ['#1D9E75','#F09595'], borderWidth: 0 }] }, options: { cutout: '60%', plugins: { legend: { display: false } }, responsive: false } });
      if (lEl) new Chart(lEl, { type: 'line', data: { labels: months, datasets: [{ data: vals, borderColor: '#185FA5', backgroundColor: 'rgba(24,95,165,.1)', borderWidth: 2, pointRadius: 3, fill: true, tension: 0.4 }] }, options: { plugins: { legend: { display: false }, tooltip: { callbacks: { label: function(ctx) { var i = ctx.dataIndex; return ' ' + presents[i] + '/' + totals[i] + ' days present (' + vals[i] + '%)'; } } } }, scales: { y: { min: 0, max: 100, ticks: { font: { size: 9 } } }, x: { ticks: { font: { size: 9 } } } }, responsive: true } });
      if (bEl) new Chart(bEl, { type: 'bar', data: { labels: months, datasets: [{ data: vals, backgroundColor: vals.map(v => v >= 75 ? '#1D9E75' : v >= 60 ? '#EF9F27' : '#E24B4A'), borderRadius: 4, borderWidth: 0 }] }, options: { plugins: { legend: { display: false }, tooltip: { callbacks: { label: function(ctx) { var i = ctx.dataIndex; return ' ' + presents[i] + '/' + totals[i] + ' days present (' + vals[i] + '%)'; } } } }, scales: { y: { min: 0, max: 100, ticks: { font: { size: 9 } } }, x: { ticks: { font: { size: 9 } } } }, responsive: true } });
    }, 100);
    loadStudentExamMarks(studentId, 'stuModalExamMarks');
  } catch (e) {
    document.getElementById('mProfileBody').innerHTML = `<div style="color:var(--red)">Failed to load profile: ${e?.detail || 'unknown error'}</div>`;
  }
}

async function showMentorProfile(mentorId) {
  document.getElementById('mProfileTitle').textContent = 'Mentor Profile';
  document.getElementById('mProfileBody').innerHTML = `<div style="text-align:center;padding:2rem"><div class="spinner"></div></div>`;
  om('mProfile');
  try {
    const mentors = await API.getHodMentors();
    const m = mentors.find(x => x.id === mentorId);
    const mentees = await API.getMentees(mentorId);
    document.getElementById('mProfileBody').innerHTML = `
      <div class="profile-hdr">
        <div class="profile-av" style="background:#EEEDFE;color:#534AB7">${ini(m.name)}</div>
        <div><div class="profile-name">${m.name}</div><div class="profile-meta">${m.email} · ${m.department}</div></div>
      </div>
      <div style="font-size:13px;color:var(--gray-500);margin-bottom:10px">${mentees.length} mentees assigned</div>
      <div style="display:grid;gap:6px">
        ${mentees.map(s => `
          <div style="display:flex;justify-content:space-between;align-items:center;padding:7px 10px;background:var(--gray-50);border-radius:6px;border:1px solid var(--gray-200)">
            <span class="fw-600 text-sm">${s.name} <span class="text-muted text-xs">${s.roll_no}</span></span>
            ${attnPill(s.attendance_pct)}
          </div>`).join('')}
      </div>`;
  } catch (e) { document.getElementById('mProfileBody').innerHTML = `<div style="color:var(--red)">Error: ${e?.detail}</div>`; }
}

// ══════════════════════════════════════════════════════
// HOD ACTIONS
// ══════════════════════════════════════════════════════
async function submitAddMentor() {
  const name  = document.getElementById('newMName').value.trim();
  const email = document.getElementById('newMEmail').value.trim();
  const dept  = document.getElementById('newMDept').value.trim();
  const pwd   = document.getElementById('newMPwd').value.trim();
  if (!name || !email) { showToast('Name and email required', 'error'); return; }
  try {
    await API.addMentor({ name, email, department: dept, password: pwd });
    cm('mAddMentor');
    showToast('Mentor added successfully!');
    navigateTo('hod_mentors');
  } catch (e) { showToast(e?.detail || 'Error adding mentor', 'error'); }
}

async function deleteMentor(id, name) {
  if (!confirm(`Remove mentor "${name}"? Their mentees will become unassigned.`)) return;
  try {
    await API.deleteMentor(id);
    showToast('Mentor removed');
    navigateTo('hod_mentors');
  } catch (e) { showToast('Error removing mentor', 'error'); }
}

// ASSIGN STUDENTS — only shows mentorless + this mentor's current group
async function openAssign(mentorId, mentorName) {
  assigningMentorId = mentorId;
  document.getElementById('mAssignTitle').textContent = `Assign Students → ${mentorName}`;
  document.getElementById('assignList').innerHTML = '<div class="spinner" style="margin:1rem auto;display:block"></div>';
  om('mAssign');
  try {
    const students = await API.getAssignable(mentorId);
    if (!students.length) {
      document.getElementById('assignList').innerHTML = emptyState('🎓', 'All students are assigned to other mentors. Remove a student from their current mentor first.');
      return;
    }
    document.getElementById('assignList').innerHTML = students.map(s => `
      <div class="assign-student-item">
        <input type="checkbox" id="astu-${s.id}" value="${s.id}" ${s.is_assigned ? 'checked' : ''}>
        <label for="astu-${s.id}">
          <strong>${s.name}</strong>
          <span class="text-muted text-xs"> ${s.roll_no || ''} · Yr${s.year}${s.section}</span>
          ${s.is_assigned ? '<span class="assign-tag"> ✓ currently assigned</span>' : '<span class="assign-unassigned"> (unassigned)</span>'}
        </label>
      </div>`).join('');
  } catch (e) {
    document.getElementById('assignList').innerHTML = `<div style="color:var(--red);padding:8px">Error: ${e?.detail}</div>`;
  }
}

async function submitAssign() {
  const checked = [...document.querySelectorAll('#assignList input[type=checkbox]:checked')].map(el => parseInt(el.value));
  try {
    await API.assignStudents(assigningMentorId, checked);
    cm('mAssign');
    showToast(`${checked.length} students assigned successfully!`);
    navigateTo('hod_mentors');
  } catch (e) { showToast(e?.detail || 'Error saving assignments', 'error'); }
}

function openAdvisorModal(id = '', name = '', email = '', year = 2, section = 'A') {
  document.getElementById('mAdvisorTitle').textContent = id ? 'Change Advisor Role' : 'Add New Advisor';
  document.getElementById('editAdvisorId').value = id;
  document.getElementById('advName').value = name;
  document.getElementById('advEmail').value = email;
  document.getElementById('advYear').value = year;
  document.getElementById('advSection').value = section;
  // Show password field only when adding a new advisor, hide when editing
  document.getElementById('advPwdRow').style.display = id ? 'none' : 'block';
  om('mAdvisor');
}

async function submitAdvisor() {
  const id      = document.getElementById('editAdvisorId').value;
  const name    = document.getElementById('advName').value.trim();
  const email   = document.getElementById('advEmail').value.trim();
  const year    = parseInt(document.getElementById('advYear').value);
  const section = document.getElementById('advSection').value;
  const pwd     = document.getElementById('advPwd').value;
  if (!name || !email) { showToast('Name and email required', 'error'); return; }
  try {
    let result;
    if (id) {
      // Editing existing — do NOT send password
      result = await API.changeAdvisor(id, { name, email, year, section });
    } else {
      // Adding new — send password
      result = await API.addAdvisor({ name, email, year, section, password: pwd });
    }
    cm('mAdvisor');
    showToast(result?.message || (id ? 'Advisor updated!' : 'Advisor added!'));
    navigateTo('hod_advisors');
  } catch (e) { showToast(e?.detail || 'Error', 'error'); }
}
async function deleteAdvisor(id, name) {
  if (!confirm(`Remove advisor "${name}"?`)) return;
  try {
    await API.deleteAdvisor(id);
    showToast('Advisor removed');
    navigateTo('hod_advisors');
  } catch (e) { showToast('Error', 'error'); }
}

// ══════════════════════════════════════════════════════
// ADVISOR ACTIONS
// ══════════════════════════════════════════════════════
async function openAttendanceModal() {
  if (!ENTITY_ID) return;
  const students = await API.getMyClass(ENTITY_ID);
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('attendDate').value = today;
  await loadAttendanceForDate(today, students);
  om('mAttend');

  // When advisor changes the date, reload existing records for that date
  document.getElementById('attendDate').onchange = async function () {
    await loadAttendanceForDate(this.value, students);
  };
}

async function loadAttendanceForDate(dateStr, students) {
  if (!dateStr) return;

  // Fetch existing records + on-duty info for this date
  let records = [];
  try {
    records = await API.getAttendanceByDate(ENTITY_ID, dateStr);
  } catch (e) {
    records = [];
  }

  // Handle new response format {records, date_locked} OR old array format
  let recordList = Array.isArray(records) ? records : (records.records || []);
  const dateLocked = Array.isArray(records) ? false : (records.date_locked || false);

  // Build maps from the response
  const statusMap = {};
  const lockedMap = {};
  recordList.forEach(r => {
    statusMap[r.student_id] = r.status;
    lockedMap[r.student_id] = r.locked;
  });

  const hasExistingRecords = recordList.some(r => r.status !== null);

  // If the whole date is locked by HOD, show a banner and block editing
  const infoEl2 = document.getElementById('attendDateInfo');
  if (dateLocked && infoEl2) {
    infoEl2.innerHTML = `🔒 <strong>This date has been locked by the HOD.</strong> Attendance cannot be modified.`;
    infoEl2.style.color = '#791F1F';
    infoEl2.style.background = '#FCEBEB';
    infoEl2.style.display = 'block';
  }

  document.getElementById('attendList').innerHTML = students.map(s => {
    const status = statusMap[s.id] || 'present';
    const locked = lockedMap[s.id] || false;

    // If HOD locked this date — show all as read-only
    if (dateLocked) {
      const statusLabel = status === 'onduty' ? 'On-Duty' : status === 'absent' ? 'Absent' : 'Present';
      const statusColor = status === 'absent' ? '#FCEBEB' : status === 'onduty' ? '#E6F1FB' : '#E1F5EE';
      const textColor   = status === 'absent' ? '#791F1F' : status === 'onduty' ? '#0C447C' : '#085041';
      return `
        <div style="display:flex;justify-content:space-between;align-items:center;padding:7px 4px;border-bottom:1px solid var(--gray-100)">
          <span class="fw-600 text-sm">${s.name} <span class="text-muted text-xs">${s.roll_no || ''}</span></span>
          <div style="display:flex;align-items:center;gap:8px">
            <span style="background:${statusColor};color:${textColor};padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600">${statusLabel}</span>
            <span style="font-size:11px;color:var(--gray-400)">🔒 Locked</span>
          </div>
        </div>`;
    }

    if (locked && status === 'onduty') {
      // On-Duty student — show locked badge, no dropdown
      return `
        <div style="display:flex;justify-content:space-between;align-items:center;padding:7px 4px;border-bottom:1px solid var(--gray-100)">
          <span class="fw-600 text-sm">
            ${s.name} <span class="text-muted text-xs">${s.roll_no || ''}</span>
          </span>
          <div style="display:flex;align-items:center;gap:8px">
            <span style="background:#E6F1FB;color:#0C447C;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600">
              On-Duty
            </span>
            <span style="font-size:11px;color:var(--gray-500)">(counted as present)</span>
          </div>
        </div>`;
    }

    return `
      <div style="display:flex;justify-content:space-between;align-items:center;padding:7px 4px;border-bottom:1px solid var(--gray-100)">
        <span class="fw-600 text-sm">
          ${s.name} <span class="text-muted text-xs">${s.roll_no || ''}</span>
        </span>
        <select id="atst-${s.id}" style="padding:4px 8px;font-size:12px">
          <option value="present" ${status === 'present' ? 'selected' : ''}>Present</option>
          <option value="absent"  ${status === 'absent'  ? 'selected' : ''}>Absent</option>
        </select>
      </div>`;
  }).join('');

  // Disable/enable Save button based on lock status
  const saveBtn = document.querySelector('#mAttend .btn-p[onclick="submitAttendance()"]');
  if (saveBtn) {
    saveBtn.disabled = dateLocked;
    saveBtn.style.opacity = dateLocked ? '0.4' : '1';
    saveBtn.title = dateLocked ? 'This date is locked by HOD' : '';
  }

  // Info banner
  const infoEl = document.getElementById('attendDateInfo');
  if (infoEl) {
    const onDutyCount = recordList.filter(r => r.status === 'onduty').length;
    if (!dateLocked) {
      if (hasExistingRecords) {
        infoEl.innerHTML = `Showing saved attendance for ${dateStr}. You can edit and re-save.`
          + (onDutyCount > 0 ? ` &nbsp;|&nbsp; <strong>${onDutyCount} student(s) on approved On-Duty</strong> — locked as present.` : '');
        infoEl.style.color = '#085041';
        infoEl.style.background = '#E1F5EE';
      } else {
        infoEl.innerHTML = `No attendance saved yet for ${dateStr}. Defaulting all to Present.`
          + (onDutyCount > 0 ? ` &nbsp;|&nbsp; <strong>${onDutyCount} student(s) on approved On-Duty.</strong>` : '');
        infoEl.style.color = '#633806';
        infoEl.style.background = '#FAEEDA';
      }
      infoEl.style.display = 'block';
    }
  }
}

async function submitAttendance() {
  if (!ENTITY_ID) return;
  const date = document.getElementById('attendDate').value;
  if (!date) { showToast('Select a date', 'error'); return; }
  const students = await API.getMyClass(ENTITY_ID);

  const entries = [];
  students.forEach(s => {
    const selectEl = document.getElementById('atst-' + s.id);
    if (!selectEl) {
      // No dropdown = On-Duty student — skip, already handled by leave approval
      return;
    }
    entries.push({
      student_id: s.id,
      status: selectEl.value
    });
  });

  try {
    await API.uploadAttendance({ date, entries, marked_by: USER_ID });
    cm('mAttend');
    showToast('Attendance saved! Absences visible to mentors & HOD.');
    navigateTo(currentPage);
  } catch (e) { showToast('Error saving attendance', 'error'); }
}

async function resolveLeave(id, status) {
  try {
    await API.reviewLeave(id, { status, reviewed_by: USER_ID });
    showToast(status === 'accepted' ? 'Leave accepted. Dates auto-marked as present.' : 'Leave declined.');
    navigateTo('adv_leave');
  } catch (e) { showToast('Error: ' + (e?.detail || ''), 'error'); }
}

async function submitAddStudent() {
  const email   = document.getElementById('stuEmail').value.trim();
  const pwd     = document.getElementById('stuPwd').value.trim();
  const year    = parseInt(document.getElementById('stuYear').value);
  const section = document.getElementById('stuSection').value;
  if (!email) { showToast('Email required', 'error'); return; }
  try {
    await API.addStudent({ email, password: pwd, year, section, advisor_id: ENTITY_ID });
    cm('mAddStudent');
    showToast('Student account created! Credentials sent to ' + email);
    navigateTo(currentPage);
  } catch (e) { showToast(e?.detail || 'Error creating student', 'error'); }
}

// ══════════════════════════════════════════════════════
// MENTOR ACTIONS
// ══════════════════════════════════════════════════════
async function submitAnnouncement() {
  const title = document.getElementById('annTitle').value.trim();
  const body  = document.getElementById('annBody').value.trim();
  if (!title || !body) { showToast('Fill title and message', 'error'); return; }
  try {
    await API.postAnnounce(ENTITY_ID, { title, body });
    cm('mAnnounce');
    showToast('Announcement sent to all mentees!');
    document.getElementById('annTitle').value = '';
    document.getElementById('annBody').value = '';
    navigateTo('ment_announce');
  } catch (e) { showToast('Error sending announcement', 'error'); }
}

// ══════════════════════════════════════════════════════
// STUDENT ACTIONS
// ══════════════════════════════════════════════════════
async function submitLeaveRequest() {
  const type   = document.getElementById('leaveType').value;
  const from   = document.getElementById('leaveFrom').value;
  const to     = document.getElementById('leaveTo').value;
  const reason = document.getElementById('leaveReason').value.trim();
  if (!from || !to || !reason) { showToast('Fill all fields', 'error'); return; }
  try {
    await API.submitLeave(ENTITY_ID, { type, from_date: from, to_date: to, reason });
    cm('mLeave');
    showToast('Leave request submitted to your class advisor!');
    navigateTo('stu_leave');
  } catch (e) { showToast(e?.detail || 'Error', 'error'); }
}

async function submitCertUpload() {
  const title   = document.getElementById('certTitle').value.trim();
  const type    = document.getElementById('certType').value;
  const issuer  = document.getElementById('certIssuer').value.trim();
  const date    = document.getElementById('certDate').value;
  const fileEl  = document.getElementById('certFile');
  if (!title || !date || !fileEl.files.length) { showToast('Fill all fields and select a file', 'error'); return; }
  const form = new FormData();
  form.append('title',      title);
  form.append('cert_type',  type);
  form.append('issuer',     issuer);
  form.append('issue_date', date);
  form.append('file',       fileEl.files[0]);
  try {
    await API.uploadCert(ENTITY_ID, form);
    cm('mUploadCert');
    showToast('Certificate uploaded successfully!');
    navigateTo('stu_certs');
  } catch (e) { showToast(e?.detail || 'Upload failed', 'error'); }
}

async function submitFirstLogin() {
  const name     = document.getElementById('fl_name').value.trim();
  const roll     = document.getElementById('fl_roll').value.trim();
  const phone    = document.getElementById('fl_phone').value.trim();
  const dob      = document.getElementById('fl_dob').value;
  const cgpa     = parseFloat(document.getElementById('fl_cgpa').value) || 0;
  const backlogs = parseInt(document.getElementById('fl_backlogs').value) || 0;
  if (!name || !roll) { showToast('Name and roll number required', 'error'); return; }
  try {
    await API.updateProfile(ENTITY_ID, { name, roll_no: roll, phone, dob, cgpa, backlogs });
    localStorage.setItem('first_login', 'false');
    localStorage.setItem('userName', name);
    document.getElementById('tbName').textContent = name;
    document.getElementById('tbAvatar').textContent = ini(name);
    cm('mFirstLogin');
    showToast('Profile saved! Welcome to MentorConnect.');
    navigateTo('stu_profile');
  } catch (e) { showToast(e?.detail || 'Error saving profile', 'error'); }
}

// =====================================================
// ADD ALL OF THIS AT THE BOTTOM OF frontend/assets/dashboard.js
// =====================================================


// ══════════════════════════════════════════════════════
// CHANGE PASSWORD
// ══════════════════════════════════════════════════════

function resetChangePwd() {
  document.getElementById('cpOld').value = '';
  document.getElementById('cpNew').value = '';
  document.getElementById('cpConfirm').value = '';
  const errEl = document.getElementById('changePwdError');
  const okEl  = document.getElementById('changePwdSuccess');
  if (errEl) errEl.style.display = 'none';
  if (okEl)  okEl.style.display  = 'none';
}

async function submitChangePassword() {
  const oldPwd  = document.getElementById('cpOld').value.trim();
  const newPwd  = document.getElementById('cpNew').value.trim();
  const confirm = document.getElementById('cpConfirm').value.trim();
  const errEl   = document.getElementById('changePwdError');
  const okEl    = document.getElementById('changePwdSuccess');
  const btn     = document.getElementById('cpSaveBtn');

  errEl.style.display = 'none';
  okEl.style.display  = 'none';

  if (!oldPwd || !newPwd || !confirm) {
    errEl.textContent = 'Please fill in all fields.';
    errEl.style.display = 'block';
    return;
  }
  if (newPwd.length < 6) {
    errEl.textContent = 'New password must be at least 6 characters.';
    errEl.style.display = 'block';
    return;
  }
  if (newPwd !== confirm) {
    errEl.textContent = 'New passwords do not match.';
    errEl.style.display = 'block';
    return;
  }
  if (oldPwd === newPwd) {
    errEl.textContent = 'New password must be different from your current password.';
    errEl.style.display = 'block';
    return;
  }

  btn.textContent = 'Saving...';
  btn.disabled = true;

  try {
    const result = await API.changePassword({ old_password: oldPwd, new_password: newPwd });
    okEl.textContent = (result.message || 'Password changed!') + ' You will be logged out now.';
    okEl.style.display = 'block';
    resetChangePwd();
    // Log out after 2 seconds so user logs in fresh with new password
    setTimeout(() => {
      cm('mChangePwd');
      doLogout();
    }, 2000);
  } catch (e) {
    errEl.textContent = e?.detail || 'Error changing password. Please try again.';
    errEl.style.display = 'block';
    btn.textContent = 'Save New Password';
    btn.disabled = false;
  }
}


// ══════════════════════════════════════════════════════
// YEAR PROMOTION
// ══════════════════════════════════════════════════════

async function openPromotion() {
  document.getElementById('promotionActions').style.display = 'none';
  document.getElementById('promotionBody').innerHTML =
    '<div style="text-align:center;padding:2rem"><div class="spinner"></div></div>';
  om('mPromotion');

  try {
    const data = await API.getPromotionPreview();
    renderPromotionPreview(data);
  } catch (e) {
    document.getElementById('promotionBody').innerHTML =
      '<div style="color:#E24B4A;padding:1rem;font-size:13px">Error loading preview. Please try again.</div>';
  }
}

function renderPromotionPreview(data) {
  const now   = new Date();
  const batch = `${now.getFullYear() - 4}–${now.getFullYear()}`;

  document.getElementById('promotionBody').innerHTML = `
    <div style="background:#FCEBEB;border:1px solid #F7C1C1;border-radius:8px;padding:10px 14px;margin-bottom:1rem;font-size:13px;color:#791F1F">
      <strong>⚠ This action is permanent and cannot be undone.</strong>
      Read carefully before confirming.
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:1rem">

      <div style="background:#FCEBEB;border-radius:8px;padding:12px 14px">
        <div style="font-size:11px;font-weight:700;color:#791F1F;text-transform:uppercase;letter-spacing:.04em;margin-bottom:6px">
          Passed Out — ${data.passout_count} students
        </div>
        <div style="font-size:12px;color:#791F1F;margin-bottom:6px">
          Will be marked as <strong>Alumni (Batch ${batch})</strong>.
          Excel report auto-downloaded.
        </div>
        <div style="max-height:110px;overflow-y:auto;border-top:1px solid #F7C1C1;padding-top:6px">
          ${data.passout.length
            ? data.passout.map(s =>
                `<div style="font-size:12px;padding:2px 0;color:#791F1F">
                  ${s.name} <span style="color:#A32D2D">${s.roll_no || ''} · Sec ${s.section}</span>
                </div>`
              ).join('')
            : '<div style="font-size:12px;color:#A32D2D">No 4th year students found.</div>'}
        </div>
      </div>

      <div style="display:flex;flex-direction:column;gap:8px">
        <div style="background:#FAEEDA;border-radius:8px;padding:10px 12px">
          <div style="font-size:11px;font-weight:700;color:#633806;margin-bottom:4px">
            3rd Year → 4th Year &nbsp;(${data.third_to_fourth.length} students)
          </div>
          <div style="font-size:12px;color:#633806">
            Class advisors detached — HOD must reassign.
          </div>
        </div>
        <div style="background:#FAEEDA;border-radius:8px;padding:10px 12px">
          <div style="font-size:11px;font-weight:700;color:#633806;margin-bottom:4px">
            2nd Year → 3rd Year &nbsp;(${data.second_to_third.length} students)
          </div>
          <div style="font-size:12px;color:#633806">
            Class advisors detached — HOD must reassign.
          </div>
        </div>
        <div style="background:#E1F5EE;border-radius:8px;padding:10px 12px">
          <div style="font-size:11px;font-weight:700;color:#085041;margin-bottom:4px">
            2nd Year — becomes empty
          </div>
          <div style="font-size:12px;color:#085041">
            Ready for new incoming students. Class Advisors can add them.
          </div>
        </div>
      </div>
    </div>

    <div style="background:#E6F1FB;border-radius:8px;padding:10px 14px;font-size:12px;color:#0C447C">
      <strong>After promotion:</strong> Go to Advisors page and reassign advisors to the promoted classes.
      Mentor assignments are kept unchanged.
    </div>`;

  document.getElementById('promotionActions').style.display = 'flex';
}

async function confirmPromotion() {
  const btn = document.getElementById('promotionConfirmBtn');
  btn.textContent = 'Processing...';
  btn.disabled = true;

  try {
    const token = localStorage.getItem('token');
    const res = await fetch(BASE_URL + '/hod/promotion/execute', {
      method: 'POST',
      headers: { Authorization: 'Bearer ' + token }
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw err;
    }

    // Trigger Excel file download
    const blob = await res.blob();
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    const now  = new Date();
    a.href     = url;
    a.download = `Passout_${now.getFullYear() - 4}-${now.getFullYear()}.xlsx`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    cm('mPromotion');
    showToast('Year promotion done! Excel downloaded. Please reassign advisors for promoted classes.');
    navigateTo(currentPage);

  } catch (e) {
    showToast(e?.detail || 'Error during promotion. Please try again.', 'error');
    btn.textContent = 'Confirm Promotion & Download Excel';
    btn.disabled = false;
  }
}
// ══════════════════════════════════════════════════════
// HOD PDF EXPORT
// ══════════════════════════════════════════════════════
async function exportHodPDF() {
  showToast('Preparing PDF…', 'info');

  const [students, mentors, advisors, certs] = await Promise.all([
    API.getHodStudents().catch(() => []),
    API.getHodMentors().catch(() => []),
    API.getHodAdvisors().catch(() => []),
    API.getHodCerts().catch(() => []),
  ]);

  const today       = new Date().toLocaleDateString('en-IN', { day:'2-digit', month:'long', year:'numeric' });
  const low         = students.filter(s => s.attendance_pct < 75);
  const critical    = students.filter(s => s.attendance_pct < 60);
  const atRisk      = students.filter(s => s.attendance_pct >= 60 && s.attendance_pct < 75);
  const regular     = students.filter(s => s.attendance_pct >= 75);
  const avgCgpa     = students.length
    ? (students.reduce((a, s) => a + parseFloat(s.cgpa || 0), 0) / students.length).toFixed(2)
    : '—';

  const attnColor  = p => p >= 75 ? '#1D9E75' : p >= 60 ? '#EF9F27' : '#E24B4A';
  const attnLabel  = p => p >= 75 ? 'Regular' : p >= 60 ? 'At Risk' : 'Critical';

  const studentRows = students.map(s => `
    <tr>
      <td>${s.name}</td>
      <td>${s.roll_no || '—'}</td>
      <td>Yr${s.year} ${s.section}</td>
      <td>${s.cgpa || '—'}</td>
      <td style="color:${attnColor(s.attendance_pct)};font-weight:600">${s.attendance_pct}%</td>
      <td style="color:${attnColor(s.attendance_pct)}">${attnLabel(s.attendance_pct)}</td>
      <td>${s.mentor_name || '—'}</td>
    </tr>`).join('');

  const mentorRows = mentors.map(m => `
    <tr>
      <td>${m.name}</td>
      <td>${m.email}</td>
      <td>${m.department}</td>
      <td>${m.mentee_count}</td>
      <td style="color:${m.low_attendance > 0 ? '#E24B4A' : '#1D9E75'};font-weight:600">${m.low_attendance}</td>
    </tr>`).join('');

  const certRows = certs.map(c => `
    <tr>
      <td>${c.student || '—'}</td>
      <td>${c.title}</td>
      <td>${c.type || '—'}</td>
      <td>${c.issuer || '—'}</td>
      <td>${c.date ? new Date(c.date).toLocaleDateString('en-IN') : '—'}</td>
    </tr>`).join('');

  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>MentorConnect — HOD Report</title>
      <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family: 'Segoe UI', Arial, sans-serif; font-size:12px; color:#1a1a2e; background:#fff; padding:32px; }

        .header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:28px; padding-bottom:16px; border-bottom:2px solid #185FA5; }
        .header-left .logo { font-size:22px; font-weight:800; color:#185FA5; letter-spacing:-0.5px; }
        .header-left .sub  { font-size:11px; color:#868E96; margin-top:2px; }
        .header-right      { text-align:right; font-size:11px; color:#868E96; line-height:1.8; }
        .header-right strong { color:#1a1a2e; }

        .stats-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin-bottom:24px; }
        .stat-box   { background:#F8F9FA; border-radius:8px; padding:12px 14px; border-left:3px solid #185FA5; }
        .stat-box.green  { border-color:#1D9E75; }
        .stat-box.amber  { border-color:#EF9F27; }
        .stat-box.red    { border-color:#E24B4A; }
        .stat-lbl { font-size:10px; text-transform:uppercase; letter-spacing:.05em; color:#868E96; font-weight:600; }
        .stat-num { font-size:22px; font-weight:800; color:#1a1a2e; margin-top:2px; }

        .section-title { font-size:13px; font-weight:700; color:#185FA5; text-transform:uppercase; letter-spacing:.06em; margin:20px 0 10px; padding-bottom:4px; border-bottom:1px solid #e9ecef; }

        table { width:100%; border-collapse:collapse; margin-bottom:8px; font-size:11px; }
        th    { background:#185FA5; color:#fff; padding:7px 10px; text-align:left; font-weight:600; font-size:10px; text-transform:uppercase; letter-spacing:.04em; }
        td    { padding:6px 10px; border-bottom:1px solid #f1f3f5; }
        tr:nth-child(even) td { background:#f8f9fa; }

        .summary-row { display:flex; gap:16px; margin-bottom:20px; }
        .summary-box { flex:1; background:#F8F9FA; border-radius:8px; padding:12px 14px; }
        .summary-box .s-title { font-size:10px; font-weight:700; text-transform:uppercase; color:#868E96; margin-bottom:6px; }
        .s-row { display:flex; justify-content:space-between; padding:3px 0; font-size:11px; border-bottom:1px solid #e9ecef; }
        .s-row:last-child { border-bottom:none; }

        .footer { margin-top:32px; padding-top:12px; border-top:1px solid #e9ecef; display:flex; justify-content:space-between; font-size:10px; color:#adb5bd; }

        @media print {
          body { padding:16px; }
          @page { margin:15mm; size:A4; }
        }
      </style>
    </head>
    <body>

      <div class="header">
        <div class="header-left">
          <div class="logo">🎓 MentorConnect</div>
          <div class="sub">College Mentor–Mentee Management System · CSE Department</div>
        </div>
        <div class="header-right">
          <div><strong>Report Type:</strong> HOD Department Overview</div>
          <div><strong>Generated:</strong> ${today}</div>
          <div><strong>Academic Year:</strong> 2025–26</div>
        </div>
      </div>

      <div class="stats-grid">
        <div class="stat-box">        <div class="stat-lbl">Total Students</div><div class="stat-num">${students.length}</div></div>
        <div class="stat-box">        <div class="stat-lbl">Mentors</div><div class="stat-num">${mentors.length}</div></div>
        <div class="stat-box">        <div class="stat-lbl">Advisors</div><div class="stat-num">${advisors.length}</div></div>
        <div class="stat-box">        <div class="stat-lbl">Avg CGPA</div><div class="stat-num">${avgCgpa}</div></div>
        <div class="stat-box green">  <div class="stat-lbl">Regular (≥75%)</div><div class="stat-num">${regular.length}</div></div>
        <div class="stat-box amber">  <div class="stat-lbl">At Risk (60–74%)</div><div class="stat-num">${atRisk.length}</div></div>
        <div class="stat-box red">    <div class="stat-lbl">Critical (&lt;60%)</div><div class="stat-num">${critical.length}</div></div>
        <div class="stat-box">        <div class="stat-lbl">Certificates</div><div class="stat-num">${certs.length}</div></div>
      </div>

      <div class="section-title">📋 All Students</div>
      <table>
        <thead><tr><th>Name</th><th>Roll No</th><th>Yr/Sec</th><th>CGPA</th><th>Attendance</th><th>Status</th><th>Mentor</th></tr></thead>
        <tbody>${studentRows || '<tr><td colspan="7" style="text-align:center;color:#aaa">No students found</td></tr>'}</tbody>
      </table>

      <div class="section-title">👨🏫 Mentor Summary</div>
      <table>
        <thead><tr><th>Name</th><th>Email</th><th>Department</th><th>Mentees</th><th>Low Attendance</th></tr></thead>
        <tbody>${mentorRows || '<tr><td colspan="5" style="text-align:center;color:#aaa">No mentors found</td></tr>'}</tbody>
      </table>

      <div class="section-title">🏅 Certificates Uploaded</div>
      <table>
        <thead><tr><th>Student</th><th>Certificate</th><th>Type</th><th>Issuer</th><th>Issue Date</th></tr></thead>
        <tbody>${certRows || '<tr><td colspan="5" style="text-align:center;color:#aaa">No certificates found</td></tr>'}</tbody>
      </table>

      <div class="footer">
        <span>MentorConnect — Confidential Department Report</span>
        <span>Generated on ${today}</span>
      </div>

    </body>
    </html>`;

  // Open in new tab and trigger print dialog
  const win = window.open('', '_blank');
  win.document.write(html);
  win.document.close();
  win.onload = () => {
    win.focus();
    win.print();
  };
}
// ══════════════════════════════════════════════════════
// ACADEMIC CALENDAR
// ══════════════════════════════════════════════════════

const CAL_TYPES = {
  'Exam / Test':          { color: '#E24B4A', bg: '#FCEBEB', icon: '📝' },
  'Industry Visit':       { color: '#185FA5', bg: '#E6F1FB', icon: '🏭' },
  'Internship Deadline':  { color: '#534AB7', bg: '#EEEDFE', icon: '💼' },
  'Holiday':              { color: '#1D9E75', bg: '#E1F5EE', icon: '🎉' },
  'Meeting / Review':     { color: '#EF9F27', bg: '#FAEEDA', icon: '🤝' },
};

function calGetEvents() {
  try { return JSON.parse(localStorage.getItem('mc_calendar_events') || '[]'); }
  catch { return []; }
}

function calSaveEvents(events) {
  localStorage.setItem('mc_calendar_events', JSON.stringify(events));
}

function calendarPageHTML(isHod) {
  const events   = calGetEvents();
  const now      = new Date();
  const upcoming = events
    .filter(e => new Date(e.date) >= new Date(now.toDateString()))
    .sort((a, b) => new Date(a.date) - new Date(b.date));
  const past     = events
    .filter(e => new Date(e.date) < new Date(now.toDateString()))
    .sort((a, b) => new Date(b.date) - new Date(a.date));

  const typeOptions = Object.keys(CAL_TYPES)
    .map(t => `<option value="${t}">${CAL_TYPES[t].icon} ${t}</option>`).join('');

  const renderEvent = (e, showDelete) => {
    const t = CAL_TYPES[e.type] || { color: '#868E96', bg: '#f8f9fa', icon: '📌' };
    const d = new Date(e.date).toLocaleDateString('en-IN', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' });
    const daysLeft = Math.ceil((new Date(e.date) - new Date(now.toDateString())) / 86400000);
    const daysLabel = daysLeft === 0 ? '🔴 Today'
      : daysLeft === 1 ? '🟠 Tomorrow'
      : daysLeft > 0   ? `🟡 In ${daysLeft} days`
      : '';
    return `
      <div style="display:flex;align-items:flex-start;gap:12px;padding:12px 0;border-bottom:1px solid var(--gray-100)">
        <div style="width:42px;height:42px;border-radius:10px;background:${t.bg};display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0">${t.icon}</div>
        <div style="flex:1">
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
            <span style="font-size:13px;font-weight:700;color:var(--gray-900)">${e.title}</span>
            <span style="font-size:11px;font-weight:600;padding:2px 8px;border-radius:20px;background:${t.bg};color:${t.color}">${e.type}</span>
            ${daysLabel ? `<span style="font-size:11px;font-weight:600;color:${t.color}">${daysLabel}</span>` : ''}
          </div>
          <div style="font-size:12px;color:var(--gray-500);margin-top:3px">📅 ${d}</div>
          ${e.desc ? `<div style="font-size:12px;color:var(--gray-600);margin-top:4px">${e.desc}</div>` : ''}
        </div>
        ${showDelete ? `<button onclick="calDeleteEvent('${e.id}')" style="background:none;border:none;cursor:pointer;font-size:16px;color:#E24B4A;padding:4px" title="Delete">🗑</button>` : ''}
      </div>`;
  };

  return `
    <div class="page-header">
      <div class="page-title">🗓 Academic Calendar</div>
      ${isHod ? `<button class="btn btn-p" onclick="calOpenAdd()">+ Add Event</button>` : ''}
    </div>

    ${isHod ? `
    <!-- ADD EVENT FORM (hidden by default) -->
    <div id="calAddForm" style="display:none">
      <div class="card" style="margin-bottom:14px;border:2px solid #185FA5">
        <div style="font-size:13px;font-weight:700;color:#185FA5;margin-bottom:14px">➕ New Academic Event</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
          <div class="fg">
            <label style="font-size:12px;font-weight:600;color:var(--gray-600);display:block;margin-bottom:4px">Event Title *</label>
            <input id="calTitle" type="text" class="w-full" placeholder="e.g. Mid Semester Exam" style="padding:8px 10px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px;width:100%">
          </div>
          <div class="fg">
            <label style="font-size:12px;font-weight:600;color:var(--gray-600);display:block;margin-bottom:4px">Event Type *</label>
            <select id="calType" class="w-full" style="padding:8px 10px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px;width:100%">
              ${typeOptions}
            </select>
          </div>
          <div class="fg">
            <label style="font-size:12px;font-weight:600;color:var(--gray-600);display:block;margin-bottom:4px">Date *</label>
            <input id="calDate" type="date" class="w-full" style="padding:8px 10px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px;width:100%">
          </div>
          <div class="fg">
            <label style="font-size:12px;font-weight:600;color:var(--gray-600);display:block;margin-bottom:4px">Description (optional)</label>
            <input id="calDesc" type="text" class="w-full" placeholder="Short note about the event" style="padding:8px 10px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px;width:100%">
          </div>
        </div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-p" onclick="calSaveEvent()">Save Event</button>
          <button class="btn btn-s" onclick="calCloseAdd()">Cancel</button>
        </div>
      </div>
    </div>` : ''}

    <!-- UPCOMING EVENTS -->
    <div class="card" style="margin-bottom:14px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px">
        <div style="font-size:12px;font-weight:700;color:var(--gray-500);text-transform:uppercase;letter-spacing:.05em">Upcoming Events (${upcoming.length})</div>
      </div>
      ${upcoming.length
        ? upcoming.map(e => renderEvent(e, isHod)).join('')
        : `<div style="text-align:center;padding:2rem;color:var(--gray-400);font-size:13px">No upcoming events${isHod ? '. Click "+ Add Event" to schedule one.' : '. Check back later.'}</div>`}
    </div>

    <!-- PAST EVENTS -->
    ${past.length ? `
    <div class="card">
      <div style="font-size:12px;font-weight:700;color:var(--gray-500);text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px">Past Events (${past.length})</div>
      <div style="opacity:0.6">
        ${past.slice(0, 5).map(e => renderEvent(e, isHod)).join('')}
      </div>
      ${past.length > 5 ? `<div style="font-size:12px;color:var(--gray-400);text-align:center;padding-top:8px">+ ${past.length - 5} more past events</div>` : ''}
    </div>` : ''}
  `;
}

function calOpenAdd() {
  const form = document.getElementById('calAddForm');
  if (form) {
    form.style.display = 'block';
    // Set default date to today
    document.getElementById('calDate').value = new Date().toISOString().split('T')[0];
    form.scrollIntoView({ behavior: 'smooth' });
  }
}

function calCloseAdd() {
  const form = document.getElementById('calAddForm');
  if (form) form.style.display = 'none';
}

function calSaveEvent() {
  const title = document.getElementById('calTitle')?.value.trim();
  const type  = document.getElementById('calType')?.value;
  const date  = document.getElementById('calDate')?.value;
  const desc  = document.getElementById('calDesc')?.value.trim();

  if (!title) { showToast('Please enter an event title.', 'error'); return; }
  if (!date)  { showToast('Please select a date.', 'error'); return; }

  const events = calGetEvents();
  events.push({
    id:    'ev_' + Date.now(),
    title, type, date, desc,
    addedBy: localStorage.getItem('userName') || 'HOD',
    addedAt: new Date().toISOString(),
  });
  calSaveEvents(events);
  showToast('Event added successfully!', 'success');
  navigateTo('hod_calendar');
}

function calDeleteEvent(id) {
  if (!confirm('Delete this event?')) return;
  const events = calGetEvents().filter(e => e.id !== id);
  calSaveEvents(events);
  showToast('Event deleted.', 'info');
  navigateTo('hod_calendar');
}

// ══════════════════════════════════════════════════════
// STUDENT PROGRESS TIMELINE
// ══════════════════════════════════════════════════════
function renderTimeline(mentees, certs) {
  const select = document.getElementById('timelineSelect');
  const id     = parseInt(select ? select.value : mentees[0].id);
  const s      = mentees.find(m => m.id === id);
  if (!s) return;

  const studentCerts = certs.filter(c => c.student === s.name);
  const attnColor    = p => p >= 75 ? '#1D9E75' : p >= 60 ? '#EF9F27' : '#E24B4A';
  const attnLabel    = p => p >= 75 ? 'Regular' : p >= 60 ? 'At Risk' : 'Critical';

  // Build timeline events
  const events = [];

  // Attendance status
  events.push({
    date:  'Current',
    icon:  '📅',
    color: attnColor(s.attendance_pct),
    bg:    s.attendance_pct >= 75 ? '#E1F5EE' : s.attendance_pct >= 60 ? '#FAEEDA' : '#FCEBEB',
    title: `Attendance: ${s.attendance_pct}%`,
    desc:  `Status: ${attnLabel(s.attendance_pct)}`,
  });

  // CGPA
  events.push({
    date:  'Current',
    icon:  '🎓',
    color: parseFloat(s.cgpa) >= 8 ? '#1D9E75' : parseFloat(s.cgpa) >= 7 ? '#EF9F27' : '#E24B4A',
    bg:    parseFloat(s.cgpa) >= 8 ? '#E1F5EE' : parseFloat(s.cgpa) >= 7 ? '#FAEEDA' : '#FCEBEB',
    title: `CGPA: ${s.cgpa}`,
    desc:  parseFloat(s.cgpa) >= 9 ? 'Excellent academic performance'
         : parseFloat(s.cgpa) >= 8 ? 'Good academic performance'
         : parseFloat(s.cgpa) >= 7 ? 'Average — needs improvement'
         : 'Below average — urgent attention needed',
  });

  // Backlogs
  if (s.backlogs > 0) {
    events.push({
      date:  'Current',
      icon:  '⚠',
      color: '#E24B4A',
      bg:    '#FCEBEB',
      title: `${s.backlogs} Active Backlog${s.backlogs > 1 ? 's' : ''}`,
      desc:  'Student has pending arrear papers to clear',
    });
  }

  // Certificates
  studentCerts.forEach(c => {
    events.push({
      date:  c.date ? formatDate(c.date) : 'N/A',
      icon:  '🏅',
      color: '#534AB7',
      bg:    '#EEEDFE',
      title: c.title,
      desc:  `${c.type} · ${c.issuer || ''}`,
    });
  });

  // Absent today
  if (s.absent_today) {
    events.push({
      date:  'Today',
      icon:  '🔴',
      color: '#E24B4A',
      bg:    '#FCEBEB',
      title: 'Absent Today',
      desc:  'Marked absent by class advisor',
    });
  }

  const cgpaGrade = parseFloat(s.cgpa) >= 9 ? 'O'
    : parseFloat(s.cgpa) >= 8 ? 'A+'
    : parseFloat(s.cgpa) >= 7 ? 'A'
    : parseFloat(s.cgpa) >= 6 ? 'B'
    : 'C';

  const content = document.getElementById('timelineContent');
  if (!content) return;

  content.innerHTML = `
    <!-- Student Summary Card -->
    <div class="card" style="margin-bottom:14px">
      <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">
        <div style="width:56px;height:56px;border-radius:14px;background:#FAEEDA;color:#633806;
          display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:800;flex-shrink:0">
          ${ini(s.name)}
        </div>
        <div style="flex:1">
          <div style="font-size:16px;font-weight:700;color:var(--gray-900)">${s.name}</div>
          <div style="font-size:12px;color:var(--gray-500);margin-top:2px">
            ${s.roll_no || '—'} · Year ${s.year} · Section ${s.section}
          </div>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <div style="text-align:center;padding:10px 16px;background:#E6F1FB;border-radius:10px">
            <div style="font-size:18px;font-weight:800;color:#185FA5">${s.cgpa}</div>
            <div style="font-size:10px;color:#185FA5;font-weight:600">CGPA</div>
          </div>
          <div style="text-align:center;padding:10px 16px;background:${s.attendance_pct>=75?'#E1F5EE':s.attendance_pct>=60?'#FAEEDA':'#FCEBEB'};border-radius:10px">
            <div style="font-size:18px;font-weight:800;color:${attnColor(s.attendance_pct)}">${s.attendance_pct}%</div>
            <div style="font-size:10px;color:${attnColor(s.attendance_pct)};font-weight:600">Attendance</div>
          </div>
          <div style="text-align:center;padding:10px 16px;background:#EEEDFE;border-radius:10px">
            <div style="font-size:18px;font-weight:800;color:#534AB7">${cgpaGrade}</div>
            <div style="font-size:10px;color:#534AB7;font-weight:600">Grade</div>
          </div>
          <div style="text-align:center;padding:10px 16px;background:${s.backlogs>0?'#FCEBEB':'#E1F5EE'};border-radius:10px">
            <div style="font-size:18px;font-weight:800;color:${s.backlogs>0?'#E24B4A':'#1D9E75'}">${s.backlogs}</div>
            <div style="font-size:10px;color:${s.backlogs>0?'#E24B4A':'#1D9E75'};font-weight:600">Backlogs</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Timeline -->
    <div class="card">
      <div style="font-size:12px;font-weight:700;color:var(--gray-500);text-transform:uppercase;
        letter-spacing:.05em;margin-bottom:16px">Progress Timeline</div>

      <div style="position:relative;padding-left:28px">
        <!-- Vertical line -->
        <div style="position:absolute;left:9px;top:8px;bottom:8px;width:2px;background:var(--gray-200);border-radius:2px"></div>

        ${events.map((e, idx) => `
          <div style="position:relative;margin-bottom:${idx < events.length-1 ? '20px' : '0'}">
            <!-- Dot -->
            <div style="position:absolute;left:-24px;top:6px;width:12px;height:12px;border-radius:50%;
              background:${e.color};border:2px solid #fff;box-shadow:0 0 0 2px ${e.color}40"></div>

            <div style="background:${e.bg};border-radius:10px;padding:12px 14px;
              border-left:3px solid ${e.color}">
              <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap">
                <div style="display:flex;align-items:center;gap:8px">
                  <span style="font-size:16px">${e.icon}</span>
                  <span style="font-size:13px;font-weight:700;color:var(--gray-900)">${e.title}</span>
                </div>
                <span style="font-size:11px;color:var(--gray-400);font-weight:500">${e.date}</span>
              </div>
              <div style="font-size:12px;color:var(--gray-600);margin-top:4px;padding-left:24px">${e.desc}</div>
            </div>
          </div>`).join('')}

        ${events.length === 0 ? `
          <div style="text-align:center;padding:2rem;color:var(--gray-400);font-size:13px">
            No timeline data available for this student.
          </div>` : ''}
      </div>
    </div>

    <!-- Certificates Section -->
    ${studentCerts.length ? `
    <div class="card" style="margin-top:14px">
      <div style="font-size:12px;font-weight:700;color:var(--gray-500);text-transform:uppercase;
        letter-spacing:.05em;margin-bottom:12px">Certificates & Achievements (${studentCerts.length})</div>
      ${studentCerts.map(c => `
        <div style="display:flex;align-items:center;gap:12px;padding:10px 0;
          border-bottom:1px solid var(--gray-100)">
          <div style="width:36px;height:36px;border-radius:8px;background:#EEEDFE;
            display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0">🏅</div>
          <div style="flex:1">
            <div style="font-size:13px;font-weight:600;color:var(--gray-900)">${c.title}</div>
            <div style="font-size:11px;color:var(--gray-500)">${c.type} · ${c.issuer||''} · ${formatDate(c.date)}</div>
          </div>
          ${pill(c.type,'purple')}
        </div>`).join('')}
    </div>` : ''}
  `;
}

// Timeline data store
let _timelineMentees = [];
let _timelineCerts   = [];

function renderTimelineById() {
  renderTimeline(_timelineMentees, _timelineCerts);
}

POST_RENDER.ment_timeline = async function() {
  _timelineMentees = await API.getMentees(ENTITY_ID).catch(() => []);
  _timelineCerts   = await API.getMentorCerts(ENTITY_ID).catch(() => []);
  if (_timelineMentees.length) renderTimeline(_timelineMentees, _timelineCerts);
};

// ══════════════════════════════════════════════════════
// BULK CSV ATTENDANCE
// ══════════════════════════════════════════════════════
function downloadCsvTemplate() {
  const csv = `roll_no,name,status\n21CS001,Arun Krishnan,present\n21CS002,Bhavani Raj,absent\n22CS015,Chandru Mohan,present`;
  const blob = new Blob([csv], { type: 'text/csv' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = 'attendance_template.csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function parseCsvAttendance() {
  const fileInput = document.getElementById('csvFileInput');
  const feedback  = document.getElementById('csvFeedback');

  if (!fileInput?.files?.length) {
    showFeedback(feedback, 'Please select a CSV file first.', 'error');
    return;
  }

  const file   = fileInput.files[0];
  const reader = new FileReader();

  reader.onload = function(e) {
    const text  = e.target.result;
    const lines = text.trim().split('\n');

    if (lines.length < 2) {
      showFeedback(feedback, 'CSV file is empty or has no data rows.', 'error');
      return;
    }

    // Skip header row
    const dataLines = lines.slice(1);
    let matched = 0, skipped = 0, errors = [];

    dataLines.forEach((line, idx) => {
      // Handle both comma and semicolon separators
      const parts = line.split(/[,;]/).map(p => p.trim().replace(/^"|"$/g, ''));
      if (parts.length < 3) {
        errors.push(`Row ${idx + 2}: not enough columns`);
        return;
      }

      const rollNo = parts[0].toUpperCase();
      const status = parts[2].toLowerCase().trim();

      if (!rollNo) { skipped++; return; }
      if (status !== 'present' && status !== 'absent') {
        errors.push(`Row ${idx + 2}: invalid status "${parts[2]}" (use present/absent)`);
        return;
      }

      // Find the dropdown in attendList that matches this roll number
      // The dropdown ids are atst-{student_id}, the text shows roll_no
      const allRows = document.querySelectorAll('#attendList [id^="atst-"]');
      let found = false;

      allRows.forEach(sel => {
        // Parent div has the roll number as text
        const parentText = sel.closest('div')?.querySelector('.text-muted')?.textContent?.trim().toUpperCase();
        if (parentText === rollNo) {
          sel.value = status;
          found = true;
          matched++;
        }
      });

      if (!found) {
        skipped++;
      }
    });

    // Show result
    if (errors.length) {
      showFeedback(feedback,
        `Applied ${matched} row(s). Skipped ${skipped}. Errors: ${errors.slice(0,3).join(' | ')}`,
        'warn');
    } else if (matched === 0) {
      showFeedback(feedback,
        `No matching students found. Make sure roll numbers match exactly.`,
        'error');
    } else {
      showFeedback(feedback,
        `CSV applied! ${matched} student(s) updated, ${skipped} skipped (not in class).`,
        'success');
    }
  };

  reader.onerror = () => showFeedback(feedback, 'Error reading file.', 'error');
  reader.readAsText(file);
}

function showFeedback(el, msg, type) {
  if (!el) return;
  el.textContent = msg;
  el.style.display = 'block';
  el.style.background = type === 'success' ? '#E1F5EE'
    : type === 'error' ? '#FCEBEB'
    : '#FAEEDA';
  el.style.color = type === 'success' ? '#085041'
    : type === 'error' ? '#791F1F'
    : '#633806';
}
// ══════════════════════════════════════════════════════
// EXAMINATION MODULE
// ══════════════════════════════════════════════════════
let _currentExamId = null;
let _currentSubjectId = null;
let _currentExamName = '';
let _currentSubjectName = '';

function openAddExamForm() {
  document.getElementById('addExamForm').style.display = 'block';
  document.getElementById('addExamForm').scrollIntoView({ behavior: 'smooth' });
}
function closeAddExamForm() {
  document.getElementById('addExamForm').style.display = 'none';
  document.getElementById('examName').value = '';
  document.getElementById('examDate').value = '';
  document.getElementById('subjectInputs').innerHTML = `
    <div class="subject-input-row" style="display:flex;gap:8px;margin-bottom:6px">
      <input type="text" class="subj-name w-full" placeholder="Subject name e.g. Mathematics"
        style="padding:8px 10px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px;flex:1">
      <button onclick="removeSubjectRow(this)" style="background:none;border:1px solid #E24B4A;color:#E24B4A;border-radius:6px;padding:4px 10px;cursor:pointer;font-size:13px">x</button>
    </div>`;
}

function addSubjectRow() {
  const row = document.createElement('div');
  row.className = 'subject-input-row';
  row.style.cssText = 'display:flex;gap:8px;margin-bottom:6px';
  row.innerHTML = `
    <input type="text" class="subj-name w-full" placeholder="Subject name"
      style="padding:8px 10px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px;flex:1">
    <button onclick="removeSubjectRow(this)" style="background:none;border:1px solid #E24B4A;color:#E24B4A;border-radius:6px;padding:4px 10px;cursor:pointer;font-size:13px">x</button>`;
  document.getElementById('subjectInputs').appendChild(row);
}

function removeSubjectRow(btn) {
  const rows = document.querySelectorAll('.subject-input-row');
  if (rows.length <= 1) { showToast('At least one subject is required', 'error'); return; }
  btn.closest('.subject-input-row').remove();
}

async function submitCreateExam() {
  const name         = document.getElementById('examName').value.trim();
  const conducted_on = document.getElementById('examDate').value;
  const subjectEls   = document.querySelectorAll('.subj-name');
  const subjects     = Array.from(subjectEls).map(el => el.value.trim()).filter(Boolean);
  if (!name)            { showToast('Exam name is required', 'error'); return; }
  if (!conducted_on)    { showToast('Date is required', 'error'); return; }
  if (!subjects.length) { showToast('Add at least one subject', 'error'); return; }
  try {
    await API.createExam({
      advisor_id: ENTITY_ID,
      name,
      conducted_on,
      subjects: subjects.map(s => ({ name: s }))
    });
    showToast('Examination created!');
    closeAddExamForm();
    navigateTo('adv_exam');
  } catch (e) {
    showToast(e?.detail || 'Error creating exam', 'error');
  }
}

async function deleteExamConfirm(id, name) {
  if (!confirm('Delete examination "' + name + '"? All marks will be lost.')) return;
  try {
    await API.deleteExam(id);
    showToast('Examination deleted.');
    navigateTo('adv_exam');
  } catch (e) {
    showToast('Error deleting exam', 'error');
  }
}

async function openSubjectMarks(examId, examName, subjectId, subjectName) {
  _currentExamId      = examId;
  _currentSubjectId   = subjectId;
  _currentExamName    = examName;
  _currentSubjectName = subjectName;
  const panel = document.getElementById('marksPanel');
  panel.style.display = 'block';
  panel.scrollIntoView({ behavior: 'smooth' });
  document.getElementById('marksPanelTitle').textContent = examName + ' — ' + subjectName;
  document.getElementById('marksPanelSub').textContent   = 'Enter marks manually or upload CSV';
  document.getElementById('marksTableWrap').innerHTML    = '<div class="spinner" style="margin:1rem auto;display:block"></div>';
  try {
    const marks = await API.getExamMarks(examId, subjectId);
    renderMarksTable(marks);
  } catch (e) {
    document.getElementById('marksTableWrap').innerHTML =
      '<div style="color:var(--red);font-size:13px">Error loading marks: ' + (e?.detail || '') + '</div>';
  }
}

function closeMarksPanel() {
  document.getElementById('marksPanel').style.display = 'none';
  _currentExamId = null;
  _currentSubjectId = null;
}

function renderMarksTable(marks) {
  if (!marks.length) {
    document.getElementById('marksTableWrap').innerHTML =
      emptyState('📝', 'No students found in this class.');
    return;
  }
  document.getElementById('marksTableWrap').innerHTML = `
    <table style="width:100%;border-collapse:collapse;font-size:13px">
      <thead>
        <tr style="background:#185FA5;color:#fff">
          <th style="padding:8px 10px;text-align:left;font-weight:600">Student</th>
          <th style="padding:8px 10px;text-align:left;font-weight:600">Roll No</th>
          <th style="padding:8px 10px;text-align:center;font-weight:600">Subject Mark</th>
          <th style="padding:8px 10px;text-align:center;font-weight:600">Max Mark</th>
          <th style="padding:8px 10px;text-align:center;font-weight:600">Activity Mark</th>
          <th style="padding:8px 10px;text-align:center;font-weight:600">Grade</th>
          <th style="padding:8px 10px;text-align:center;font-weight:600">Pass/Fail</th>
        </tr>
      </thead>
      <tbody>
        ${marks.map((m, i) => `
          <tr style="background:${i%2===0?'#fff':'#f8f9fa'}">
            <td style="padding:7px 10px;font-weight:600">${m.name}</td>
            <td style="padding:7px 10px;color:var(--gray-500)">${m.roll_no}</td>
            <td style="padding:7px 10px;text-align:center">
              <input type="number" id="sm-${m.student_id}" value="${m.subject_mark}"
                min="0" max="${m.max_mark}"
                style="width:70px;padding:4px 6px;border:1px solid var(--gray-200);border-radius:4px;text-align:center;font-size:12px"
                oninput="autoCalcGrade(${m.student_id})">
            </td>
            <td style="padding:7px 10px;text-align:center">
              <input type="number" id="mm-${m.student_id}" value="${m.max_mark}" min="1"
                style="width:70px;padding:4px 6px;border:1px solid var(--gray-200);border-radius:4px;text-align:center;font-size:12px"
                oninput="autoCalcGrade(${m.student_id})">
            </td>
            <td style="padding:7px 10px;text-align:center">
              <input type="number" id="am-${m.student_id}" value="${m.activity_mark}" min="0"
                style="width:70px;padding:4px 6px;border:1px solid var(--gray-200);border-radius:4px;text-align:center;font-size:12px">
            </td>
            <td style="padding:7px 10px;text-align:center">
              <input type="text" id="gr-${m.student_id}" value="${m.grade || ''}"
                maxlength="3" placeholder="A+"
                style="width:55px;padding:4px 6px;border:1px solid var(--gray-200);border-radius:4px;text-align:center;font-size:12px">
            </td>
            <td style="padding:7px 10px;text-align:center">
              <select id="pf-${m.student_id}"
                style="padding:4px 6px;border:1px solid var(--gray-200);border-radius:4px;font-size:12px">
                <option value="Pass" ${m.pass_fail==='Pass'?'selected':''}>Pass</option>
                <option value="Fail" ${m.pass_fail==='Fail'?'selected':''}>Fail</option>
              </select>
            </td>
          </tr>`).join('')}
      </tbody>
    </table>`;
}

function autoCalcGrade(studentId) {
  const sm  = parseFloat(document.getElementById('sm-' + studentId)?.value || 0);
  const mm  = parseFloat(document.getElementById('mm-' + studentId)?.value || 100);
  const pct = mm > 0 ? (sm / mm) * 100 : 0;
  const grade = pct >= 90 ? 'O' : pct >= 80 ? 'A+' : pct >= 70 ? 'A'
    : pct >= 60 ? 'B+' : pct >= 50 ? 'B' : pct >= 40 ? 'C' : 'F';
  const passFail = pct >= 40 ? 'Pass' : 'Fail';
  const grEl = document.getElementById('gr-' + studentId);
  const pfEl = document.getElementById('pf-' + studentId);
  if (grEl) grEl.value = grade;
  if (pfEl) pfEl.value = passFail;
}

async function saveMarks() {
  if (!_currentExamId || !_currentSubjectId) return;
  const rows    = document.querySelectorAll('#marksTableWrap tbody tr');
  const entries = [];
  rows.forEach(row => {
    const smEl = row.querySelector('[id^="sm-"]');
    if (!smEl) return;
    const studentId = parseInt(smEl.id.replace('sm-', ''));
    entries.push({
      student_id:    studentId,
      subject_mark:  parseFloat(document.getElementById('sm-' + studentId)?.value || 0),
      max_mark:      parseFloat(document.getElementById('mm-' + studentId)?.value || 100),
      activity_mark: parseFloat(document.getElementById('am-' + studentId)?.value || 0),
      grade:         document.getElementById('gr-' + studentId)?.value || '',
      pass_fail:     document.getElementById('pf-' + studentId)?.value || 'Pass',
    });
  });
  if (!entries.length) { showToast('No marks to save', 'error'); return; }
  try {
    await API.saveExamMarks(_currentExamId, _currentSubjectId, { entries });
    showToast('Marks saved successfully!');
  } catch (e) {
    showToast(e?.detail || 'Error saving marks', 'error');
  }
}

function downloadMarksTemplate() {
  const rows = document.querySelectorAll('#marksTableWrap tbody tr');
  let csv    = 'roll_no,name,subject_mark,max_mark,activity_mark,grade,pass_fail\n';
  rows.forEach(row => {
    const smEl = row.querySelector('[id^="sm-"]');
    if (!smEl) return;
    const sid    = smEl.id.replace('sm-', '');
    const name   = row.cells[0]?.textContent.trim() || '';
    const rollNo = row.cells[1]?.textContent.trim() || '';
    csv += `${rollNo},${name},${document.getElementById('sm-'+sid)?.value||0},${document.getElementById('mm-'+sid)?.value||100},${document.getElementById('am-'+sid)?.value||0},${document.getElementById('gr-'+sid)?.value||''},${document.getElementById('pf-'+sid)?.value||'Pass'}\n`;
  });
  const blob = new Blob([csv], { type: 'text/csv' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url; a.download = _currentExamName + '_' + _currentSubjectName + '_marks.csv';
  document.body.appendChild(a); a.click();
  document.body.removeChild(a); URL.revokeObjectURL(url);
}

function applyMarksCsv() {
  const fileInput = document.getElementById('marksCsvInput');
  const feedback  = document.getElementById('marksCsvFeedback');
  if (!fileInput?.files?.length) { showFeedback(feedback, 'Please select a CSV file first.', 'error'); return; }
  const reader = new FileReader();
  reader.onload = e => {
    const lines = e.target.result.trim().split('\n').slice(1);
    let matched = 0, skipped = 0;
    lines.forEach(line => {
      const p = line.split(/[,;]/).map(x => x.trim().replace(/^"|"$/g,''));
      if (p.length < 3) { skipped++; return; }
      const rollNo = p[0].toUpperCase();
      document.querySelectorAll('#marksTableWrap tbody tr').forEach(row => {
        if (row.cells[1]?.textContent.trim().toUpperCase() === rollNo) {
          const sid = row.querySelector('[id^="sm-"]')?.id.replace('sm-','');
          if (!sid) return;
          if (p[2] !== undefined) document.getElementById('sm-'+sid).value = p[2];
          if (p[3] !== undefined) document.getElementById('mm-'+sid).value = p[3];
          if (p[4] !== undefined) document.getElementById('am-'+sid).value = p[4];
          if (p[5] !== undefined) document.getElementById('gr-'+sid).value = p[5];
          if (p[6] !== undefined) document.getElementById('pf-'+sid).value = p[6];
          autoCalcGrade(parseInt(sid));
          matched++;
        }
      });
    });
    showFeedback(feedback, 'Applied ' + matched + ' row(s), skipped ' + skipped + '.', matched > 0 ? 'success' : 'error');
  };
  reader.readAsText(fileInput.files[0]);
}

// ══════════════════════════════════════════════════════
// EXAM EDIT — ADD NEW SUBJECTS
// ══════════════════════════════════════════════════════
let _editingExamId   = null;
let _editingExamName = '';

function openEditExam(examId, examName) {
  _editingExamId   = examId;
  _editingExamName = examName;

  // Build inline edit panel inside the exam card
  // First close any existing edit panel
  const existing = document.getElementById('editExamPanel');
  if (existing) existing.remove();

  const panel = document.createElement('div');
  panel.id = 'editExamPanel';
  panel.innerHTML = `
    <div class="card" style="margin-bottom:12px;border:2px solid #1D9E75">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
        <div style="font-size:13px;font-weight:700;color:#1D9E75">
          Edit: ${examName}
        </div>
        <button onclick="closeEditExam()"
          style="background:none;border:none;cursor:pointer;font-size:18px;color:var(--gray-400)">x</button>
      </div>
      <div style="font-size:12px;color:var(--gray-500);margin-bottom:10px">
        Add new subjects to this examination:
      </div>
      <div id="newSubjectInputs">
        <div class="new-subj-row" style="display:flex;gap:8px;margin-bottom:6px">
          <input type="text" class="new-subj-name" placeholder="New subject name e.g. Physics"
            style="padding:8px 10px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px;flex:1">
          <button onclick="removeNewSubjRow(this)"
            style="background:none;border:1px solid #E24B4A;color:#E24B4A;border-radius:6px;padding:4px 10px;cursor:pointer;font-size:13px">X</button>
        </div>
      </div>
      <button onclick="addNewSubjRow()"
        style="background:none;border:1px dashed var(--gray-300);border-radius:6px;padding:6px 14px;
        cursor:pointer;font-size:12px;color:var(--gray-500);margin-top:4px;margin-bottom:12px">
        + Add Another Subject
      </button>
      <div id="editExamFeedback" style="display:none;font-size:12px;padding:6px 10px;border-radius:6px;margin-bottom:10px"></div>
      <div style="display:flex;gap:8px">
        <button class="btn btn-p" onclick="submitAddSubjects()">Save New Subjects</button>
        <button class="btn btn-s" onclick="closeEditExam()">Cancel</button>
      </div>
    </div>`;

  // Insert panel before examList
  const examList = document.getElementById('examList');
  if (examList) examList.insertAdjacentElement('beforebegin', panel);
  panel.scrollIntoView({ behavior: 'smooth' });
}

function closeEditExam() {
  const panel = document.getElementById('editExamPanel');
  if (panel) panel.remove();
  _editingExamId   = null;
  _editingExamName = '';
}

function addNewSubjRow() {
  const row = document.createElement('div');
  row.className = 'new-subj-row';
  row.style.cssText = 'display:flex;gap:8px;margin-bottom:6px';
  row.innerHTML =
    '<input type="text" class="new-subj-name" placeholder="New subject name"' +
    ' style="padding:8px 10px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px;flex:1">' +
    '<button onclick="removeNewSubjRow(this)" style="background:none;border:1px solid #E24B4A;color:#E24B4A;border-radius:6px;padding:4px 10px;cursor:pointer;font-size:13px">X</button>';
  document.getElementById('newSubjectInputs').appendChild(row);
}

function removeNewSubjRow(btn) {
  const rows = document.querySelectorAll('.new-subj-row');
  if (rows.length <= 1) { showToast('At least one subject row required', 'error'); return; }
  btn.closest('.new-subj-row').remove();
}

async function submitAddSubjects() {
  if (!_editingExamId) return;

  const inputs   = document.querySelectorAll('.new-subj-name');
  const subjects = Array.from(inputs).map(el => el.value.trim()).filter(Boolean);
  const feedback = document.getElementById('editExamFeedback');

  if (!subjects.length) {
    showFeedback(feedback, 'Please enter at least one subject name.', 'error');
    return;
  }

  let saved = 0, failed = 0;
  for (const name of subjects) {
    try {
      await API.addExamSubject(_editingExamId, { name });
      saved++;
    } catch (e) {
      failed++;
    }
  }

  if (failed === 0) {
    showToast(saved + ' subject(s) added successfully!');
    closeEditExam();
    navigateTo('adv_exam');
  } else {
    showFeedback(feedback, saved + ' saved, ' + failed + ' failed. Please try again.', 'warn');
  }
}

// ══════════════════════════════════════════════════════
// HOD EXAM RESULTS PAGE
// ══════════════════════════════════════════════════════
PAGE_RENDERERS.hod_exam_results = async function() {
  const allMarks = await API.getHodExamMarks().catch(() => []);

  // Build unique exam and subject lists for filters
  const exams    = [...new Map(allMarks.map(m => [m.exam_id, { id: m.exam_id, name: m.exam_name }])).values()];
  const sections = [...new Set(allMarks.map(m => m.section))].filter(Boolean).sort();

  if (!allMarks.length) {
    return `
      <div class="page-title">Exam Results</div>
      <div class="card">${emptyState('📊', 'No exam marks found. Class advisors need to enter marks first.')}</div>`;
  }

  return `
    <div class="page-header">
      <div class="page-title">Exam Results</div>
    </div>

    <!-- FILTERS -->
    <div class="card" style="margin-bottom:14px">
      <div style="display:flex;flex-wrap:wrap;gap:12px;align-items:flex-end">
        <div>
          <label style="font-size:11px;font-weight:600;color:var(--gray-500);display:block;margin-bottom:4px;text-transform:uppercase">Examination</label>
          <select id="hodExamFilter" onchange="hodFilterMarks()"
            style="padding:7px 10px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px;min-width:180px">
            <option value="">All Exams</option>
            ${exams.map(e => `<option value="${e.id}">${e.name}</option>`).join('')}
          </select>
        </div>
        <div>
          <label style="font-size:11px;font-weight:600;color:var(--gray-500);display:block;margin-bottom:4px;text-transform:uppercase">Year</label>
          <select id="hodYearFilter" onchange="hodFilterMarks()"
            style="padding:7px 10px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px">
            <option value="">All Years</option>
            <option value="2">Year 2</option>
            <option value="3">Year 3</option>
            <option value="4">Year 4</option>
          </select>
        </div>
        <div>
          <label style="font-size:11px;font-weight:600;color:var(--gray-500);display:block;margin-bottom:4px;text-transform:uppercase">Section</label>
          <select id="hodSecFilter" onchange="hodFilterMarks()"
            style="padding:7px 10px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px">
            <option value="">All Sections</option>
            ${sections.map(s => `<option value="${s}">Section ${s}</option>`).join('')}
          </select>
        </div>
        <div>
          <label style="font-size:11px;font-weight:600;color:var(--gray-500);display:block;margin-bottom:4px;text-transform:uppercase">Pass/Fail</label>
          <select id="hodPfFilter" onchange="hodFilterMarks()"
            style="padding:7px 10px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px">
            <option value="">All</option>
            <option value="Pass">Pass</option>
            <option value="Fail">Fail</option>
          </select>
        </div>
        <div>
          <label style="font-size:11px;font-weight:600;color:var(--gray-500);display:block;margin-bottom:4px;text-transform:uppercase">Search</label>
          <input id="hodMarkSearch" type="text" placeholder="Student name or roll no..."
            oninput="hodFilterMarks()"
            style="padding:7px 10px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px;min-width:200px">
        </div>
      </div>
    </div>

    <!-- CHARTS ROW -->
    <div class="two-col" style="margin-bottom:14px">
      <div class="card">
        <div style="font-size:12px;font-weight:600;color:var(--gray-500);text-transform:uppercase;letter-spacing:.05em;margin-bottom:10px">Pass / Fail Distribution</div>
        <div style="position:relative;height:180px"><canvas id="hodExamPieChart"></canvas></div>
      </div>
      <div class="card">
        <div style="font-size:12px;font-weight:600;color:var(--gray-500);text-transform:uppercase;letter-spacing:.05em;margin-bottom:10px">Grade Distribution</div>
        <div style="position:relative;height:180px"><canvas id="hodExamBarChart"></canvas></div>
      </div>
    </div>

    <!-- SUMMARY STATS -->
    <div id="hodExamStats" style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:14px"></div>

    <!-- RESULTS TABLE -->
    <div class="card" style="padding:0">
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Student</th><th>Roll No</th><th>Yr/Sec</th>
              <th>Exam</th><th>Subject</th>
              <th>Mark</th><th>Activity</th><th>Grade</th><th>Status</th>
            </tr>
          </thead>
          <tbody id="hodMarksTableBody"></tbody>
        </table>
      </div>
    </div>`;
};

// Store marks globally for filtering
let _hodAllMarks = [];

POST_RENDER.hod_exam_results = async function() {
  _hodAllMarks = await API.getHodExamMarks().catch(() => []);
  hodFilterMarks();
};

function hodFilterMarks() {
  const examId  = document.getElementById('hodExamFilter')?.value;
  const year    = document.getElementById('hodYearFilter')?.value;
  const section = document.getElementById('hodSecFilter')?.value;
  const pf      = document.getElementById('hodPfFilter')?.value;
  const q       = document.getElementById('hodMarkSearch')?.value?.toLowerCase() || '';

  let filtered = _hodAllMarks;
  if (examId)  filtered = filtered.filter(m => m.exam_id == examId);
  if (year)    filtered = filtered.filter(m => m.year == year);
  if (section) filtered = filtered.filter(m => m.section === section);
  if (pf)      filtered = filtered.filter(m => m.pass_fail === pf);
  if (q)       filtered = filtered.filter(m =>
    (m.student_name||'').toLowerCase().includes(q) ||
    (m.roll_no||'').toLowerCase().includes(q));

  hodRenderStats(filtered);
  hodRenderTable(filtered);
  hodRenderCharts(filtered);
}

function hodRenderStats(data) {
  const el = document.getElementById('hodExamStats');
  if (!el) return;
  const total   = data.length;
  const passed  = data.filter(m => m.pass_fail === 'Pass').length;
  const failed  = data.filter(m => m.pass_fail === 'Fail').length;
  const avgMark = total ? (data.reduce((a, m) => a + (m.subject_mark / m.max_mark * 100), 0) / total).toFixed(1) : 0;
  el.innerHTML = `
    <div class="stat-card"><div class="stat-label">Total Records</div><div class="stat-val">${total}</div></div>
    <div class="stat-card"><div class="stat-label">Passed</div><div class="stat-val" style="color:#1D9E75">${passed}</div></div>
    <div class="stat-card"><div class="stat-label">Failed</div><div class="stat-val" style="color:#E24B4A">${failed}</div></div>
    <div class="stat-card"><div class="stat-label">Avg Score</div><div class="stat-val">${avgMark}%</div></div>`;
}

function hodRenderTable(data) {
  const tbody = document.getElementById('hodMarksTableBody');
  if (!tbody) return;
  if (!data.length) {
    tbody.innerHTML = `<tr><td colspan="9" style="text-align:center;padding:2rem;color:var(--gray-400)">No results found for the selected filters.</td></tr>`;
    return;
  }
  tbody.innerHTML = data.map((m, i) => {
    const pct   = m.max_mark > 0 ? Math.round((m.subject_mark / m.max_mark) * 100) : 0;
    const pfCol = m.pass_fail === 'Pass' ? '#1D9E75' : '#E24B4A';
    const pfBg  = m.pass_fail === 'Pass' ? '#E1F5EE' : '#FCEBEB';
    return `
      <tr style="background:${i%2===0?'#fff':'#f8f9fa'}">
        <td style="font-weight:600">${m.student_name}</td>
        <td style="color:var(--gray-500)">${m.roll_no}</td>
        <td>${pill('Yr'+m.year+' '+m.section,'gray')}</td>
        <td style="font-size:12px">${m.exam_name}</td>
        <td style="font-size:12px">${m.subject_name}</td>
        <td>
          <div style="display:flex;align-items:center;gap:6px">
            <span style="font-weight:700">${m.subject_mark}/${m.max_mark}</span>
            <span style="font-size:11px;color:var(--gray-400)">(${pct}%)</span>
          </div>
          <div style="height:4px;background:#f0f0f0;border-radius:4px;margin-top:3px;width:80px">
            <div style="height:100%;border-radius:4px;width:${pct}%;background:${pct>=75?'#1D9E75':pct>=50?'#EF9F27':'#E24B4A'}"></div>
          </div>
        </td>
        <td>${m.activity_mark}</td>
        <td><span style="font-weight:700;color:#534AB7">${m.grade || '—'}</span></td>
        <td><span style="padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600;background:${pfBg};color:${pfCol}">${m.pass_fail}</span></td>
      </tr>`;
  }).join('');
}

function hodRenderCharts(data) {
  // Destroy old charts
  if (chartRefs.hodExamPie) { chartRefs.hodExamPie.destroy(); delete chartRefs.hodExamPie; }
  if (chartRefs.hodExamBar) { chartRefs.hodExamBar.destroy(); delete chartRefs.hodExamBar; }

  const pieEl = document.getElementById('hodExamPieChart');
  const barEl = document.getElementById('hodExamBarChart');

  const passed = data.filter(m => m.pass_fail === 'Pass').length;
  const failed = data.filter(m => m.pass_fail === 'Fail').length;

  if (pieEl && (passed + failed) > 0) {
    chartRefs.hodExamPie = new Chart(pieEl, {
      type: 'doughnut',
      data: {
        labels: ['Pass', 'Fail'],
        datasets: [{ data: [passed, failed], backgroundColor: ['#1D9E75', '#E24B4A'], borderWidth: 0, hoverOffset: 4 }]
      },
      options: { responsive: true, maintainAspectRatio: false, cutout: '65%',
        plugins: { legend: { position: 'bottom', labels: { font: { size: 11 } } },
          tooltip: { callbacks: { label: ctx => ` ${ctx.label}: ${ctx.raw}` } } } }
    });
  }

  // Grade distribution bar chart
  const gradeCounts = { 'O': 0, 'A+': 0, 'A': 0, 'B+': 0, 'B': 0, 'C': 0, 'F': 0 };
  data.forEach(m => { if (m.grade && gradeCounts[m.grade] !== undefined) gradeCounts[m.grade]++; });

  if (barEl) {
    chartRefs.hodExamBar = new Chart(barEl, {
      type: 'bar',
      data: {
        labels: Object.keys(gradeCounts),
        datasets: [{
          label: 'Students',
          data: Object.values(gradeCounts),
          backgroundColor: ['#185FA5','#1D9E75','#1D9E75','#EF9F27','#EF9F27','#E24B4A','#E24B4A'],
          borderRadius: 5, borderWidth: 0
        }]
      },
      options: { responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: { x: { grid: { display: false }, ticks: { color: '#868E96' } },
          y: { grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { color: '#868E96', stepSize: 1 }, beginAtZero: true } } }
    });
  }
}

// ══════════════════════════════════════════════════════
// STUDENT PROFILE — EXAM MARKS TAB
// ══════════════════════════════════════════════════════
async function loadStudentExamMarks(studentId, containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = '<div class="spinner" style="margin:1rem auto;display:block"></div>';

  try {
    const marks = await API.getStudentMarks(studentId);
    if (!marks.length) {
      container.innerHTML = emptyState('📊', 'No exam marks available yet.');
      return;
    }

    // Group by exam
    const byExam = {};
    marks.forEach(m => {
      if (!byExam[m.exam_name]) byExam[m.exam_name] = [];
      byExam[m.exam_name].push(m);
    });

    container.innerHTML = Object.entries(byExam).map(([examName, subjects]) => {
      const avg = subjects.reduce((a, s) => a + (s.subject_mark / s.max_mark * 100), 0) / subjects.length;
      const allPass = subjects.every(s => s.pass_fail === 'Pass');
      return `
        <div style="margin-bottom:14px;border:1px solid var(--gray-200);border-radius:10px;overflow:hidden">
          <div style="background:#185FA5;color:#fff;padding:10px 14px;display:flex;justify-content:space-between;align-items:center">
            <span style="font-weight:700;font-size:13px">${examName}</span>
            <div style="display:flex;gap:8px;align-items:center">
              <span style="font-size:11px;background:rgba(255,255,255,0.2);padding:2px 8px;border-radius:10px">Avg: ${avg.toFixed(1)}%</span>
              <span style="font-size:11px;padding:2px 8px;border-radius:10px;font-weight:600;
                background:${allPass?'#E1F5EE':'#FCEBEB'};color:${allPass?'#085041':'#791F1F'}">
                ${allPass ? 'All Pass' : 'Has Fail'}
              </span>
            </div>
          </div>
          <table style="width:100%;border-collapse:collapse;font-size:12px">
            <thead>
              <tr style="background:#f8f9fa">
                <th style="padding:7px 12px;text-align:left;color:var(--gray-500);font-weight:600">Subject</th>
                <th style="padding:7px 12px;text-align:center;color:var(--gray-500);font-weight:600">Mark</th>
                <th style="padding:7px 12px;text-align:center;color:var(--gray-500);font-weight:600">Activity</th>
                <th style="padding:7px 12px;text-align:center;color:var(--gray-500);font-weight:600">Grade</th>
                <th style="padding:7px 12px;text-align:center;color:var(--gray-500);font-weight:600">Status</th>
              </tr>
            </thead>
            <tbody>
              ${subjects.map(s => {
                const pct   = s.max_mark > 0 ? Math.round(s.subject_mark / s.max_mark * 100) : 0;
                const pfCol = s.pass_fail === 'Pass' ? '#1D9E75' : '#E24B4A';
                return `
                  <tr style="border-top:1px solid var(--gray-100)">
                    <td style="padding:8px 12px;font-weight:600">${s.subject_name}</td>
                    <td style="padding:8px 12px;text-align:center">
                      <span style="font-weight:700">${s.subject_mark}/${s.max_mark}</span>
                      <div style="height:3px;background:#f0f0f0;border-radius:3px;margin-top:3px;width:60px;margin-left:auto;margin-right:auto">
                        <div style="height:100%;border-radius:3px;width:${pct}%;background:${pct>=75?'#1D9E75':pct>=50?'#EF9F27':'#E24B4A'}"></div>
                      </div>
                    </td>
                    <td style="padding:8px 12px;text-align:center">${s.activity_mark}</td>
                    <td style="padding:8px 12px;text-align:center;font-weight:700;color:#534AB7">${s.grade || '—'}</td>
                    <td style="padding:8px 12px;text-align:center">
                      <span style="padding:2px 8px;border-radius:10px;font-size:11px;font-weight:600;
                        background:${s.pass_fail==='Pass'?'#E1F5EE':'#FCEBEB'};color:${pfCol}">
                        ${s.pass_fail}
                      </span>
                    </td>
                  </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>`;
    }).join('');
  } catch(e) {
    container.innerHTML = '<div style="color:var(--red);font-size:13px">Error loading marks.</div>';
  }
}

// ══════════════════════════════════════════════════════
// TIMETABLE MODULE
// ══════════════════════════════════════════════════════

const TT_SLOTS = [
  { index: 0, label: '8:45 - 9:45',   type: 'period' },
  { index: 1, label: '9:45 - 10:45',  type: 'period' },
  { index: 2, label: '10:45 - 11:00', type: 'break'  },
  { index: 3, label: '11:00 - 12:00', type: 'period' },
  { index: 4, label: '12:00 - 1:00',  type: 'lunch'  },
  { index: 5, label: '1:00 - 2:00',   type: 'period' },
  { index: 6, label: '2:00 - 2:50',   type: 'period' },
  { index: 7, label: '2:50 - 3:00',   type: 'break'  },
  { index: 8, label: '3:00 - 3:50',   type: 'period' },
  { index: 9, label: '3:50 - 4:40',   type: 'period' },
];
const TT_DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday'];

// Subject colors for visual distinction
const TT_COLORS = [
  { bg: '#E6F1FB', border: '#185FA5', text: '#185FA5' },
  { bg: '#E1F5EE', border: '#1D9E75', text: '#1D9E75' },
  { bg: '#EEEDFE', border: '#534AB7', text: '#534AB7' },
  { bg: '#FAEEDA', border: '#EF9F27', text: '#633806' },
  { bg: '#FCEBEB', border: '#E24B4A', text: '#E24B4A' },
  { bg: '#E8F8F5', border: '#17A589', text: '#17A589' },
  { bg: '#FEF9E7', border: '#D4AC0D', text: '#9A7D0A' },
  { bg: '#FDEDEC', border: '#E74C3C', text: '#E74C3C' },
];

let _ttSubjectColorMap = {};

function ttGetColor(subjectId) {
  if (!_ttSubjectColorMap[subjectId]) {
    const idx = Object.keys(_ttSubjectColorMap).length % TT_COLORS.length;
    _ttSubjectColorMap[subjectId] = TT_COLORS[idx];
  }
  return _ttSubjectColorMap[subjectId];
}

// ── HOD TIMETABLE PAGE ────────────────────────────────
function ttHodPageHTML(staff, subjects) {
  const yr2Subs = subjects.filter(s => s.year === 2);
  const yr3Subs = subjects.filter(s => s.year === 3);
  const yr4Subs = subjects.filter(s => s.year === 4);

  return `
    <div class="page-header">
      <div class="page-title">Timetable Management</div>
    </div>

    <!-- GENERATE CONTROLS -->
    <div class="card" style="margin-bottom:14px">
      <div style="font-size:13px;font-weight:700;color:var(--gray-700);margin-bottom:12px">
        Generate Timetable
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center">
        <select id="ttGenYear"
          style="padding:8px 12px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px">
          <option value="2">Year 2</option>
          <option value="3">Year 3</option>
          <option value="4">Year 4</option>
        </select>
        <select id="ttGenSec"
          style="padding:8px 12px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px">
          <option value="A">Section A</option>
          <option value="B">Section B</option>
          <option value="C">Section C</option>
        </select>
        <button class="btn btn-p" onclick="ttGenerate()">
          Auto-Generate Timetable
        </button>
        <span style="font-size:11px;color:var(--gray-400)">
          Generates based on subjects and staff assigned
        </span>
      </div>
    </div>

    <!-- VIEW CONTROLS -->
    <div class="card" style="margin-bottom:14px">
      <div style="font-size:13px;font-weight:700;color:var(--gray-700);margin-bottom:12px">
        View Timetable
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center">
        <select id="ttViewYear" onchange="ttLoadView()"
          style="padding:8px 12px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px">
          <option value="2">Year 2</option>
          <option value="3">Year 3</option>
          <option value="4">Year 4</option>
        </select>
        <select id="ttViewSec" onchange="ttLoadView()"
          style="padding:8px 12px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px">
          <option value="A">Section A</option>
          <option value="B">Section B</option>
          <option value="C">Section C</option>
        </select>
      </div>
    </div>

    <!-- SUBJECTS SUMMARY -->
    <div class="card" style="margin-bottom:14px">
      <div style="font-size:13px;font-weight:700;color:var(--gray-700);margin-bottom:12px">
        Subjects & Staff Assignment
      </div>
      ${[{year:2,subs:yr2Subs},{year:3,subs:yr3Subs},{year:4,subs:yr4Subs}].map(g => `
        <div style="margin-bottom:12px">
          <div style="font-size:11px;font-weight:700;color:var(--gray-500);text-transform:uppercase;
            letter-spacing:.05em;margin-bottom:6px">Year ${g.year}</div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            ${g.subs.map(s => `
              <div style="padding:6px 10px;border-radius:6px;border:1px solid var(--gray-200);
                font-size:12px;background:#f8f9fa">
                <span style="font-weight:600">${s.code}</span> ${s.name}
                <span style="color:var(--gray-400);margin-left:4px">— ${s.staff_name || 'Unassigned'}</span>
                ${s.is_lab ? '<span style="background:#EEEDFE;color:#534AB7;padding:1px 6px;border-radius:10px;font-size:10px;margin-left:4px">LAB</span>' : ''}
              </div>`).join('')}
          </div>
        </div>`).join('')}
    </div>

    <!-- TIMETABLE GRID -->
    <div id="ttGridContainer">
      <div style="text-align:center;padding:2rem;color:var(--gray-400);font-size:13px">
        Select year and section above to view timetable
      </div>
    </div>`;
}

// ── GENERATE TIMETABLE ────────────────────────────────
async function ttGenerate() {
  const year    = document.getElementById('ttGenYear')?.value;
  const section = document.getElementById('ttGenSec')?.value;
  if (!year || !section) return;

  const btn = event.target;
  btn.textContent = 'Generating...';
  btn.disabled    = true;

  try {
    const res = await API.generateTimetable(year, section);
    showToast(res.message || 'Timetable generated!');
    // Auto-load the generated timetable
    const viewYear = document.getElementById('ttViewYear');
    const viewSec  = document.getElementById('ttViewSec');
    if (viewYear) viewYear.value = year;
    if (viewSec)  viewSec.value  = section;
    await ttLoadView();
  } catch (e) {
    showToast(e?.detail || 'Error generating timetable', 'error');
  } finally {
    btn.textContent = 'Auto-Generate Timetable';
    btn.disabled    = false;
  }
}

// ── LOAD & RENDER TIMETABLE GRID ─────────────────────
async function ttLoadView(defaultYear, defaultSection) {
  const yearEl = document.getElementById('ttViewYear');
  const secEl  = document.getElementById('ttViewSec');
  const year    = yearEl ? parseInt(yearEl.value) : (defaultYear || 2);
  const section = secEl  ? secEl.value            : (defaultSection || 'A');

  const container = document.getElementById('ttGridContainer');
  if (!container) return;
  container.innerHTML = '<div class="spinner" style="margin:2rem auto;display:block"></div>';

  try {
    const data = await API.getTimetable(year, section);
    _ttSubjectColorMap = {};
    container.innerHTML = ttRenderGrid(data, `Year ${year} — Section ${section}`, false);
  } catch(e) {
    container.innerHTML = `<div class="card" style="color:var(--red);font-size:13px">
      Error loading timetable: ${e?.detail || 'No timetable generated yet. Click Auto-Generate first.'}
    </div>`;
  }
}

// ── VIEW PAGE (Advisor / Mentor / Student) ────────────
function ttViewPageHTML(role) {
  return `
    <div class="page-header">
      <div class="page-title">Timetable</div>
    </div>
    <div class="card" style="margin-bottom:14px">
      <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center">
        <select id="ttViewYear" onchange="ttLoadViewGeneric()"
          style="padding:8px 12px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px">
          <option value="2">Year 2</option>
          <option value="3">Year 3</option>
          <option value="4">Year 4</option>
        </select>
        <select id="ttViewSec" onchange="ttLoadViewGeneric()"
          style="padding:8px 12px;border:1px solid var(--gray-200);border-radius:6px;font-size:13px">
          <option value="A">Section A</option>
          <option value="B">Section B</option>
          <option value="C">Section C</option>
        </select>
      </div>
    </div>
    <div id="ttGridContainer">
      <div style="text-align:center;padding:2rem;color:var(--gray-400);font-size:13px">
        Loading timetable...
      </div>
    </div>`;
}

async function ttLoadViewGeneric() {
  const yearEl = document.getElementById('ttViewYear');
  const secEl  = document.getElementById('ttViewSec');
  const year    = yearEl ? parseInt(yearEl.value) : 2;
  const section = secEl  ? secEl.value            : 'A';
  const container = document.getElementById('ttGridContainer');
  if (!container) return;
  container.innerHTML = '<div class="spinner" style="margin:2rem auto;display:block"></div>';
  try {
    const data = await API.getTimetable(year, section);
    _ttSubjectColorMap = {};
    container.innerHTML = ttRenderGrid(data, 'Year ' + year + ' - Section ' + section, false);
  } catch(e) {
    container.innerHTML = `<div class="card" style="color:var(--gray-400);font-size:13px;text-align:center;padding:2rem">
      No timetable available for Year ${year} Section ${section} yet.
    </div>`;
  }
}

async function ttLoadAdvisorView() {
  const myYear    = localStorage.getItem('my_year');
  const mySection = localStorage.getItem('my_section');
  const staffId   = localStorage.getItem('staff_id');
  const yearEl = document.getElementById('ttViewYear');
  const secEl  = document.getElementById('ttViewSec');
  if (yearEl && myYear)    yearEl.value = myYear;
  if (secEl  && mySection) secEl.value  = mySection;
  await ttLoadViewGeneric();
  if (staffId) await ttLoadStaffSchedule(staffId);
}

async function ttLoadMentorView() {
  const staffId = localStorage.getItem('staff_id');
  await ttLoadViewGeneric();
  if (staffId) await ttLoadStaffSchedule(staffId);
}

async function ttLoadStudentView() {
  try {
    const profile = await API.getMyProfile(ENTITY_ID);
    const yearEl  = document.getElementById('ttViewYear');
    const secEl   = document.getElementById('ttViewSec');
    if (yearEl && profile.year)    yearEl.value = String(profile.year);
    if (secEl  && profile.section) secEl.value  = profile.section;
    if (yearEl) yearEl.disabled = true;
    if (secEl)  secEl.disabled  = true;
    await ttLoadViewGeneric();
  } catch(e) {
    await ttLoadViewGeneric();
  }
}

async function ttLoadStaffSchedule(staffId) {
  const container = document.getElementById('ttGridContainer');
  if (!container) return;
  const scheduleDiv = document.createElement('div');
  scheduleDiv.id = 'ttStaffSchedule';
  scheduleDiv.innerHTML = '<div style="text-align:center;padding:1rem;color:var(--gray-400);font-size:13px">Loading your schedule...</div>';
  container.appendChild(scheduleDiv);
  try {
    const data = await API.getStaffTimetable(staffId);
    scheduleDiv.innerHTML = ttRenderStaffSchedule(data);
  } catch(e) {
    scheduleDiv.innerHTML = '';
  }
}

function ttRenderStaffSchedule(data) {
  const { slots, days, entries } = data;
  if (!entries || entries.length === 0) {
    return `<div class="card" style="margin-top:14px;text-align:center;padding:2rem;color:var(--gray-400)">
      <div style="font-size:28px;margin-bottom:8px">📋</div>
      <div style="font-size:13px">No periods allocated yet. HOD needs to generate the timetable first.</div>
    </div>`;
  }
  const grid = {};
  days.forEach(d => { grid[d] = {}; });
  entries.forEach(e => {
    if (!grid[e.day]) grid[e.day] = {};
    grid[e.day][e.slot_index] = e;
  });
  const totalPeriods = entries.length;
  const subjects = [...new Set(entries.map(e => e.subject_name))];
  const classes  = [...new Set(entries.map(e => 'Yr' + e.year + e.section))];
  const dayShort = { Monday:'Mon', Tuesday:'Tue', Wednesday:'Wed', Thursday:'Thu', Friday:'Fri' };

  return `<div class="card" style="margin-top:14px;padding:0;overflow:hidden">
    <div style="padding:14px 16px;border-bottom:1px solid var(--gray-100);
      background:linear-gradient(135deg,#185FA5,#2980B9);color:white;
      display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
      <div>
        <div style="font-size:14px;font-weight:700">My Teaching Schedule</div>
        <div style="font-size:11px;opacity:.8;margin-top:2px">Your allocated periods this week</div>
      </div>
      <div style="display:flex;gap:16px">
        <div style="text-align:center">
          <div style="font-size:20px;font-weight:800">${totalPeriods}</div>
          <div style="font-size:10px;opacity:.8">Periods/Week</div>
        </div>
        <div style="text-align:center">
          <div style="font-size:20px;font-weight:800">${subjects.length}</div>
          <div style="font-size:10px;opacity:.8">Subjects</div>
        </div>
        <div style="text-align:center">
          <div style="font-size:20px;font-weight:800">${classes.length}</div>
          <div style="font-size:10px;opacity:.8">Classes</div>
        </div>
      </div>
    </div>
    <div style="overflow-x:auto">
      <table style="width:100%;border-collapse:collapse;min-width:700px">
        <thead>
          <tr style="background:#f8f9fa">
            <th style="padding:10px 12px;text-align:left;font-size:11px;font-weight:700;
              color:var(--gray-500);text-transform:uppercase;width:100px;
              border-bottom:2px solid var(--gray-200)">Time</th>
            ${days.map(d => `<th style="padding:10px 12px;text-align:center;font-size:12px;font-weight:700;
              color:#185FA5;border-bottom:2px solid var(--gray-200)">${dayShort[d]||d}</th>`).join('')}
          </tr>
        </thead>
        <tbody>
          ${slots.map((slot, rowIdx) => {
            if (slot.type === 'break') return `<tr style="background:#FFF9E6">
              <td style="padding:5px 12px;font-size:11px;font-weight:600;color:#EF9F27;
                border-bottom:1px solid #FAC775">Short Break</td>
              ${days.map(() => '<td style="border-bottom:1px solid #FAC775"></td>').join('')}
            </tr>`;
            if (slot.type === 'lunch') return `<tr style="background:#E8F8F5">
              <td style="padding:8px 12px;font-size:11px;font-weight:600;color:#1D9E75;
                border-bottom:1px solid #A9DFBF">Lunch Break</td>
              ${days.map(() => '<td style="border-bottom:1px solid #A9DFBF"></td>').join('')}
            </tr>`;
            return `<tr style="background:${rowIdx%2===0?'#fff':'#fafafa'}">
              <td style="padding:6px 12px;font-size:11px;font-weight:600;
                color:var(--gray-600);border-bottom:1px solid var(--gray-100);white-space:nowrap">
                ${slot.label}
              </td>
              ${days.map(day => {
                const entry = grid[day]?.[slot.index];
                if (!entry) return `<td style="padding:6px;border-bottom:1px solid var(--gray-100);
                  text-align:center"><span style="font-size:10px;color:var(--gray-200)">—</span></td>`;
                const col = ttGetColor(entry.subject_name);
                return `<td style="padding:5px 6px;border-bottom:1px solid var(--gray-100)">
                  <div style="background:${col.bg};border-left:3px solid ${col.border};
                    border-radius:4px;padding:5px 7px;min-height:50px">
                    ${entry.is_lab ? `<div style="font-size:9px;font-weight:700;color:${col.text};
                      text-transform:uppercase;margin-bottom:2px">LAB</div>` : ''}
                    <div style="font-size:11px;font-weight:700;color:${col.text}">${entry.subject_code||''}</div>
                    <div style="font-size:10px;color:${col.text};opacity:.85">${entry.subject_name}</div>
                    <div style="font-size:10px;font-weight:700;color:#185FA5;margin-top:3px">
                      Year ${entry.year} — Sec ${entry.section}
                    </div>
                  </div>
                </td>`;
              }).join('')}
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>
  </div>`;
}

function ttRenderGrid(data, title, staffView) {
  const { slots, days, grid } = data;
  if (!grid || Object.keys(grid).length === 0) {
    return `<div class="card" style="text-align:center;padding:3rem;color:var(--gray-400)">
      <div style="font-size:32px;margin-bottom:8px">📅</div>
      No timetable generated yet. Use the Generate button above.
    </div>`;
  }

  const dayShort = { Monday:'Mon', Tuesday:'Tue', Wednesday:'Wed', Thursday:'Thu', Friday:'Fri' };

  return `
    <div class="card" style="padding:0;overflow:hidden">
      <div style="padding:14px 16px;border-bottom:1px solid var(--gray-100);
        display:flex;align-items:center;justify-content:space-between">
        <div style="font-size:14px;font-weight:700;color:var(--gray-900)">${title}</div>
        <div style="font-size:11px;color:var(--gray-400)">Weekly Fixed Schedule</div>
      </div>
      <div style="overflow-x:auto">
        <table style="width:100%;border-collapse:collapse;min-width:700px">
          <thead>
            <tr style="background:#f8f9fa">
              <th style="padding:10px 12px;text-align:left;font-size:11px;font-weight:700;
                color:var(--gray-500);text-transform:uppercase;width:100px;border-bottom:2px solid var(--gray-200)">
                Time
              </th>
              ${days.map(d => `
                <th style="padding:10px 12px;text-align:center;font-size:12px;font-weight:700;
                  color:#185FA5;border-bottom:2px solid var(--gray-200)">
                  ${dayShort[d] || d}
                </th>`).join('')}
            </tr>
          </thead>
          <tbody>
            ${slots.map((slot, rowIdx) => {
              if (slot.type === 'break') {
                return `<tr style="background:#FFF9E6">
                  <td style="padding:5px 12px;font-size:11px;font-weight:600;color:#EF9F27;
                    border-bottom:1px solid #FAC775">Short Break</td>
                  ${days.map(() => `<td style="padding:5px;text-align:center;font-size:11px;
                    color:#EF9F27;border-bottom:1px solid #FAC775">10 min</td>`).join('')}
                </tr>`;
              }
              if (slot.type === 'lunch') {
                return `<tr style="background:#E8F8F5">
                  <td style="padding:8px 12px;font-size:11px;font-weight:600;color:#1D9E75;
                    border-bottom:1px solid #A9DFBF">Lunch Break</td>
                  ${days.map(() => `<td style="padding:8px;text-align:center;font-size:11px;
                    color:#1D9E75;border-bottom:1px solid #A9DFBF">1 hour</td>`).join('')}
                </tr>`;
              }
              return `<tr style="background:${rowIdx % 2 === 0 ? '#fff' : '#fafafa'}">
                <td style="padding:6px 12px;font-size:11px;font-weight:600;
                  color:var(--gray-600);border-bottom:1px solid var(--gray-100);white-space:nowrap">
                  ${slot.label}
                </td>
                ${days.map(day => {
                  const key   = day + '_' + slot.index;
                  const entry = grid[key];
                  if (!entry || !entry.subject_name) {
                    return `<td style="padding:6px;border-bottom:1px solid var(--gray-100);
                      text-align:center">
                      <span style="font-size:10px;color:var(--gray-300)">—</span>
                    </td>`;
                  }
                  const col = ttGetColor(entry.subject_id);
                  return `<td style="padding:5px 6px;border-bottom:1px solid var(--gray-100)">
                    <div style="background:${col.bg};border-left:3px solid ${col.border};
                      border-radius:4px;padding:5px 7px;min-height:44px">
                      ${entry.is_lab ? `<div style="font-size:9px;font-weight:700;color:${col.text};
                        text-transform:uppercase;letter-spacing:.04em;margin-bottom:2px">LAB</div>` : ''}
                      <div style="font-size:11px;font-weight:700;color:${col.text};
                        line-height:1.3">${entry.subject_code || ''}</div>
                      <div style="font-size:10px;color:${col.text};opacity:.8;
                        white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
                        max-width:90px" title="${entry.subject_name}">
                        ${entry.subject_name}
                      </div>
                      <div style="font-size:10px;color:var(--gray-500);margin-top:2px">
                        ${entry.staff_short || entry.staff_name || ''}
                      </div>
                    </div>
                  </td>`;
                }).join('')}
              </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>

      <!-- LEGEND -->
      <div style="padding:12px 16px;border-top:1px solid var(--gray-100);
        display:flex;flex-wrap:wrap;gap:8px">
        ${[...new Set(Object.values(grid).filter(e => e.subject_id).map(e => e.subject_id))].map(sid => {
          const entry = Object.values(grid).find(e => e.subject_id === sid);
          const col   = ttGetColor(sid);
          return entry ? `<div style="display:flex;align-items:center;gap:4px;font-size:11px;color:var(--gray-600)">
            <div style="width:10px;height:10px;border-radius:2px;background:${col.bg};
              border:1px solid ${col.border}"></div>
            <span>${entry.subject_code} — ${entry.subject_name}</span>
          </div>` : '';
        }).join('')}
      </div>
    </div>`;
}


// ══════════════════════════════════════════════════════
// ATTENDANCE LOCK MANAGER (HOD)
// ══════════════════════════════════════════════════════

async function openLockManager() {
  om('mAttendLock');
  await refreshLockedDates();
}

async function refreshLockedDates() {
  const el = document.getElementById('lockedDatesList');
  if (!el) return;
  el.innerHTML = '<div style="padding:20px;text-align:center"><div class="spinner"></div></div>';
  try {
    const locks = await API.getLocks();
    if (!locks.length) {
      el.innerHTML = '<div style="padding:20px;text-align:center;color:var(--gray-400);font-size:13px">✅ No dates are currently locked.</div>';
      return;
    }
    el.innerHTML = `
      <table style="width:100%;border-collapse:collapse">
        <thead>
          <tr style="background:var(--gray-50);font-size:12px;color:var(--gray-500)">
            <th style="padding:10px 14px;text-align:left;font-weight:600">Locked Date</th>
            <th style="padding:10px 14px;text-align:left;font-weight:600">Locked At</th>
            <th style="padding:10px 14px;text-align:right;font-weight:600">Action</th>
          </tr>
        </thead>
        <tbody>
          ${locks.map(l => `
            <tr style="border-top:1px solid var(--gray-100)">
              <td style="padding:10px 14px;font-weight:600">
                <span style="background:#FEE2E2;color:#991B1B;padding:3px 10px;border-radius:12px;font-size:12px">🔒 ${formatDate(l.date)}</span>
              </td>
              <td style="padding:10px 14px;font-size:12px;color:var(--gray-500)">${formatDate(l.locked_at)}</td>
              <td style="padding:10px 14px;text-align:right">
                <button class="btn btn-s btn-xs" style="background:#FEF9C3;color:#854D0E;border-color:#FDE047" onclick="unlockAttendanceDate('${l.date}')">🔓 Unlock</button>
              </td>
            </tr>`).join('')}
        </tbody>
      </table>`;
  } catch(e) {
    el.innerHTML = '<div style="padding:16px;color:var(--red)">Error loading locks</div>';
  }
}

async function lockAttendanceDate() {
  const d = document.getElementById('lockDateInput')?.value;
  if (!d) { showToast('Please select a date to lock', 'warning'); return; }
  try {
    await API.lockDate({ date: d, locked_by: USER_ID });
    showToast('🔒 ' + formatDate(d) + ' locked successfully', 'success');
    document.getElementById('lockDateInput').value = '';
    await refreshLockedDates();
  } catch(e) {
    showToast(e?.detail || 'Failed to lock date', 'error');
  }
}

async function unlockAttendanceDate(dateStr) {
  if (!confirm('Unlock attendance for ' + formatDate(dateStr) + '? Advisors will be able to edit this date again.')) return;
  try {
    await API.unlockDate(dateStr);
    showToast('🔓 ' + formatDate(dateStr) + ' unlocked', 'success');
    await refreshLockedDates();
  } catch(e) {
    showToast(e?.detail || 'Failed to unlock', 'error');
  }
}


// ══════════════════════════════════════════════════════

// ==============================================
// PERIOD REPORT - DAY FILTERED
// ==============================================

async function prLoadReport() {
  const dateVal = document.getElementById('prDatePicker')?.value;
  const el      = document.getElementById('prTableArea');
  if (!el || !dateVal || !ENTITY_ID) return;
  el.innerHTML = '<div class="card" style="text-align:center;padding:2rem"><div class="spinner"></div></div>';
  try {
    const data = await API.getClassPeriodReport(ENTITY_ID, dateVal);
    if (data.no_classes) {
      el.innerHTML = '<div class="card" style="text-align:center;padding:2rem;color:var(--gray-400)">No classes on ' + (data.day_name || 'this day') + '. Select another day.</div>';
      return;
    }
    const { students, subjects, day_name } = data;
    if (!students || !students.length) { el.innerHTML = '<div class="card">No students found.</div>'; return; }
    if (!subjects || !subjects.length) { el.innerHTML = '<div class="card">No subjects scheduled on ' + (day_name||'this day') + '.</div>'; return; }
    const headerCols = subjects.map(s =>
      '<th style="padding:10px 8px;text-align:center;font-size:11px;color:#185FA5;font-weight:700;border-bottom:2px solid var(--gray-200)">' + s.code + '<br><span style="font-weight:400;color:var(--gray-500)">' + s.name + '</span></th>'
    ).join('');
    const rows = students.map(s => {
      const subCols = subjects.map(sub => {
        const d = s.subjects[sub.name];
        if (!d || d.total === 0) return '<td style="padding:9px 8px;text-align:center"><span style="font-size:11px;color:var(--gray-300)">—</span></td>';
        const col = d.pct >= 75 ? '#1D9E75' : d.pct >= 60 ? '#EF9F27' : '#E24B4A';
        const bg  = d.pct >= 75 ? '#E1F5EE' : d.pct >= 60 ? '#FAEEDA' : '#FCEBEB';
        return '<td style="padding:9px 8px;text-align:center"><span style="background:' + bg + ';color:' + col + ';padding:3px 8px;border-radius:20px;font-size:11px;font-weight:700">' + d.pct + '%</span><div style="font-size:10px;color:var(--gray-400);margin-top:2px">' + d.present + '/' + d.total + '</div></td>';
      }).join('');
      return '<tr style="border-bottom:1px solid var(--gray-100)"><td style="padding:9px 14px;font-weight:600;font-size:13px">' + s.name + '</td><td style="padding:9px 14px;font-size:12px;color:var(--gray-500)">' + (s.roll_no || '—') + '</td>' + subCols + '</tr>';
    }).join('');
    el.innerHTML =
      '<div style="font-size:12px;color:var(--gray-500);margin-bottom:1rem">Showing attendance for <strong>' + (day_name||'') + '</strong> — ' + subjects.length + ' subject(s)</div>' +
      '<div class="card" style="padding:0;overflow-x:auto"><table style="width:100%;border-collapse:collapse;min-width:600px">' +
        '<thead><tr style="background:#f8f9fa">' +
          '<th style="padding:10px 14px;text-align:left;font-size:12px;color:var(--gray-500);font-weight:600;border-bottom:2px solid var(--gray-200)">Student</th>' +
          '<th style="padding:10px 14px;text-align:left;font-size:12px;color:var(--gray-500);font-weight:600;border-bottom:2px solid var(--gray-200)">Roll No</th>' +
          headerCols + '</tr></thead><tbody>' + rows + '</tbody></table></div>';
  } catch(e) {
    el.innerHTML = '<div class="card" style="color:var(--red)">Error: ' + (e?.detail || e?.message || 'unknown') + '</div>';
  }
}

POST_RENDER.adv_period_report = async function() { await prLoadReport(); };

// PERIOD ATTENDANCE FUNCTIONS
// ══════════════════════════════════════════════════════

const PA_SLOT_LABELS = {
  0: '8:45 – 9:45',
  1: '9:45 – 10:45',
  3: '11:00 – 12:00',
  5: '1:00 – 2:00',
  6: '2:00 – 2:50',
  8: '3:00 – 3:50',
  9: '3:50 – 4:40',
};

// ── PERIOD ATTENDANCE: TIMETABLE-DRIVEN ───────────────
// When staff picks a date, we check what day of week it is,
// then show ONLY the periods they are actually scheduled for that day.

async function paLoadDaySlots() {
  const dateVal = document.getElementById('paDate')?.value;
  const staffId = localStorage.getItem('staff_id');
  const el      = document.getElementById('paStudentList');
  if (!dateVal || !staffId) return;

  el.innerHTML = '<div class="card"><div class="spinner"></div></div>';

  try {
    const dt       = new Date(dateVal + 'T00:00:00');
    const dayNames = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    const dayName  = dayNames[dt.getDay()];

    if (dayName === 'Sunday' || dayName === 'Saturday') {
      el.innerHTML = '<div class="card" style="text-align:center;padding:2rem;color:var(--gray-400)">📅 No classes on weekends</div>';
      return;
    }

    const ttData     = await API.getStaffTimetable(staffId);
    const todaySlots = (ttData.entries || []).filter(e => e.day === dayName);

    if (!todaySlots.length) {
      el.innerHTML = '<div class="card" style="text-align:center;padding:2rem;color:var(--gray-400)">📅 No periods scheduled for ' + dayName + '. Check your timetable.</div>';
      return;
    }

    todaySlots.sort((a, b) => a.slot_index - b.slot_index);

    // Store slot data globally for submit/markall
    window._paSlots = todaySlots.map(s => ({ ...s, date: dateVal, staffId }));

    let html = '<div style="font-size:13px;font-weight:600;color:var(--gray-600);margin-bottom:12px">📅 ' + dayName + ' — Your ' + todaySlots.length + ' period(s)</div>';

    for (let i = 0; i < todaySlots.length; i++) {
      const slot    = todaySlots[i];
      const slotLabel = PA_SLOT_LABELS[slot.slot_index] || ('Period ' + slot.slot_index);
      const yr  = slot.year;
      const sec = slot.section;
      const si  = slot.slot_index;
      const subjId = slot.subject_id || 0;

      const [students, existing] = await Promise.all([
        API.getStudentsForPeriod(yr, sec),
        API.getExistingPeriod(staffId, subjId, dateVal, si).catch(() => ({ records: [], already_marked: false }))
      ]);

      window._paSlots[i].students = students;
      const existingMap = {};
      (existing.records || []).forEach(r => { existingMap[r.student_id] = r.status; });
      const alreadyMarked = existing.already_marked;

      let studentRows = '';
      students.forEach(s => {
        const status = existingMap[s.id] || 'present';
        studentRows +=
          '<tr style="border-bottom:1px solid var(--gray-100)">' +
          '<td style="padding:7px 12px;font-size:13px;font-weight:600">' + s.name + '</td>' +
          '<td style="padding:7px 12px;font-size:12px;color:var(--gray-500)">' + (s.roll_no || '—') + '</td>' +
          '<td style="padding:7px 12px;text-align:center">' +
            '<select id="pa-' + yr + '-' + sec + '-' + si + '-' + s.id + '" style="padding:4px 8px;font-size:12px;border-radius:6px;border:1px solid var(--gray-200)">' +
              '<option value="present"' + (status === 'present' ? ' selected' : '') + '>Present</option>' +
              '<option value="absent"' + (status === 'absent' ? ' selected' : '') + '>Absent</option>' +
            '</select>' +
          '</td></tr>';
      });

      const statusBadge = alreadyMarked
        ? '<span style="background:#E1F5EE;color:#085041;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600">✓ Already marked</span>'
        : '<span style="background:#FAEEDA;color:#633806;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600">Not marked yet</span>';

      html +=
        '<div class="card" style="margin-bottom:14px">' +
          '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;flex-wrap:wrap;gap:8px">' +
            '<div>' +
              '<div style="font-size:15px;font-weight:700;color:var(--gray-900)">' + slotLabel + '</div>' +
              '<div style="font-size:12px;color:#185FA5;font-weight:600;margin-top:2px">' + (slot.subject_name || 'Subject') + ' &nbsp;|&nbsp; Year ' + yr + ' — Section ' + sec + '</div>' +
            '</div>' + statusBadge +
          '</div>' +
          '<div style="display:flex;gap:8px;margin-bottom:10px">' +
            '<button data-yr="' + yr + '" data-sec="' + sec + '" data-si="' + si + '" data-st="present" onclick="paMarkAllNew(this)" style="background:#E1F5EE;color:#085041;border:1px solid #A9DFBF;border-radius:6px;padding:4px 12px;font-size:12px;font-weight:600;cursor:pointer">✓ All Present</button>' +
            '<button data-yr="' + yr + '" data-sec="' + sec + '" data-si="' + si + '" data-st="absent" onclick="paMarkAllNew(this)" style="background:#FCEBEB;color:#791F1F;border:1px solid #F7C1C1;border-radius:6px;padding:4px 12px;font-size:12px;font-weight:600;cursor:pointer">✗ All Absent</button>' +
          '</div>' +
          '<div class="table-wrap"><table style="width:100%;border-collapse:collapse">' +
            '<thead><tr style="background:#f8f9fa">' +
              '<th style="padding:8px 12px;text-align:left;font-size:12px;color:var(--gray-500)">Name</th>' +
              '<th style="padding:8px 12px;text-align:left;font-size:12px;color:var(--gray-500)">Roll No</th>' +
              '<th style="padding:8px 12px;text-align:center;font-size:12px;color:var(--gray-500)">Status</th>' +
            '</tr></thead>' +
            '<tbody>' + (studentRows || '<tr><td colspan="3" style="padding:12px;text-align:center;color:var(--gray-400)">No students</td></tr>') + '</tbody>' +
          '</table></div>' +
          '<div style="display:flex;justify-content:flex-end;margin-top:12px">' +
            '<button data-yr="' + yr + '" data-sec="' + sec + '" data-si="' + si + '" data-subjid="' + subjId + '" data-date="' + dateVal + '" onclick="paSubmitNew(this)" style="background:#185FA5;color:#fff;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:600;cursor:pointer">💾 Save — Yr' + yr + ' Sec ' + sec + ' · ' + slotLabel + '</button>' +
          '</div>' +
        '</div>';
    }

    el.innerHTML = html;
  } catch(e) {
    el.innerHTML = '<div class="card" style="color:var(--red)">Error: ' + (e?.detail || e?.message || 'Failed to load') + '</div>';
  }
}


function paMarkAllNew(btn) {
  const yr = btn.dataset.yr, sec = btn.dataset.sec, si = btn.dataset.si, st = btn.dataset.st;
  document.querySelectorAll('[id^="pa-' + yr + '-' + sec + '-' + si + '-"]').forEach(sel => {
    sel.value = st;
  });
}

async function paSubmitNew(btn) {
  const yr     = btn.dataset.yr;
  const sec    = btn.dataset.sec;
  const si     = parseInt(btn.dataset.si);
  const subjId = parseInt(btn.dataset.subjid);
  const dateVal= btn.dataset.date;
  const staffId= localStorage.getItem('staff_id');
  if (!staffId) { showToast('No staff ID found', 'error'); return; }

  const selects = document.querySelectorAll('[id^="pa-' + yr + '-' + sec + '-' + si + '-"]');
  if (!selects.length) { showToast('No students found', 'error'); return; }

  const entries = [];
  selects.forEach(sel => {
    const parts = sel.id.split('-');
    entries.push({ student_id: parseInt(parts[parts.length - 1]), status: sel.value });
  });

  try {
    btn.textContent = 'Saving...';
    btn.disabled = true;
    await API.markPeriodAttendance({
      date: dateVal, subject_id: subjId,
      staff_id: parseInt(staffId), slot_index: si,
      entries, marked_by: USER_ID
    });
    showToast('✓ Saved — Yr' + yr + ' Sec ' + sec, 'success');
    await paLoadDaySlots();
  } catch(e) {
    showToast(e?.detail || 'Error saving', 'error');
    btn.textContent = '💾 Save';
    btn.disabled = false;
  }
}
